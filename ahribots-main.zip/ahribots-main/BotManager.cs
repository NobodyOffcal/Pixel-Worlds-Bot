﻿using ArhiBots.Bots;
using ArhiBots.GUI.Command_Handler;
using ArhiBots.Misc;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ArhiBots
{
    public static class BotManager
    {
        public static Thread BotManagerThread = new(UpdateBehaviours);

        public static List<Bot> bots = new();

        public static object behaviourLock = new object();
        public static List<Behaviour> behaviours = new();

        public static System.Timers.Timer wbUpdate = new System.Timers.Timer();

        public static Thread discordBot = new(Discord_bot.DiscordBot.StartDiscordBot);


        public static void Start()
        {
            BotManagerThread.Start();
            wbUpdate.Interval = 3000;
            wbUpdate.Elapsed += WHupdate;
            wbUpdate.Start();
        }



        public static void UpdateBehaviours()
        {
            Stopwatch stopwatch = new();
            stopwatch.Start();
            long previousTime = stopwatch.ElapsedMilliseconds;

            while (true)
            {
                lock (behaviourLock)
                {
                    for (int i = 0; i < behaviours.Count; i++)
                    {
                        Behaviour behaviour = behaviours[i];

                        if (behaviour.Destroyed)
                        {
                            behaviour.Dispose();
                            behaviours.RemoveAt(i);
                            i--;
                            continue;
                        }
                        if (!behaviour.ExecutedAwake)
                        {
                            behaviour.ExecutedAwake = true;
                            behaviour.Awake();
                        }
                        if (!behaviour.ExecutedStart)
                        {
                            behaviour.ExecutedStart = true;
                            behaviour.Start();
                        }

                        behaviour.Update();
                    }
                }

                long currentTime = stopwatch.ElapsedMilliseconds;
                Time.deltaTime = (float)((currentTime - previousTime) / 1000.0f);
                previousTime = currentTime;
            }

        }

        public static void AddBehaviour(Behaviour behaviour)
        {
            lock (behaviourLock)
            {
                behaviours.Add(behaviour);
            }
        }

        public static void RemoveBehaviour(Behaviour behaviour)
        {
            lock (behaviourLock)
            {
                behaviours.Remove(behaviour);
            }
        }

        public static void RemoveBot(int index)
        {
            if (index == -1) return;

            bots[index].Dispose();
            bots.RemoveAt(index);
        }

        public static Bot FindAvaliableCasinoBot()
        {
            foreach (Bot bot in bots)
            {
                if ((bot.status == Constants.PlayerConnectionStatus.InMenus || bot.status == Constants.PlayerConnectionStatus.InRoom) && bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.None && !bot.auto.Autoing()) 
                    return bot;
            }
            return null;
        }

        public static Bot FindAvaliableCasinoBot(int bytes)
        {
            foreach (Bot bot in bots)
            {
                if ((bot.status == Constants.PlayerConnectionStatus.InMenus || bot.status == Constants.PlayerConnectionStatus.InRoom) && bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.None && !bot.auto.Autoing() && bot.Player.myPlayerData.bc >= bytes * 0.75f)
                    return bot;
            }
            return null;
        }

        public static void RemoveBot(Bot bot)
        {
            bot.Dispose();
            bots.Remove(bot);
        }

        private static async void WHupdate(object? sender, ElapsedEventArgs e)
        {
            await WebhookLogs.UpdateBots();
        }

        public static Bot GetBotViaString(string @string)
        {
            bool parsed = int.TryParse(@string.ToLower(), out int value);


            if (parsed && value >= 0 && value < BotManager.bots.Count)
            {
                var bt = BotManager.bots[value];
                return bt;
            }
            else if (parsed)
            {
                return null;
            }
            else
            {
                string botsName = @string.ToUpper();

                foreach (var bt in BotManager.bots)
                {
                    if (botsName == bt.Player?.myPlayerData?.RealUsername.ToUpper())
                    {
                        return bt;
                    }

                }

            }
            return null;

        }
    }
}
