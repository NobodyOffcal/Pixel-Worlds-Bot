﻿using ArhiBots.Bots;
using ArhiBots.GUI;
using ArhiBots.GUI.Command_Handler;
using ArhiBots.Misc;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace ArhiBots
{
    public class Program
    {

        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;

        public static Random rand = new Random();
        public static Stopwatch UPTIME = new Stopwatch();
        static CommandHandler handler = new CommandHandler();
        static bool optionChosen = false;
        static bool GUI = false;
        static void Main()
        {
            
            Console.Title = "Arhi bots console";

            Logger.Log("Setting up aws services!");
            Task.Run(() =>
            {
                AWSRequests.Start();
                AWSRequests.ConnectCognito();
            });
            handler.SetupCommands();
            handler.StartConsoleMode();
            
            UPTIME.Start();
            Config.LoadSettings();
            
            Time.SetupTime();
            
            BotManager.Start();
            Console.ReadKey();
        }
        public static SampleOverlay? Overlay { get; private set; }
        public static async void StartGui()
        {
            if (SampleOverlay.GUIRUNNING) return;
            IntPtr consoleHandle = GetConsoleWindow();
            ShowWindow(consoleHandle, SW_HIDE);
            SampleOverlay.GUIRUNNING = true;
            using SampleOverlay ovr = new ();
            Overlay = ovr;
            await Overlay.Run();
            
        }
        
        public static void StopGUI()
        {

            Overlay?.End(true);


        }
    }
}