﻿using ArhiBots.Bots;
using ArhiBots.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Auto
{
    public class Fishing
    {
        public Bot bot;
        public Fishing(Bot bot) { this.bot = bot; }
        public FishingState fishingState;

    }
}
