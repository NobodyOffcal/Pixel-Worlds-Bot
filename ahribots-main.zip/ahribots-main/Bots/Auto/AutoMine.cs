﻿using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Pathfinding;
using ArhiBots.Structs;
using ImGuiNET;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots.Auto
{
    public class AutoMine
    {

        public Bot bot { get; set; }
        public bool Automine = false;

        public AutoMine(Bot bot) { this.bot = bot; }

        public List<PNode> autoMinePath = new List<PNode>();
        public MiningState miningState { get; set; }

        float miningSpeed = .185f;
        float miningTimer = 0f;
        float tpSpeed = 0.165f;
        bool teleport = true;

        public float estimatedCompletionTime = 0.0f;

        public List<Vector2i> Positions = new List<Vector2i>();
        
        public void AutoMineStart()
        {
            if (bot.world.WorldName != "MINEWORLD") return;
            autoMinePath = bot.Player.pathfind.GetBestMiningPath();
            miningState = MiningState.Moving;
            autoMinePath.RemoveAt(0);//
            GetEstimatedTimeOfCompletion();


        }

        public void ResetSomethings()
        {
            estimatedCompletionTime = 0.00f;
            JoinTimer = 0f;
            joinedMineStart = true;
        }

        public float GetEstimatedTimeOfCompletion()
        {
            float time = 0.0f;
            for (int i = 0; i < autoMinePath.Count; i++)
            {
                var block = bot.world.GetBlockType((Vector2i)autoMinePath[i]);

                switch (block)
                {
                    case BlockType.None:
                        time += tpSpeed;
                        break;
                    case BlockType.MiningSoil1:
                    case BlockType.MiningSoil2:
                    case BlockType.MiningSoil3:
                    case BlockType.MiningSoil4:
                    case BlockType.MiningSoil5:
                    case BlockType.MiningGemStoneTopaz:
                    case BlockType.MiningGemStoneEmerald:
                    case BlockType.MiningGemStoneSapphire:
                        time += 2 * miningSpeed;
                        break;


                    case BlockType.MiningRockSoft1:
                    case BlockType.MiningRockMedium1:
                    case BlockType.MiningRockHard1:
                    case BlockType.MiningRockHard2:
                    case BlockType.MiningRockHard3:
                    case BlockType.MiningWoodBlock1:
                    case BlockType.MiningGemStoneRuby:
                        time += 3 * miningSpeed;
                        break;

                    case BlockType.MiningBedrock1:
                    case BlockType.MiningBedrock2:
                    case BlockType.MiningBedrock3:
                    case BlockType.MiningGemStoneDiamond:
                        time += 4 * miningSpeed;
                        break;

                    case BlockType.Bedrock:
                    case BlockType.PortalMineExit:
                    case BlockType.PortalMiningEntry:
                        time += 0;
                        break;
                }
            }
            estimatedCompletionTime = time;
            return time;
        }




        public void MineUpdate()
        {
            JoinMine();
            ActualAuto();
        }

        float JoinTimer = 0f;
        float ResetPathTimer = 0f;
        Vector2i lastPos = new();
        public bool joinedMineStart = false;
        void JoinMine()
        {
            if (Automine == false)
            {
                JoinTimer = 0;
                return;
            }
            if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
            {
                
                
                return;
            }

            JoinTimer += Time.deltaTime;
            if (JoinTimer >= 25f)
            {
                if (bot.world.WorldName != "MINEWORLD")
                {
                    bot.Player.JoinHighestPossibleMine();
                    JoinTimer = 0f;
                    return;
                }

                if(joinedMineStart && bot.world.WorldName == "MINEWORLD")
                {
                    if(!bot.world.worldLoaded)
                    {
                        JoinTimer = 15f;
                        return;
                    }
                    joinedMineStart = false;
                    AutoMineStart();
                }

                JoinTimer = 0f;
            }
        }

        void ActualAuto()
        {
            if (bot.world.WorldName != "MINEWORLD") return;

            if (miningState == MiningState.None)
            {
                return;
            }

            if (autoMinePath == null) return;

            if (autoMinePath.Count <= 0)
            {
                return;
            }

            miningTimer += Time.deltaTime;

            if (miningTimer >= miningSpeed && autoMinePath.Count > 0)
            {
                miningTimer = 0f;
                

                var block = bot.world.GetBlockType(autoMinePath[0]);
                if (autoMinePath.Count <= 2)
                {
                    if (block == BlockType.PortalMineExit)
                    {
                        joinedMineStart = true;
                        miningState = MiningState.None;
                        
                        bot.OutgoingMessages.AddOneMessageToList(new()
                        {
                            ["ID"] = "GMExit",
                            ["x"] = autoMinePath[0].x,
                            ["y"] = autoMinePath[0].y
                        });
                        autoMinePath.Clear();

                        return;
                    }
                }


                if (!bot.Player.pathfind.IsTileWalkable(autoMinePath[0]))
                {
                    bot.WorldController.MineBlockWithTool(0, false, autoMinePath[0], BlockType.SoilBlock, false);
                    return;
                }
                else
                {
                    bot.Player.CurrentPosition = PositionConversions.ConvertMapPointToPlayersWorldPointFromFeet(autoMinePath[0]);



                    autoMinePath.RemoveAt(0);
                    GetEstimatedTimeOfCompletion();
                    if (teleport)
                    {
                        if (bot.Player.pathfind.IsTileWalkable(autoMinePath[0]))
                            miningTimer += miningSpeed - tpSpeed;
                        else
                        {
                            bot.WorldController.MineBlockWithTool(0, false, autoMinePath[0], BlockType.SoilBlock, false);
                        }
                    }
                }
            }
        }
    
        public void StopAutoMine()
        {

            bot.auto.autoMine.joinedMineStart = false;
            bot.auto.autoMine.Automine = false;
            bot.auto.autoMine.miningState = MiningState.None;
            bot.auto.autoMine.autoMinePath.Clear();
        }
    
    }



    public enum MiningState
    {
        None,
        Moving,
        Breaking
    }
}
