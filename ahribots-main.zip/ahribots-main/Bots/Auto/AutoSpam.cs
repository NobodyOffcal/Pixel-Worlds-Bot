﻿using ArhiBots.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots.Auto
{
    public class AutoSpam
    {
        public Bot bot { get; set; }
        public AutoSpam(Bot bot) { this.bot = bot; }
        public SpammingState state = SpammingState.None;
        public bool Spam { get { return state == SpammingState.Spamming; } }

        public void StartStop()
        {
            state = state == SpammingState.None ? SpammingState.Spamming : SpammingState.None;
            
        }

        public void RequestRandomWorld()
        {
            if (!Spam) { return; }
            //bot.OutgoingMessages.RequestRandomWorld();
            bot.OutgoingMessages.SendTryToJoinMessage("diamatti\n");
            spawned = false;
            interpolation = 0.0f;
        }


        public void WorldJoinResult(WorldJoinResult result)
        {
            if (!Spam) { return; }
            if (result != ArhiBots.Constants.WorldJoinResult.Ok && bot.status == PlayerConnectionStatus.InMenus)
            {
                RequestRandomWorld();
            }
        }
        public bool spawned = false;
        public float interpolation = 0.00f;

        public void OnUpdate()
        {
            

            if (!Spam) return;

            if (bot.status != PlayerConnectionStatus.InRoom)
            {
                return;
            }

            if (!spawned && interpolation >= 5f)
            {
                OnSpawn();
            }

            if (interpolation >= 30 && spawned)
            {
                OnSpawn();
            }
            interpolation += Time.deltaTime;
        }
        
        public void OnSpawn()
        {
            if (!Spam) { return; }
            
            
            spawned = true;
            interpolation = 0;


            bot.OutgoingMessages.SendTryToJoinMessage("diamatti\n");

            spawned = false;
            interpolation = 0.0f;
            // bot.Player.LeaveWorld();
        }
    }

    public enum SpammingState : byte
    {
        None,
        Spamming
    }
}
