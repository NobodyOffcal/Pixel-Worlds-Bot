﻿using ArhiBots.Bots;
using ArhiBots.Bots.Auto;
using ImGuiNET;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Auto
{
    public class  Automain
    {
        public Bot bot { get; set; }
        public AutoMine autoMine { get; set; }
        public Autofarm autoFarm { get; set; }
        public AutoDrop autoDrop { get; set; }
        public AutoSpam autoSpam { get; set; }
        public AutoMannequin autoMannequin { get; set; }
        public Automain(Bot bot) { 
            this.bot = bot;
            autoMannequin = new AutoMannequin(bot);
            autoMine = new AutoMine(bot);
            autoFarm = new Autofarm(bot);
            autoSpam = new AutoSpam(bot);   
            autoDrop = new AutoDrop(bot);   
        }


        public void PlayerUpdate()
        {
            bot.auto.autoFarm.Update();
            bot.auto.autoMine.MineUpdate();
            bot.auto.autoDrop.Update();
            bot.auto.autoSpam.OnUpdate();
            bot.botHelper.Update();
        }

        public bool Autoing()
        {
            if (autoDrop.drop) return true;
            if (autoFarm.auto) return true;
            if (autoMine.Automine) return true;

            return false;
        }


        public void Stop()
        {
            autoMine.StopAutoMine();
            autoFarm.auto = false;
        }
    }
}
