﻿using ArhiBots.Constants;
using ArhiBots.Misc;

namespace ArhiBots.Bots.Auto
{
    public class AutoDrop
    {
        public Bot bot;
        public AutoDrop(Bot bot) { this.bot = bot; }

        public bool drop = false;
        public float dropSpeed = 1.6f;

        
        float interpolation = 0f;
        bool droppedSomething = false;
        public void StartDropping()
        {
            if (bot.status != PlayerConnectionStatus.InRoom)
            {
                return;
            }
            if (drop) return;
            if (bot.world.WorldName.ToUpper() == "MINEWORLD") return;
            droppedSomething = false;
            drop = true;
        }

        public void Update()
        {
            if (!drop) return;
            
            if (bot.status != PlayerConnectionStatus.InRoom)
            {
                return;
            }

            interpolation += Time.deltaTime;
            if (interpolation >= dropSpeed)
            {
                interpolation = 0f;
                droppedSomething = false;
                foreach (var item in bot.Player.myPlayerData.GetInventoryAsOrderedByInventoryItemType())
                {
                    /*if (ConfigData.IsMiningGem(item.blockType) || item.blockType == BlockType.ConsumableMineKeyLevel5)
                    {
                        if (!ConfigData.DoesBlockHaveCollider(bot.world.GetBlockType(bot.Player.GetNextUNSAFEPlayerPositionBasedOnLookDirection())))
                        {
                            bot.Player.DropItems(item, bot.Player.myPlayerData.GetCount(item));
                        }
                        else
                        {
                            if (bot.Player.direction == Direction.Left)
                            {
                                bot.Player.direction = Direction.Right;
                            }
                            else if (bot.Player.direction == Direction.Right)
                            {
                                bot.Player.direction = Direction.Left;
                            }
                        }
                        
                        droppedSomething = true;
                        break;
                    }*/

                    if (item.blockType == BlockType.ConsumableMessageBottleNote)
                    {
                        if (!ConfigData.DoesBlockHaveCollider(bot.world.GetBlockType(bot.Player.GetNextUNSAFEPlayerPositionBasedOnLookDirection())))
                        {
                            bot.Player.DropItems(item, bot.Player.myPlayerData.GetCount(item));
                        }
                        else
                        {
                            if (bot.Player.direction == Direction.Left)
                            {
                                bot.Player.direction = Direction.Right;
                            }
                            else if (bot.Player.direction == Direction.Right)
                            {
                                bot.Player.direction = Direction.Left;
                            }
                        }
                        droppedSomething = true;
                        break;
                    }
                }

                if (!droppedSomething)
                {
                    drop = false;
                    Logger.Log("Completed dropping!");
                }

            }
        }
    }
}
