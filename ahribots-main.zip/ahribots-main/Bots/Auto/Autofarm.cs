﻿using ArhiBots.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ArhiBots.Structs;
using System.Threading.Tasks;
using ArhiBots.Misc;

namespace ArhiBots.Bots.Auto
{
    public class Autofarm
    {
        public Bot bot;
        public Autofarm(Bot bot) { this.bot = bot; }

        public bool auto = false;
        public float farmSpeed = 0.3f;

        public BlockType block;

        public void SetBlockType(BlockType block) => this.block = block;

        float interpolation = 0f;
        bool setBlock = false;

        public void Update() {
            if (!auto) return; 
            interpolation += Time.deltaTime;
            Vector2i farmingSpot = new (bot.Player.currentPlayerMapPoint.x, bot.Player.currentPlayerMapPoint.y + 1);

            if (interpolation > farmSpeed) {
                interpolation = 0;

                if (bot.world.GetBlockType(farmingSpot) != BlockType.None)
                {
                    bot.WorldController.MineBlockWithTool(0, false, farmingSpot, BlockType.None, false);
                    setBlock = true;
                }
                else
                {
                    bot.WorldController.SetBlockWithTool(block, farmingSpot, 0);
                }
            }
        
        }
    }
}
