﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots.Auto
{
    public class AutoMannequin
    {
        public Bot bot { get; set; }
        public AutoMannequin(Bot bot) {
            this.bot = bot;
        }

        public bool AutoSwap = false;

        public void Start()
        {
            AutoSwap = true;
            bot.world.SwapClothesWithMannequin(bot.Player.currentPlayerMapPoint);
        }

        public void SwapAgain()
        {
            if (AutoSwap)
            bot.world.SwapClothesWithMannequin(bot.Player.currentPlayerMapPoint);
        }
    }
}
