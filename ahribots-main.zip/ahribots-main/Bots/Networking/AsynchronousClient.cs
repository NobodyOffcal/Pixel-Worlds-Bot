﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using ArhiBots.Bots;
using ArhiBots.Misc;

namespace ArhiBots.Networking
{
    public class AsynchronousClient
    {


        private int port { get { return bot.address.port;  } }

        public Bot bot;
        public NetworkClient networkClient;
        public OutgoingMessages OM;

        public string serverAddress { get { return bot.address.serverAddress; } }
        public string serverReconnectAddress = null;

        private ManualResetEvent connectDone = new ManualResetEvent(initialState: false);

        public Socket socket;

        private readonly object sendLock = new object();

        private readonly object socketLock = new object();

        private readonly object packetsLock = new object();

        public bool connected;

        private List<byte[]> packetsForNetworkClient = new List<byte[]>();

        public bool useEncryption = false;

        public byte[] ourPrivateRSAKey;

        public byte[] commonAESKey;

        public byte[] commonAESIV;

        public bool StartClient(Bot bot)
        {
            
            this.bot = bot;
            this.OM = bot.OutgoingMessages;
            this.networkClient = bot.NetworkClient;
            packetsForNetworkClient.Clear();
            Logger.Log(serverAddress + " " + port);
            try
            {
                string hostNameOrAddress = serverAddress;
                Logger.Log(hostNameOrAddress);
                if (bot.address.serverReconnectAddress != null)
                {
                    hostNameOrAddress = bot.address.serverReconnectAddress;
                }
                bot.address.serverReconnectAddress = null;
                Logger.Log(hostNameOrAddress);

                IPHostEntry hostEntry = Dns.GetHostEntry(hostNameOrAddress);
                IPAddress address = hostEntry.AddressList[0];
                for (int i = 0; i < hostEntry.AddressList.Length; i++)
                {
                    if (hostEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                    {
                        address = hostEntry.AddressList[i];
                        break;
                    }
                }
                IPEndPoint remoteEP = new(address, 10001);
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                {
                    NoDelay = true
                };
                socket.BeginConnect(remoteEP, ConnectCallback, socket);
                bool flag = connectDone.WaitOne(new TimeSpan(0, 0, 2));
                connectDone.Reset();
                if (flag)
                {
                    return true;
                }
                Logger.Log("Couldn't connect to server");
                StartClient(this.bot);
            }
            catch (Exception ex)
            {
                Logger.Log(ex.ToString());
            }
            return false;
        }

        private void ConnectCallback(IAsyncResult ar)
        {
            lock (socketLock)
            {
                try
                {
                    Socket socket = (Socket)ar.AsyncState;
                    socket.EndConnect(ar);
                    connectDone.Set();
                    connected = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message.ToString());
                }
            }
        }

        private void Receive(Socket client)
        {
            lock (socketLock)
            {
                try
                {
                    StateObject stateObject = new()
                    {
                        workSocket = client
                    };
                    client.BeginReceive(stateObject.buffer, 0, 1024, SocketFlags.None, ReceiveMessageCallback, stateObject);
                }
                catch (Exception ex)
                {
                    Logger.Log(ex.ToString());
                }
            }
        }

        private void ReceiveMessageCallback(IAsyncResult ar)
        {
            lock (socketLock)
            {
                try
                {
                    StateObject stateObject = (StateObject)ar.AsyncState;
                    Socket workSocket = stateObject.workSocket;
                    int num = workSocket.EndReceive(ar);
                    if (num <= 0)
                    {
                        return;
                    }
                    if (stateObject.data == null)
                    {
                        int num2 = BitConverter.ToInt32(stateObject.buffer, 0);
                        stateObject.data = new byte[num2 - 4];
                        Array.Copy(stateObject.buffer, 4, stateObject.data, 0, num - 4);
                        stateObject.bytesReadToData = num - 4;
                    }
                    else
                    {
                        Array.Copy(stateObject.buffer, 0, stateObject.data, stateObject.bytesReadToData, num);
                        stateObject.bytesReadToData += num;
                    }
                    if (stateObject.bytesReadToData == stateObject.data.Length)
                    {
                        if (useEncryption)
                        {
                        }
                        lock (packetsLock)
                        {
                            packetsForNetworkClient.Add(stateObject.data);
                            return;
                        }
                    }
                    workSocket.BeginReceive(stateObject.buffer, 0, 1024, SocketFlags.None, ReceiveMessageCallback, stateObject);
                }
                catch (Exception ex)
                {
                    Logger.Log(Logger.LogType.Error, ex.ToString());
                }
            }
        }

        public bool SendMessages()
        {
            
            if (socket == null)
            {
                return false;
            }
            if (!socket.Connected)
            {
                return false;
            }
            lock (sendLock)
            {
                if (!OM.AreThereAnyMessages())
                {
                    return false;
                }
                MemoryStream memoryStream = new();
                using (BinaryWriter binaryWriter = new(memoryStream))
                {
                    byte[] array = OM.TurnMessagesToBytesAndConsumeThem();
                    binaryWriter.Write(array.Length + 4);
                    binaryWriter.Write(array);
                }
                byte[] array2 = memoryStream.ToArray();
                if (useEncryption)
                {
                }
                socket.BeginSend(array2, 0, array2.Length, SocketFlags.None, SendCallback, socket);
            }
            bot.NetworkClient.pingTimer.Restart();
            return true;
        }

        private void SendCallback(IAsyncResult ar)
        {
            lock (socketLock)
            {
                try
                {
                    Socket socket = (Socket)ar.AsyncState;
                    int num = socket.EndSend(ar);
                    Receive(socket);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

        public bool CheckSocketConnection()
        {
            lock (socketLock)
            {
                try
                {
                    if (socket == null)
                    {
                        connected = false;
                        return connected;
                    }
                    bool polled = socket.Poll(1000, SelectMode.SelectRead);
                    bool avaliable = socket.Available == 0;
                    if (polled && avaliable)
                    {
                        //Logger.Log("Socket not connected anymore!");
                        connected = false;
                        return connected;
                    }
                    connected = true;
                    return connected;
                }
                catch (Exception ex)
                {
                    Logger.Log("Exception checking socket connection: " + ex.Message);
                    connected = false;
                    return connected;
                }
            }
        }

        public void CloseConnection()
        {
            if (socket != null && connected)
            {
                try
                {
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }
                catch
                {
                }
            }
        }

        public void DetectNetworkChange()
        {
            if (socket == null || !connected)
            {
                return;
            }
            IPEndPoint iPEndPoint = socket.LocalEndPoint as IPEndPoint;
            bool flag = false;
            NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface networkInterface in allNetworkInterfaces)
            {
                IPInterfaceProperties iPProperties = networkInterface.GetIPProperties();
                foreach (UnicastIPAddressInformation unicastAddress in iPProperties.UnicastAddresses)
                {
                    if (unicastAddress.Address.Equals(iPEndPoint.Address))
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if (!flag)
            {
                Logger.Log("Network not found, disconnect");
                CloseConnection();
            }
        }

        public bool CheckIfThereArePacketsForClient()
        {
            lock (packetsLock)
            {
                return packetsForNetworkClient.Count > 0;
            }
        }

        public byte[] GetAndConsumeFirstPacketForClient()
        {
            lock (packetsLock)
            {
                byte[] array = packetsForNetworkClient[0];
                packetsForNetworkClient.RemoveAt(0);
                return array;
            }
        }

        public void SetPrivateRSAKey(byte[] newPrivateRSAKey)
        {
            ourPrivateRSAKey = newPrivateRSAKey;
        }

        public byte[] GetPrivateRSAKey()
        {
            return ourPrivateRSAKey;
        }

        public void SetAesValueAndStartToUseEncryption(byte[] newAesKey, byte[] newAesIV)
        {
            commonAESKey = newAesKey;
            commonAESIV = newAesIV;
            useEncryption = true;
        }
    }

    public class StateObject
    {
        public Socket workSocket;

        public const int BufferSize = 1024;

        public byte[] buffer = new byte[1024];

        public byte[] data;

        public int bytesReadToData;
    }
}