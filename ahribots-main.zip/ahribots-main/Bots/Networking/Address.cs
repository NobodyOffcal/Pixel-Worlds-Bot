﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Networking
{
    public class Address
    {
        public string serverAddress = "prod.gamev83.portalworldsgame.com";
        //public string serverAddress = "127.0.0.1";
        public string serverReconnectAddress = null;
        //public int port = 10001;
        public int port = 10001;
    }
}
