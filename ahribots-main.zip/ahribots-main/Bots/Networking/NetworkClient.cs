﻿using ArhiBots.Bots;
using ArhiBots.Bots.Auto;
using ArhiBots.Constants;
using ArhiBots.Discord_bot;
using ArhiBots.Misc;
using ArhiBots.Structs;
using ClickableTransparentOverlay.Win32;
using Google.OrTools.ConstraintSolver;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Numerics;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Vortice.DXGI;

namespace ArhiBots.Networking
{
    public class NetworkClient : Behaviour
    {
        public AsynchronousClient acClient;
        public OutgoingMessages outgoingMessages;
        public string currentWorld = "juujaa_2";

        public string currentWorldEntryPointID = string.Empty;

        public Bot bot;
        public KukouriTime kukouriTime = new();
        public WorldLoader WorldLoader;

        public PlayerConnectionStatus playerConnectionStatus;

        public bool tcpConnectionOpenedCorrectly;

        public bool isActiveAndEnabled = true;

        private bool areWeSending = true;

        private float lastSendTimeTimeStamp;

        private int pingCounter;

        private int networkConnectionFailAmounts;

        private DateTime lastPacketsSendTime = DateTime.MinValue;

        public string joinWorldOnConnect = null;

        public bool clientUpdateIsRequired;

        public bool clientIsNewerThanServer;

        public bool restartGameIfNetworkClientIsRemoved = true;

        private DateTime nextTimeForServerTimeSync = DateTime.MaxValue;

        private readonly int timeBetweenTimeSyncsInSeconds = 120;

        public Action<WorldJoinResult> tryToJoinSuccess;
        public Action<WorldJoinResult> tryToJoinFailed;

        public float ping = 0f;

        public Stopwatch pingTimer = new Stopwatch();


        #region Events
        public event EventHandler<BsonEventArgs> HandledGetPlayerData;
        public event EventHandler<BsonEventArgs> HandledIncorrectUser;
        #endregion

        public NetworkClient(Bot bot)
        {
            this.bot = bot;
            
        }


        private void HandleMessages(BSONObject messages)
        {
            ping = (float)pingTimer.ElapsedMilliseconds;
            pingTimer.Stop();
            
            for (int i = 0; i < messages["mc"].int32Value; i++)
            {
                BSONObject bson = messages["m" + i] as BSONObject;

                string id = bson["ID"].stringValue;

                if (playerConnectionStatus == PlayerConnectionStatus.InRoom)
                {
                    if (bson.ContainsKey("U"))
                    {
                        try
                        {
                            string U = bson["U"].stringValue;
                            for (int j = 0; j < Staff.staff.Count; j++)
                            {
                                if (Staff.staff.ContainsKey(U))
                                {
                                    // Mod detected
                                    bot.Player.WarpFromWorldToWorld(ConfigData.GenRandomWorld());
                                    bot.botHelper.Casino.ModDetected();
                                }
                            }
                        }
                        catch (Exception e) { }
                    }
                }
                
                
                switch (id)
                {
                    case "VChk":
                        HandleVersionCheck(bson);
                        break;

                    case "GPd":
                        HandlePlayerData(bson);
                        outgoingMessages.RequestServerTime();
                        break;

                    case "GWC":
                        HandleGetWorldCreate(bson);
                        break;

                    case "TTjW":
                        HandleWorldJoinMessage(bson);
                        break;

                    case "OoIP":
                        HandleOtherOwnerIPMessage(bson);
                        break;

                    case "rOP":
                        RequestOtherPlayersCompleted();
                        break;

                    case "MWli":
                        if (bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.Players)
                        {
                            bot.botHelper.Casino.MenuWorldLimitInfo(bson["Ct"].int32Value, bson["WN"].stringValue);
                        }
                        break;

                    case "DoPSE":
                        HandleDoPlayerSummonEffect(bson);
                        break;

                    case "CI":
                        ConvertItemConfirmed(bson);
                        break;

                    case "RC":
                        HandleRemoveCollectableMessage(bson);
                        break;
                    case "C":
                        HandlePlayerItemCollectConfirmed(new CollectableData(bson));
                        break;
                    case "nCo":
                        bot.world.collectables.Add(new CollectableData(bson));
                        break;
                    case "AnP":
                        HandleAddOtherPlayersMessage(bson);
                        break;
                    case "mP":
                        HandleOtherPlayerPositionMessage(bson);
                        break;
                    case "PSicU":
                        HandlePlayerStatusIconUpdate(bson);
                        break;
                    case "PL":
                        HandlePlayerLeft(bson);
                        break;
                    case "HB":
                        HandleHitBlock(bson);
                        break;
                    case "DB":
                        HandleBlockDestroyedMessage(bson);
                        break;
                    case "SB":
                        HandleSetBlockMessage(bson);
                        break;
                    case "WIU":
                        HandleWorldItemUpdate(bson);
                        break;
                    case "RIi":
                        HandleRIi(bson);
                        break;
                    case "RecycleMiningGem":
                        HandleRecycleMiningGem(bson);
                        break;

                    case "TTSWi":
                        HandleTTSWi(bson);
                        break;

                    case "AMI":
                        HandleAmi(bson);
                        break;

                    case "LW":
                        UpdateConnectionStatus(PlayerConnectionStatus.InMenus);
                        bot.auto.autoSpam.RequestRandomWorld();
                        break;

                    case "ST":
                        {
                            int num = (int)(DateTime.UtcNow - lastPacketsSendTime).TotalMilliseconds;
                            if (num < ConfigData.clientServerLeewayTimeInMilliseconds)
                            {
                                kukouriTime.SetTimeOffset(kukouriTime.ParseServerTimeFromBSON(bson), num);
                                nextTimeForServerTimeSync = DateTime.UtcNow.AddSeconds(timeBetweenTimeSyncsInSeconds);
                            }
                            else
                            {
                                outgoingMessages.RequestServerTime();
                            }
                            break;
                        }

                    case "Trade":
                        bot.botHelper.Casino.TradePacketReceived(bson);
                        break;

                    case "BGM":
                        break;

                    case "AI":

                        break;

                    case "GetWorldError":
                        GetWorldError(bson);
                        break;

                    case "KErr":
                        Logger.Log(Logger.LogType.Error,"RECEIVED KICK ERROR");
                        bot.Player.pathfind.Reset();
                        Reconnect();
                        break;

                    case "AC":
                        bot.UpdatePrefix();
                        Reconnect();
                        break;

                    case "SWD":
                        HandleSpecialWorldDataPacket(bson);
                        break;

                    case "p":
                    case "PPA":
                        break;

                    default:
                        Logger.Log($"Client doesn't support message: {id}");
                        break;

                }

                if (!Logger.BlockServerToLog.Contains(id))
                {
                    Logger.Log("Server");
                    Logger.ReadBSON(bson);
                }
                

            }
        }

        private void HandleTTSWi(BSONObject bson)
        {
            bot.OutgoingMessages.PlayerStatusIconUpdate(StatusIconType.InMenus);
            if (bot.world.SwapWithMannequin && bson["S"].boolValue)
            {
                bot.world.SwapClothesWithMannequin(new Vector2i(bson["x"].int32Value, bson["y"].int32Value));
            }

        }

        private void HandleAmi(BSONObject bson)
        {
            if (playerConnectionStatus != PlayerConnectionStatus.InRoom)
            {
                return;
            }
            List<int> IK = new List<int>();
            List<int> rI = new();

            if (bson.ContainsKey("rI"))
                rI = bson["rI"].int32ListValue;
            if (bson.ContainsKey("IK"))  
                IK = bson["IK"].int32ListValue;
            foreach (int i in rI)
            {

                InventoryKey key = InventoryKey.IntToInventoryKey(i);
                if (bot.Player.IsItemEquiped(key.blockType))
                    bot.Player.ChangeWearable(key.blockType);
                bot.Player.myPlayerData.RemoveItemsFromInventory(key, 1);
            }
            foreach (int i in IK)
            {
                InventoryKey key = InventoryKey.IntToInventoryKey(i);
                bot.Player.myPlayerData.AddItemToInventory(key.blockType, key.itemType, 1);
                bot.Player.ChangeWearable(key.blockType);
            }

            

            
        }

        private void HandleRIi(BSONObject bson)
        {
            BSONObject ri = bson["rI"] as BSONObject;
            bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey((BlockType)ri["BlockType"].int32Value,
                            (InventoryItemType)ri["InventoryType"].int32Value),
                            (short)ri["Amount"].int32Value);
        }

        private void HandleDoPlayerSummonEffect(BSONObject bson)
        {
            string user = bson["U"].stringValue;
            int x = bson["PX"].int32Value;
            int y = bson["PY"].int32Value;

            if (user == bot.Player.myPlayerData.playerId)
            {
                bot.Player.CurrentPosition = PositionConversions.ConvertMapPointToPlayersWorldPointFromFeet(new(x, y));
                bot.OutgoingMessages.ClearRecentMapPoints();
                bot.Player.SendMovementOrPingToServerIfNeeded();
                bot.Player.SendMovementOrPingToServerIfNeeded();
                return;
            }   

            //bot.NetworkPlayers.HandlePositionMessage(user, new Vector2(x, y), AnimationNames.Idle, Direction.Center);
        }

        private void HandleWorldItemUpdate(BSONObject bson)
        {
            BSONObject WiB = bson["WiB"] as BSONObject;
            int x = bson["x"].int32Value;
            int y = bson["y"].int32Value;

            bot.world.worldsItemBson[x][y] = WiB;

            if (bson.ContainsKey("swap"))
            {
                if (bson["U"].stringValue == bot.Player.myPlayerData.playerId)
                    bot.auto.autoMannequin.SwapAgain();
            }

        }

        public override void Awake()
        {
            Init();
            restartGameIfNetworkClientIsRemoved = true;
        }


        public bool Init()
        {
            outgoingMessages = bot.OutgoingMessages;
            WorldLoader = new(this);
            
            this.WorldLoader.JoinWorldOnConnect(bot.worldOnLoad);
            

            if (acClient != null)
            {
                acClient.CloseConnection();
                acClient = null;
            }
            acClient = new AsynchronousClient();
            if (!acClient.StartClient(bot))
            {
                UpdateConnectionStatus(PlayerConnectionStatus.ConnectionFailed);
                return false;
            }
            UpdateConnectionStatus(PlayerConnectionStatus.TcpConnectionOpened);
            tcpConnectionOpenedCorrectly = true;
            StartGameVersionCheck();


            return tcpConnectionOpenedCorrectly;
        }
        public void Disconnect()
        {
            tcpConnectionOpenedCorrectly = false;
            outgoingMessages.ClearMessages();
            acClient?.CloseConnection();
            UpdateConnectionStatus(PlayerConnectionStatus.NotConnected);
        }

        public bool Reconnect()
        {
            pingTimer.Restart();
            tcpConnectionOpenedCorrectly = false;
            
            outgoingMessages.ClearMessages();
            // ClearMainMenuNetworkHandlers();
            acClient?.CloseConnection();
            UpdateConnectionStatus(PlayerConnectionStatus.NotConnected);

            return Init();
        }
       


        public override void Update()
        {
            if (pingTimer.Elapsed.Seconds >= 30)
            {
                bot.Reconnect();
                return;
            }
            if (!tcpConnectionOpenedCorrectly)
            {
                return;
            }
            if (!acClient.CheckSocketConnection())
            {
                networkConnectionFailAmounts++;
                if (networkConnectionFailAmounts > 60)
                {
                    DoHardReconnect();
                }
                return;
            }

            
            networkConnectionFailAmounts = 0;
            pingCounter++;
            if (playerConnectionStatus == PlayerConnectionStatus.JoiningRoom || pingCounter > 45)
            {
                pingCounter = 0;
                outgoingMessages.SendPing();
            }
            
            if (nextTimeForServerTimeSync != DateTime.MaxValue && DateTime.UtcNow > nextTimeForServerTimeSync)
            {
                nextTimeForServerTimeSync = DateTime.MaxValue;
                outgoingMessages.RequestServerTime();
            }
            if (areWeSending)
            {
                if (acClient.SendMessages())
                {
                    
                    areWeSending = false;
                    lastSendTimeTimeStamp = Time.realtimeSinceStartup;
                    SetLastPacketsSendTime();
                }
            }
            else
            {
                if (acClient.CheckIfThereArePacketsForClient())
                {
                    BSONObject messages = SimpleBSON.Load(acClient.GetAndConsumeFirstPacketForClient());
                    HandleMessages(messages);
                    areWeSending = true;
                    lastSendTimeTimeStamp = float.MaxValue;
                }
                else if (lastSendTimeTimeStamp < Time.realtimeSinceStartup - (float)15)
                {
                    DoHardReconnect();
                }
               
            }


            if (joinWorldOnConnect != null && playerConnectionStatus == PlayerConnectionStatus.InMenus)
            {
                outgoingMessages.SendTryToJoinMessage(joinWorldOnConnect);
                joinWorldOnConnect = null;
            }
        }

        public void DoHardReconnect()
        {
            tcpConnectionOpenedCorrectly = false;
            CloseConnection();
            outgoingMessages.ClearMessages();
        }

        private void SetLastPacketsSendTime()
        {
            lastPacketsSendTime = DateTime.UtcNow;
        }

        public bool IsConnected()
        {
            return acClient != null && acClient.CheckSocketConnection();
        }

        private void CloseConnection()
        {
            tcpConnectionOpenedCorrectly = false;
            UpdateConnectionStatus(PlayerConnectionStatus.NotConnected);
            try
            {
                if (acClient != null)
                {
                    acClient.CloseConnection();
                    acClient = null;
                }
            }
            catch
            {
                Logger.Log(Logger.LogType.Error, (object)"reconnect catch!!!!");
                this.Reconnect();
            }
        }

        private void StartGameVersionCheck()
        {
            outgoingMessages.SendGetGameVersionMessage();
            UpdateConnectionStatus(PlayerConnectionStatus.CheckingGameVersion);
        }




        public void UpdateConnectionStatus(PlayerConnectionStatus status)
        {
            playerConnectionStatus = status;
        }


        private void HandleVersionCheck(BSONObject currentMessage)
        {
            int version = currentMessage["VN"].int32Value;
            if (version > 96)
            {
                clientUpdateIsRequired = true;
                CloseConnection();
            }
            else if (version < 96)
            {
                clientIsNewerThanServer = true;
                CloseConnection();
            }
            else
            {
                //Logger.Log("Waiting for player data to be ready.");
                //this.StartCoroutine(WaitForIncognitoToBeReady());
                RequestPlayerData();
            }
        }

        private void RequestPlayerData()
        {
            string[] inf = bot.ident.GetLoginInfo();
            outgoingMessages.SendGetPlayerDataMessage(inf[0], inf[1]);
            bot.auto.autoMine.ResetSomethings();
        }



        /*private IEnumerator WaitForIncognitoToBeReady()
        {
            RequestPlayerData();
            while (bot.ident.IsIdReady() == UserIdentState.Nothing)
            {
                yield return (object)new WaitForSeconds(0.2f);
            }
            //RequestPlayerData();
            yield return null;
        }*/

        private void HandlePlayerData(BSONObject currentMessage)
        {
            bot.Player.myPlayerData.InitFromBson(currentMessage, bot);
            UpdateConnectionStatus(PlayerConnectionStatus.InMenus);
            HandledGetPlayerData?.Invoke(this, new BsonEventArgs(currentMessage));
        }

        private void HandleOtherOwnerIPMessage(BSONObject currentMessage)
        {
            Logger.Log(Logger.LogType.Info, "The world seems to be owned by another server, call there!");
            this.bot.address.serverReconnectAddress = currentMessage["IP"].stringValue;

            joinWorldOnConnect = currentMessage["WN"].stringValue;

            if (bot.auto.autoSpam.Spam)
            {
                bot.worldOnLoad = joinWorldOnConnect;
            }
            if (!Reconnect())
            {
                joinWorldOnConnect = null;
                Logger.Log(Logger.LogType.Debug, "Login seems to of failed?!");
            }
        }

        public void GetWorldError(BSONObject currentMessage)
        {
            WorldJoinResult worldJoinResult = (WorldJoinResult)currentMessage["JR"].int32Value;

            if (bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.DecayDate || bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.Players)
            {
                bot.botHelper.Casino.WorldJoinResponse(worldJoinResult);
            }

            this.UpdateConnectionStatus(PlayerConnectionStatus.InMenus);
        }

        private void HandleWorldJoinMessage(BSONObject currentMessage)
        {
            WorldJoinResult worldJoinResult = (WorldJoinResult)currentMessage["JR"].int32Value;
            //Utils.ReadBSON(currentMessage);
            Logger.Log(worldJoinResult.ToString());
            bot.auto.autoSpam.WorldJoinResult(worldJoinResult);
            if (bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.DecayDate || bot.botHelper.Casino.task == Discord_bot.Bot_helpers.Casino.CurrentTask.Players)
            {
                bot.botHelper.Casino.WorldJoinResponse(worldJoinResult);
            }


            if (worldJoinResult == WorldJoinResult.Ok)
            {
                if (tryToJoinSuccess != null)
                {
                    tryToJoinSuccess(worldJoinResult);
                    ClearTryToJoinActions();
                    return;
                }

                else
                {
                    if (bot.auto.autoSpam.Spam)
                    {
                        bot.OutgoingMessages.SendGetWorldMessage(currentMessage["WNd"].stringValue, "");
                        ClearTryToJoinActions();
                        return;
                    }
                }
            }
            else if (worldJoinResult == WorldJoinResult.TooManyPlayersInWorld)
            {
                //outgoingMessages.SendTryToJoinMessage(currentMessage["WN"].stringValue);
            }
            else
            {
                /*if (currentMessage.ContainsKey("BanPlayer"))
                {
                    StaticPlayer.playerData.banState = currentMessage[NetStrings.BanState];
                    int num = currentMessage["BanPlayer"];
                    if (num == 1 && StaticPlayer.playerData.banState.CompareTo("Universal") == 0)
                    {
                        StaticPlayer.playerData.isPlayerBanned = true;
                        StaticPlayer.playerData.banEndDate = new DateTime(currentMessage[NetStrings.Timestamp].int64Value);
                    }
                    else if (num == 1 && StaticPlayer.playerData.banState.CompareTo("World") == 0)
                    {
                        StaticPlayer.playerData.isPlayerBanned = true;
                        StaticPlayer.playerData.banEndDate = new DateTime(currentMessage[NetStrings.Timestamp].int64Value);
                    }
                    else
                    {
                        StaticPlayer.playerData.isPlayerBanned = false;
                        StaticPlayer.playerData.banEndDate = DateTime.MinValue;
                    }
                }
                else
                {
                    StaticPlayer.playerData.isPlayerBanned = false;
                    StaticPlayer.playerData.banEndDate = DateTime.MinValue;
                }
                if (currentMessage.ContainsKey("WarnPlayer") && currentMessage.ContainsKey(NetStrings.ReasonForWarning))
                {
                    StaticPlayer.playerData.reasonForWarning = currentMessage[NetStrings.ReasonForWarning].stringValue;
                }*/
                if (tryToJoinFailed != null)
                {
                    tryToJoinFailed(worldJoinResult);
                }
            }
            ClearTryToJoinActions();
        }

        private void RequestOtherPlayersCompleted()
        {
            UpdateConnectionStatus(PlayerConnectionStatus.InRoom);
            outgoingMessages.ReadyToPlay();

        }

        private void ClearTryToJoinActions()
        {
            tryToJoinSuccess = null;
            tryToJoinFailed = null;
        }

        private void HandleGetWorldCreate(BSONObject bson)
        {
            if (bot.world != null) bot.world = null;

            bot.world = new(bot);
            bot.world.InitFromBinary(bson[NetStrings.WorldKey].binaryValue, currentWorld);
        }

        private void HandleRemoveCollectableMessage(BSONObject bson)
        {
            bot.WorldController.world.RemoveCollectableIfPossible(bson["CollectableID"].int32Value);
        }

        private void HandleAddOtherPlayersMessage(BSONObject currentMessage)
        {
            bot.NetworkPlayers.AddNetworkPlayer(currentMessage);
        }

        private void HandleSetBlockMessage(BSONObject bson)
        {
            BlockType blockType = (BlockType)bson["BlockType"].int32Value;
            //string user = bson["U"].stringValue;
            int y = bson["y"].int32Value;
            int x = bson["x"].int32Value;

            bot.WorldController.SetBlock(new Vector2i(x, y), blockType);
        }

        private void HandleBlockDestroyedMessage(BSONObject bson)
        {
            BlockType blockType = (BlockType)bson["DBBT"].int32Value;
            string user = bson["U"].stringValue;
            int y = bson["y"].int32Value;
            int x = bson["x"].int32Value;
            bot.WorldController.DestroyBlock(new Vector2i(x, y), ConfigData.GetBlockTypeInventoryItemType(blockType));
        }


        private void HandleHitBlock(BSONObject message)
        {
            string userId = message["U"].stringValue;
            int x = message["x"].int32Value;
            int y = message["y"].int32Value;
        }

        private void ConvertItemConfirmed(BSONObject message)
        {
            if (message.ContainsKey("IK"))
            {
                InventoryKey key = InventoryKey.IntToInventoryKey(message["IK"].int32Value);

                bot.Player.myPlayerData.AddItemToInventory(key.blockType, key.itemType, 1);
                switch (key.blockType)
                {
                    case BlockType.ConsumableMineKeyLevel2:
                        bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey(BlockType.MiningNuggetBronze, InventoryItemType.Consumable), 100);
                        break;
                    case BlockType.ConsumableMineKeyLevel3:
                        bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey(BlockType.MiningNuggetSilver, InventoryItemType.Consumable), 100);
                        break;
                    case BlockType.ConsumableMineKeyLevel4:
                        bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey(BlockType.MiningNuggetGold, InventoryItemType.Consumable), 100);
                        break;
                    case BlockType.ConsumableMineKeyLevel5:
                        bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey(BlockType.MiningNuggetPlatinum, InventoryItemType.Consumable), 100);
                        break;
                    case BlockType.MiningDarkStone:
                        bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey(BlockType.MiningNuggetDark, InventoryItemType.Consumable), 100);
                        break;
                }
            }
            

        }

        public void HandleRecycleMiningGem(BSONObject bson)
        {
            if (bson.ContainsKey("S"))
            {
                if (bson["S"].boolValue)
                {
                    short amt = (short)bson["Amt"].int32Value;
                    BlockType bt = (BlockType)bson["BT"].int32Value;

                    bot.Player.myPlayerData.RemoveItemsFromInventory(new InventoryKey(bt, InventoryItemType.Consumable), amt);
                }
            }
        }

        private void HandleSpecialWorldDataPacket(BSONObject currentMessage)
        {

            SpecialWorldDataType specialWorldDataType = (SpecialWorldDataType)currentMessage["SWDt"].int32Value;
            SpecialWorldDataEvent specialWorldDataEvent = (SpecialWorldDataEvent)currentMessage["SWDe"].int32Value;

            if (specialWorldDataType == SpecialWorldDataType.GeneratedMineSpecialWorldData)
            {
                if (specialWorldDataEvent == SpecialWorldDataEvent.PlayerComplete)
                {
                    
                    if (currentMessage.ContainsKey("CDat"))
                    {
                        BSONObject CDat = currentMessage["CDat"] as BSONObject;
                        bot.Player.myPlayerData.AddItemToInventory((BlockType)CDat["BlockType"].int32Value,
                        (InventoryItemType)CDat["InventoryType"].int32Value,
                        (short)CDat["Amount"].int32Value);
                    }

                    if (currentMessage.ContainsKey("CDataA"))
                    {
                        BSONObject CDataA = currentMessage["CDataA"] as BSONObject;
                        bot.Player.myPlayerData.AddItemToInventory((BlockType)CDataA["BlockType"].int32Value,
                            (InventoryItemType)CDataA["InventoryType"].int32Value,
                            (short)CDataA["Amount"].int32Value);
                    }

                    bot.Player.WarpFromWorldToWorld(bot.Player.previousWorldName);
                    
                   

                }
            }
        }

        private void HandleOtherPlayerPositionMessage(BSONObject currentMessage)
        {
            string userId = currentMessage["U"].stringValue;
            Vector2 newPos = new((float)currentMessage["x"].doubleValue, (float)currentMessage["y"].doubleValue);
            long time = currentMessage["t"].int64Value;
            AnimationNames a = (AnimationNames)currentMessage["a"].int32Value;
            Direction d = (Direction)currentMessage["d"].int32Value;

            bot.NetworkPlayers.HandlePositionMessage(userId, newPos, a, d);
        }

        private void HandlePlayerItemCollectConfirmed(CollectableData collectable)
        {
            
            this.bot.Player.ActualCollectedItem(collectable);
        }

        private void HandlePlayerStatusIconUpdate(BSONObject currentMessage)
        {
            string userId = currentMessage["U"].stringValue;
            StatusIconType icon = (StatusIconType)currentMessage["SIc"].int32Value;

            bot.NetworkPlayers.HandlePlayerStatusIconUpdate(userId, icon);
        }

        private void HandlePlayerLeft(BSONObject currentMessage)
        {
            bot.NetworkPlayers.PlayerLeft(currentMessage["U"].stringValue);
        }
    }
}
