﻿using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Structs;
using ClickableTransparentOverlay.Win32;
using SharpGen.Runtime.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vortice.Mathematics;
namespace ArhiBots.Networking
{
    public class OutgoingMessages
    {
        private List<BSONObject> messagesToSend = new();
        private readonly object messagesLock = new();
        
        private BSONObject myPosMessage = new();
        private List<Vector2i> recentMapPoints = new();
        private readonly object mapPointsLock = new();

        private BSONObject pingMessage = new() { ["ID"] = "p" };



        public Bot bot;
        public OutgoingMessages(Bot bot)
        {
            this.bot = bot;
        }

        public bool AreThereAnyMessages()
        {
            lock (messagesLock)
            {
                return messagesToSend.Count > 0;
            }
        }

        public void AddOneMessageToList(BSONObject toAdd)
        {
            lock (messagesLock)
            {
                messagesToSend.Add(toAdd);
            }
        }

        public void ClearRecentMapPoints()
        {
            lock (mapPointsLock)
            {
                recentMapPoints.Clear();
            }
        }

        public byte[] TurnMessagesToBytesAndConsumeThem()
        {
            BSONObject packets = new();
            int sentMessageIndex = 0;
            AddMapPointsListToIndexAndClearIt(ref packets, ref sentMessageIndex);
            lock (messagesLock)
            {

                for (int i = 0; i < messagesToSend.Count; i++)
                {

                    packets["m" + sentMessageIndex] = messagesToSend[i];
                    sentMessageIndex++;
                    
                    
                }
                packets["mc"] = sentMessageIndex;
                messagesToSend.Clear();

                for (int i = 0; i < packets["mc"].int32Value; i++)
                {
                    string id = packets["m" + i]["ID"].stringValue;
                    if (id == "RtP") bot.Player.spawned = true;
                    BSONObject? pk = packets["m" + i] as BSONObject;
                    if (!Logger.BlockClientToLog.Contains(id))
                    {
                        Logger.Log("Client");
                        Logger.ReadBSON(pk);
                    }
                }


            }
            return SimpleBSON.Dump(packets);
        }


        public void ClearMessages()
        {
            lock (messagesLock)
            {
                ClearRecentMapPoints();
                myPosMessage = new();
                messagesToSend.Clear();
            }
        }

        public void AddIfDoesNotContain(BSONObject toAdd)
        {
            lock (messagesLock)
            {
                bool flag = false;
                for (int i = 0; i < messagesToSend.Count; i++)
                {
                    if (messagesToSend[i]["ID"] == toAdd["ID"])
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    messagesToSend.Add(toAdd);
                }
            }
        }

        #region Movement packets

        public void SendPlayerPosition(BSONObject playerPosMessage)
        {
            this.myPosMessage = playerPosMessage;
        }

        public void SendPlayerPosition()
        {
            if (!myPosMessage.ContainsKey("ID")) return;

            AddIfDoesNotContain(myPosMessage);
        }

        public void AddMapPointIfNotLastAlready(Vector2i mapPoint)
        {
            object obj = this.mapPointsLock;
            lock (obj)
            {
                if (this.recentMapPoints.Count == 0)
                {
                    this.recentMapPoints.Add(mapPoint);
                }
                else if (this.recentMapPoints[recentMapPoints.Count - 1] != mapPoint)
                {
                    this.recentMapPoints.Add(mapPoint);
                }
            }
        }

        public void AddMapPointsListToIndexAndClearIt(ref BSONObject sentMessages, ref int sentMessageIndex)
        {

            if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
                return;

            SendPlayerPosition();

            object obj = this.mapPointsLock;
            lock (obj)
            {
                if (recentMapPoints.Count <= 0)
                    return;

                byte[] mapPoints = new byte[recentMapPoints.Count * 8];

                int offset = 0;
                recentMapPoints.ForEach(point => {
                    byte[] pointBytes = point.GetAsBinaryArray();
                    Buffer.BlockCopy(pointBytes, 0, mapPoints, offset, pointBytes.Length);
                    offset += pointBytes.Length;
                });
                recentMapPoints.Clear();

                BSONObject mpPacket = new() { ["ID"] = "mp", ["pM"] = mapPoints };
                sentMessages[$"m{sentMessageIndex}"] = mpPacket;
                sentMessageIndex++;
            }
        }

        public void SendResurrect(long time, Vector2i point)
        {
            AddOneMessageToList(new()
            {
                ["ID"] = "Rez",
                ["T"] = time,
                ["x"] = point.x,
                ["y"] = point.y
            });
        }


        #endregion


        public void RequestRandomWorld()
        {
            AddOneMessageToList(new()
            {
                ["ID"] = "TTJWR",
                ["Amt"] = 0
            });
        }

        public void SendMessage(string text)
        {
            AddIfDoesNotContain(new()
            {
                ["ID"] = "WCM",
                ["msg"] = text
            });
        }

        public void SendPing()
        {
            AddIfDoesNotContain(pingMessage);
        }

        public void SendMovementPing()
        {
            //AddIfDoesNotContain(new(){["ID"] = "mP"});
            this.myPosMessage = new() { ["ID"] = "mP" };
        }

        public void SendGetGameVersionMessage()
        {
            AddIfDoesNotContain(
                new BSONObject
                {
                    ["ID"] = "VChk",
                    ["OS"] = bot.os,
                    ["OSt"] = bot.os == "IPhonePlayer" ? 1 : 3
                });
        }

        public void SendGetPlayerDataMessage(string cog, string tk)
        {
            AddIfDoesNotContain(
                new BSONObject
                {
                    ["ID"] = "GPd",
                    ["CoID"] = cog,
                    ["Tk"] = tk,
                    ["cgy"] = 877
                });
        }

        public void SpinMiningWheel()
        {
            AddOneMessageToList(
                new BSONObject
                {
                    ["ID"] = "SMiningR"
                });
        }

        public void SendTryToJoinMessage(string _worldName, BasicWorldBiome biome = BasicWorldBiome.Forest)
        {
            bool isSpecial = false;

            isSpecial = (
                _worldName.ToLower() == "netherworld" ||
                _worldName.ToLower() == "secretbase" ||
                _worldName.ToLower() == "mineworld") ? true : false;

            BSONObject ttjwpkt = new()
            {
                ["ID"] = "TTjW",
                ["W"] = _worldName.ToUpper(),
                ["WB"] = (int)biome,
                ["Amt"] = 0
            };

            if (isSpecial) ttjwpkt["Is"] = true;

            AddIfDoesNotContain(ttjwpkt);


        }

        public void RequestOtherPlayersFromWorld()
        {
            AddIfDoesNotContain(
                new BSONObject
                {
                    ["ID"] = "rOP",
                });
        }

        public void ReadyToPlay()
        {
            bot.botHelper.Casino.JoinedRoom();

            AddOneMessageToList(new()
            {
                ["ID"] = "RtP"
            });
        }

        public void SendDoDisconnect()
        {
            AddIfDoesNotContain(
                new BSONObject
                {
                    ["ID"] = "DD"
                });
        }

        public void SendGetWorldMessage(string _name, string _eid)
        {
            AddOneMessageToList(new BSONObject
            {
                ["ID"] = "Gw",
                ["eID"] = _eid,
                ["W"] = _name.ToUpper()
            });
        }

        public void MenuWorldInfo(string _name)
        {
            AddOneMessageToList(
                    new()
                    {
                        ["ID"] = "MWli",
                        ["WN"] = _name.ToUpper(),
                    }
                );
        }

        public void RequestServerTime()
        {
            AddIfDoesNotContain(
                new BSONObject
                {
                    ["ID"] = "ST",
                    ["Stime"] = (((DateTime.UtcNow.Ticks - 621355968000000000) / 10000) * 10000) + 621355968000000000
                });
        }

        public void PlayerStatusIconUpdate(StatusIconType _sic)
        {
            AddIfDoesNotContain(new()
            {
                ["ID"] = "PSicU",
                ["SIc"] = (int)_sic
            });
        }
        public void SendDropItemMessage(Vector2i mapPoint, InventoryKey inventoryKey, short amount)
        {
            BSONObject bsonobject = new();
            bsonobject["ID"] = "Di";
            mapPoint.StoreToBSON(bsonobject);
            CollectableData collectableData = new(inventoryKey.blockType, amount, inventoryKey.itemType);
            bsonobject[NetStrings.droppedItem] = collectableData.GetAsBson();
            AddOneMessageToList(bsonobject);
        }
        public void SendCollectCollectable(int collectableId)
        {
            AddIfDoesNotContain(
                new BSONObject
                {
                    ["ID"] = "C",
                    ["CollectableID"] = collectableId
                });
        }
        public void SendWearableOrWeaponChange(BlockType blockType)
        {
            AddOneMessageToList(new()
            {
                ["ID"] = "WeOwC",
                ["hBlock"] = (int)blockType
            });
        }
        public void SendWearableOrWeaponUndress(BlockType blockType)
        {
            AddOneMessageToList(new()
            {
                ["ID"] = "WeOwU",
                ["hBlock"] = (int)blockType
            });
        }

        public void SendBuyInventorySlots()
        {
            BSONObject bsonobject = new();
            bsonobject["ID"] = "BuyInventorySlots";
            AddIfDoesNotContain(bsonobject);
        }

        public void SendHitAirMessage(Vector2i vector2i)
        {
            bot.Player.LastSentHitSpot = vector2i;
            AddOneMessageToList(new()
            {
                ["ID"] = "HA",
                ["x"] = vector2i.x,
                ["y"] = vector2i.y
            });
        }

        public void SendHitBlockBackgroundMessage(Vector2i vector2i)
        {
            bot.Player.LastSentHitSpot = vector2i;
            AddOneMessageToList(new()
            {
                ["ID"] = "HBB",
                ["x"] = vector2i.x,
                ["y"] = vector2i.y
            });
        }

        public void SendHitBlockMessage(Vector2i vector2i)
        {
            bot.Player.LastSentHitSpot= vector2i;
            AddOneMessageToList(new()
            {
                ["ID"] = "HB",
                ["x"] = vector2i.x,
                ["y"] = vector2i.y
            });
        }

        public void SendSetBlockMessage(Vector2i mapPoint, BlockType blockType)
        {
            AddIfDoesNotContain(new()
            {
                ["ID"] = "SB",
                ["x"] = mapPoint.x,
                ["y"] = mapPoint.y,
                ["BlockType"] = (int)blockType
            }) ;
        }

        public void ConvertItem(InventoryKey key)
        {
            AddOneMessageToList(new()
            {
                ["ID"] = "CI",
                ["IK"] = InventoryKey.InventoryKeyToInt(key)
            });
        }

        public void SendTrashItem(InventoryKey key, short amount)
        {

            BSONObject bsonobject = new();
            bsonobject["ID"] = "RIi";
            CollectableData collectableData = new(key.blockType, amount, key.itemType);
            bsonobject[NetStrings.droppedItem] = collectableData.GetAsBson();
            AddOneMessageToList(bsonobject);
        }

        public void RecycleMiningGem(InventoryKey key, short amount)
        {
            AddOneMessageToList(new()
            {
                ["ID"] = "RecycleMiningGem",
                ["IK"] = InventoryKey.InventoryKeyToInt(key),
                ["Amt"] = (int)amount
            });
        }
    }
}
