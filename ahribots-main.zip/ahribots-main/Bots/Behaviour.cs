﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots
{
    public abstract class Behaviour : IDisposable
    {
        public bool ExecutedAwake = false;
        public bool ExecutedStart = false;
        public bool Destroyed = false;

        private bool _disposed = false;

        public Behaviour() {
            ExecutedAwake = false;
            ExecutedStart = false;
            BotManager.AddBehaviour(this);
        }

        public virtual void Awake() { }
        public virtual void Start() { }
        public virtual void Update() { }
        
        ~Behaviour() { 
            Dispose(disposing: false);
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                Destroyed = true;
                this._disposed = true;
            }
        }
    }
}
