﻿using ArhiBots.Bots.Constants;
using ArhiBots.Constants;
using ArhiBots.Structs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using ImGuiNET;
using SixLabors.ImageSharp.ColorSpaces;
using ArhiBots.Pathfinding;
using ArhiBots.Misc;

namespace ArhiBots.Bots
{
    public class World
    {
        BSONObject world = new();

        public Bot bot;

        public World(Bot bot)
        {
            this.bot = bot;
        }


        public string WorldName;
        public string ID;
        public int InventoryId;
        public int WorldItemId;

        public LayerBlock[][] worldBlockLayer;
        public LayerBlockBackground[][] worldBlockBackgroundLayer;
        public LayerBlock[][] worldBlockWaterLayer;
        public LayerWiring[][] worldBlockWiringLayer;
        public BSONObject[][] worldsItemBson;
        public List<CollectableData> collectables;

        public WorldLayoutType WorldLayoutType;
        public LightingType WorldLightingType;
        public LayerBackgroundType WorldBackgroundType;
        public WeatherType WorldWeatherType;
        public GravityMode WorldGravityMode;
        public int WorldMusicIndex;

        public Vector2i WorldStartPoint;
        public Vector2i worldSize;
        public bool worldLoaded = false;

        private readonly object worldLock = new();

        public void InitFromBinary(byte[] data, string currentWorld)
        {
            worldLoaded = false;
            world = SimpleBSON.Load(LZMATools.DecompressLZMAByteArrayToByteArray(data));
            //Utils.ReadBSON(world);
            WorldName = currentWorld;
            bot.worldOnLoad = currentWorld;
            InventoryId = world["InventoryId"].int32Value;
            WorldItemId = world["WorldItemId"].int32Value;



            bot.NetworkPlayers = new (bot);

            bot.NetworkClient.outgoingMessages.RequestOtherPlayersFromWorld();

            // I assume these are something todo with AI? future me - THey definately do lol
            // even futurer me they are just requesting the ais and ai pets lol
            bot.NetworkClient.outgoingMessages.AddOneMessageToList(new BSONObject { ["ID"] = "rAIp" });
            bot.NetworkClient.outgoingMessages.AddOneMessageToList(new BSONObject { ["ID"] = "rAI" });

            WorldLayoutType = (WorldLayoutType)world["WorldLayoutType"]["Count"].int32Value;
            WorldBackgroundType = (LayerBackgroundType)world["WorldBackgroundType"]["Count"].int32Value;
            WorldWeatherType = (WeatherType)world["WorldWeatherType"]["Count"].int32Value;
            WorldLightingType = (LightingType)world["WorldLightingType"]["Count"].int32Value;
            WorldGravityMode = (GravityMode)world["WorldGravityMode"]["GM"].int32Value;
            WorldMusicIndex = world["WorldMusicIndex"]["Count"].int32Value;

            WorldStartPoint = new Vector2i(world["WorldStartPoint"]["x"].int32Value, world["WorldStartPoint"]["y"].int32Value);
            worldSize = new Vector2i(world["WorldSizeSettingsType"]["WorldSizeX"].int32Value, world["WorldSizeSettingsType"]["WorldSizeY"].int32Value);

            InitWorldHelper();

            GenerateCollectablesFromBson(world["Collectables"] as BSONObject);
            GenerateLayersFromBSON(world);
            InitPlayerSpawn();

            BSONObject worldItemsBson = world["WorldItems"] as BSONObject;
            foreach (string text2 in worldItemsBson.Keys)
            {
                string[] array2 = text2.Split(new char[]
                {
            ' '
                });
                BSONObject bsonobject2 = worldItemsBson[text2] as BSONObject;
                //WorldItemBase worldItemBase = new();//DataFactory.SpawnDataClassForEnum(WorldItemBase.GetBlockTypeViaClassNameInBSON(bsonobject2));
                //worldItemBase.SetViaBSON(bsonobject2);
                //this.worldItemsData[int.Parse(array2[1])][int.Parse(array2[2])] = worldItemBase;
                this.worldsItemBson[int.Parse(array2[1])][int.Parse(array2[2])] = bsonobject2;
            }

            worldLoaded = true;
        }

        public bool DoesPlayerHaveRightToModifyMapPoint(Vector2i mapPoint, string playerId, bool isBlockLayerCheck, BlockType newBlockType, PlayerData playerData)
        {

            return true;
        }

        public BlockType GetBlockWaterType(int positionX, int positionY)
        {
            if (positionX >= 0 && positionX < this.worldSize.x && positionY >= 0 && positionY < this.worldSize.y)
            {
                return this.worldBlockWaterLayer[positionX][positionY].blockType;
            }
            return BlockType.None;
        }


        float zoomLevel = 1.25f;

        List<PNode> miningPath= new List<PNode>();
        


            public List<Vector2i> GetDroppedItemsPositions()
            {
                List<Vector2i> positions = new List<Vector2i>();

                for (int y = worldSize.y - 1; y >= 0; y--)
                {
                    for (int x = 0; x < worldSize.x; x++)
                    {
                        BlockType block = GetBlockType(x, y);

                        if (ConfigData.IsGemStone(block))
                        {
                            positions.Add(new(x, y));
                        }

                    }
                }

                foreach (var collectable in collectables)
                {
                    positions.Add(new Vector2i((int)collectable.PosX, (int)collectable.PosY));
                }

                return positions;
            }

        public bool IsMapPointNearEnough(Vector2i mapPoint, Vector2i playerMapPoint, int range)
        {
            int num = Math.Abs(playerMapPoint.x - mapPoint.x);
            int num2 = Math.Abs(playerMapPoint.y - mapPoint.y);
            return num <= range && num2 <= range;
        }

        private void InitPlayerSpawn()
        {
            bot.NetworkClient.outgoingMessages.ClearRecentMapPoints();
            bot.Player.spawned = false;
            bot.Player.CurrentPosition = PositionConversions.ConvertMapPointToPlayersWorldPointFromFeet(WorldStartPoint);
            bot.Player.currentPlayerMapPoint= WorldStartPoint;

            bot.NetworkClient.outgoingMessages.SendPlayerPosition(new BSONObject
            {
                ["ID"] = "mP",
                ["t"] = Bot.GetTimeStamp(),
                ["x"] = (double)bot.Player.CurrentPosition.X,
                ["y"] = (double)bot.Player.CurrentPosition.Y,
                ["a"] = (int)AnimationNames.Idle,
                ["d"] = (int)Direction.Left,
            });
            bot.NetworkClient.outgoingMessages.AddMapPointIfNotLastAlready(bot.world.WorldStartPoint);

            
        }

        public void GenerateLayersFromBSON(BSONObject bson)
        {
            this.GenerateLayerFromByteArray(LayerType.Block, bson["BlockLayer"].binaryValue);
            this.GenerateLayerFromByteArray(LayerType.Background, bson["BackgroundLayer"].binaryValue);
            this.GenerateLayerFromByteArray(LayerType.Water, bson["WaterLayer"].binaryValue);
            this.GenerateLayerFromByteArray(LayerType.Wiring, bson["WiringLayer"].binaryValue);
        }

        private void InitWorldHelper()
        {
            worldBlockLayer = new LayerBlock[worldSize.x][];
            worldBlockBackgroundLayer = new LayerBlockBackground[worldSize.x][];
            worldBlockWaterLayer = new LayerBlock[worldSize.x][];
            worldBlockWiringLayer = new LayerWiring[worldSize.x][];
            //worldItemsData = new WorldItemBase[worldSize.x][];
            worldsItemBson = new BSONObject[worldSize.x][];

            this.collectables = new List<CollectableData>();

            for (int i = 0; i < worldSize.x; i++)
            {
                worldBlockLayer[i] = new LayerBlock[this.worldSize.y];
                worldBlockBackgroundLayer[i] = new LayerBlockBackground[this.worldSize.y];
                worldBlockWaterLayer[i] = new LayerBlock[this.worldSize.y];
                worldBlockWiringLayer[i] = new LayerWiring[this.worldSize.y];
                //worldItemsData[i] = new WorldItemBase[this.worldSize.y];
                worldsItemBson[i] = new BSONObject[worldSize.y];
            }

        }

        public void SetBlockHits(int amount, int positionX, int positionY)
        {
            object obj = this.worldLock;
            lock (obj)
            {
                this.worldBlockLayer[positionX][positionY].hitsRequired = amount;
            }
        }

        private void GenerateLayerFromByteArray(LayerType layer, byte[] byteArray)
        {
            short[] array = new short[byteArray.Length / 2];
            Buffer.BlockCopy(byteArray, 0, array, 0, byteArray.Length);
            for (int i = 0; i < this.worldSize.x; i++)
            {
                for (int j = 0; j < this.worldSize.y; j++)
                {
                    if (layer == LayerType.Block)
                    {
                        this.worldBlockLayer[i][j].blockType = (BlockType)array[j * this.worldSize.x + i];
                    }
                    else if (layer == LayerType.Background)
                    {
                        this.worldBlockBackgroundLayer[i][j].blockType = (BlockType)array[j * this.worldSize.x + i];
                    }
                    else if (layer == LayerType.Water)
                    {
                        this.worldBlockWaterLayer[i][j].blockType = (BlockType)array[j * this.worldSize.x + i];
                    }
                    else
                    {
                        this.worldBlockWiringLayer[i][j].blockType = (BlockType)array[j * this.worldSize.x + i];
                    }
                }
            }
        }

        private void GenerateCollectablesFromBson(BSONObject _bson)
        {
            int count = _bson["Count"].int32Value;

            for (int i = 0; i < count; i++)
            {
                collectables.Add(new(_bson["C" + i] as BSONObject));
            }
        }
        public int GetNewInventoryId()
        {
            object obj = this.worldLock;
            int result;
            lock (obj)
            {
                result = this.InventoryId++;
            }
            return result;
        }

        public CollectableData AddCollectable(BlockType blockType, short amount, InventoryItemType inventoryItemType, Vector2i mapPoint)
        {
            int newInventoryId = this.GetNewInventoryId();
            CollectableData collectableData = new(newInventoryId, blockType, amount, inventoryItemType, mapPoint.x, mapPoint.y);
            object obj = this.worldLock;
            lock (obj)
            {
                this.collectables.Add(collectableData);
            }
            return collectableData;
        }

        public bool DoesPlayerHaveRightToModifyItemData(Vector2i mapPoint, PlayerData playerData)
        {
            return false;
        }

        public CollectableData AddCollectable(BlockType blockType, short amount, InventoryItemType inventoryItemType, float x, float y)
        {
            int newInventoryId = this.GetNewInventoryId();
            CollectableData collectableData = new CollectableData(newInventoryId, blockType, amount, inventoryItemType, x, y);
            object obj = this.worldLock;
            lock (obj)
            {
                this.collectables.Add(collectableData);
            }
            return collectableData;
        }

        public bool IsValidItemDropPoint(Vector2i possibleDropPosition)
        {
            if (!this.IsMapPointInWorld(possibleDropPosition))
            {
                return false;
            }
            BlockType blockType = this.GetBlockType(possibleDropPosition);
            return blockType == BlockType.None || !ConfigData.DoesBlockHaveCollider(blockType);
        }

        private Vector2i GetBlockPos(BlockType block)
        {
            for (int i = 0; i < this.worldSize.x; i++)
            {
                for (int j = 0; j < this.worldSize.y; j++)
                {

                    if (GetBlockType(i, j) == block)
                    {
                        return new Vector2i(i, j);
                    }

                }
            }
            return new Vector2i(-1, -1);
        }

        public void RemoveCollectableIfPossible(int id)
        {
            object obj = this.worldLock;
            lock (obj)
            {
                for (int i = 0; i < this.collectables.Count; i++)
                {
                    if (this.collectables[i].CollectableId == id)
                    {
                        this.collectables.RemoveAt(i);
                        break;
                    }
                }
            }
        }


        public bool SwapWithMannequin = false;


        public void WrenchAndThenSwap(Vector2i position)
        {

            if (GetBlockType(position) != BlockType.Mannequin || this.worldsItemBson[position.x][position.y] == null)
                return;
            BSONObject bson = new()
            {
                ["ID"] = "TTSWi",
                ["x"] = position.x,
                ["y"] = position.y,
            };
            bot.OutgoingMessages.AddOneMessageToList(bson);
            SwapWithMannequin = true;
        }


        public void SwapClothesWithMannequin(Vector2i position)
        {
            if (GetBlockType(position) != BlockType.Mannequin || this.worldsItemBson[position.x][position.y] == null)
                return;

            var wib = this.worldsItemBson[position.x][position.y];

            BSONObject bson = new()
            {
                ["ID"] = "AMI",
                ["WiB"] = wib as BSONValue,
                ["x"] = position.x,
                ["y"] = position.y,
                ["swap"] = true
            };

            
            
            SwapWithMannequin = false;
            bot.OutgoingMessages.AddOneMessageToList(bson);
            //bot.OutgoingMessages.AddOneMessageToList(new() { ["ID"] = "RWI" });
            //bot.OutgoingMessages.PlayerStatusIconUpdate(StatusIconType.None);
        }

        

        public BlockType GetBlockType(Vector2i position)
        {
            return this.GetBlockType(position.x, position.y);
        }


        public bool IsMapPointInWorld(Vector2i position)
        {
            return this.IsMapPointInWorld(position.x, position.y);
        }

        public bool IsMapPointInWorld(int positionX, int positionY)
        {
            return positionX >= 0 && positionX < this.worldSize.x && positionY >= 0 && positionY < this.worldSize.y;
        }

        public BlockType GetBlockType(int positionX, int positionY)
        {
            if (positionX >= 0 && positionX < this.worldSize.x && positionY >= 0 && positionY < this.worldSize.y)
            {
                return this.worldBlockLayer[positionX][positionY].blockType;
            }
            return BlockType.None;
        }

        public struct LayerBlock
        {
            public BlockType blockType;
            public int hitsRequired;
            public int hitBuffer;
            public DateTime lastHitTime;
            public bool isWaitingForBlock;
            public int waitingBlockIndex;
            public bool isWaitingBlockTree;
        }

        public struct LayerBlockBackground
        {
            public BlockType blockType;
            public int hitsRequired;
            public int hitBuffer;
            public DateTime lastHitTime;
            public bool isWaitingForBlock;
            public int waitingBlockIndex;
        }

        public struct LayerWiring
        {
            public BlockType blockType;
            public int hitsRequired;
            public int hitBuffer;
            public DateTime lastHitTime;
            public bool isWaitingForBlock;
            public int waitingBlockIndex;
        }
    }
        }
