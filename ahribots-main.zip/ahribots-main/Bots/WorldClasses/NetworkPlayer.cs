﻿using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Structs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots
{
    public class NetworkPlayer
    {
        public string Username;
        public string UserID;
        public Gender Gender;
        public StatusIconType StatusIcon;
        public AnimationNames Animation;
        public Direction Direction;
        public Vector2 Position;
        public Vector2i MapPoint;
        public int gems;

        public NetworkPlayer(BSONObject _bson)
        {
            UserID = _bson["U"].stringValue;
            Username = _bson["UN"].stringValue;
            gems = _bson["GAmt"].int32Value;
            Position = new Vector2((float)_bson["x"].doubleValue, (float)_bson["y"].doubleValue);
            MapPoint = PositionConversions.ConvertPlayersWorldPointToMapPoint(Position);
        }
    }
}
