﻿using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Networking;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots
{
    public class WorldLoader
    {
        public NetworkClient networkClient;

        public WorldLoader(NetworkClient client)
        {
            this.networkClient = client;
        }

        private string potentialNewTargetWorldId = string.Empty;

        private string potentialNewTargetEntryPointId = string.Empty;

        private Action<WorldJoinResult> potentialNewTargetFailAction;

        public void CheckIfWeCanGoFromWorldToWorld(string newWorld, string entryPointID, Action<WorldJoinResult> doOnFail)
        {
            potentialNewTargetWorldId = newWorld;
            potentialNewTargetEntryPointId = entryPointID;
            potentialNewTargetFailAction = doOnFail;
            networkClient.tryToJoinSuccess = this.WorldToWorldTransitionWouldBeOk;
            networkClient.tryToJoinFailed = this.WorldToWorldTransitionWouldFail;
            networkClient.outgoingMessages.SendTryToJoinMessage(newWorld);
            // ControllerHelper.worldController.ShowLoadingWhenTryToGoAnotherWorld();
        }

        private void WorldToWorldTransitionWouldBeOk(WorldJoinResult worldJoinResult)
        {
            GoFromWorldToWorld(potentialNewTargetWorldId, potentialNewTargetEntryPointId);
            ClearPotentialNewTargetValues();
        }

        private void GoFromWorldToWorld(string newWorld, string entryPointID)
        {
            //networkClient.UpdateConnectionStatus(PlayerConnectionStatus.InLimbo);
            Logger.Log(("Going from: " + networkClient.currentWorld + "(" + networkClient.currentWorldEntryPointID + ") to: " + newWorld + "(" + entryPointID + ")"));
            networkClient.currentWorld = newWorld.ToUpper();
            networkClient.currentWorldEntryPointID = entryPointID;
            PlayerJoinsAnotherWorld();
        }

        private void ClearPotentialNewTargetValues()
        {
            potentialNewTargetWorldId = string.Empty;
            potentialNewTargetEntryPointId = string.Empty;
            potentialNewTargetFailAction = null;
        }

        public void GoFromMainMenuToWorld(string newWorld)
        {


            networkClient.currentWorld = newWorld;
            networkClient.currentWorldEntryPointID = string.Empty;
            PlayerJoinsAnotherWorld();
        }

        public void JoinWorldOnConnect(string name)
        {
            potentialNewTargetWorldId = name;
            potentialNewTargetEntryPointId = string.Empty;
            potentialNewTargetFailAction = null;
            networkClient.joinWorldOnConnect = name;
            networkClient.tryToJoinSuccess = this.WorldToWorldTransitionWouldBeOk;
            networkClient.tryToJoinFailed = this.WorldToWorldTransitionWouldFail;
        }

        private void PlayerJoinsAnotherWorld()
        {

            networkClient.UpdateConnectionStatus(PlayerConnectionStatus.InMenus);

            if (networkClient.bot.WorldController == null)
            {
                networkClient.bot.WorldController = new WorldController(networkClient.bot);
            }
            else
            {
                networkClient.bot.WorldController.Dispose();
                networkClient.bot.WorldController = new(networkClient.bot);
            }
        }

        private void WorldToWorldTransitionWouldFail(WorldJoinResult worldJoinResult)
        {
            if (potentialNewTargetFailAction != null)
            {
                potentialNewTargetFailAction(worldJoinResult);
            }
            ClearPotentialNewTargetValues();
        }
    }
}
