﻿using ArhiBots.Constants;
using ArhiBots.Misc;
using ImGuiNET;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots
{
    public class NetworkPlayers
    {
        public Bot bot;

        public List<NetworkPlayer> otherPlayers;

        public NetworkPlayers(Bot bot)
        {
            otherPlayers = new();
            this.bot = bot;
        }

        public void AddNetworkPlayer(BSONObject networkPlayerData)
        {
            if (IsPlayerInWorld(networkPlayerData["U"].stringValue))
            {
                Logger.Log("Client already has network player for player ID: " + networkPlayerData["U"].stringValue);
                return;
            }

            otherPlayers.Add(new NetworkPlayer(networkPlayerData));
            bot.botHelper.Casino.NewPlayer(networkPlayerData["UN"].stringValue);
        }

        public int GetNetworkPlayersCount()
        {
            return otherPlayers.Count;
        }

        public void PlayerLeft(string otherPlayerId)
        {
            //TradeUIUtility.PlayerCancelledTrade(otherPlayerId);
            NetworkPlayer networkPlayer = null;
            for (int i = 0; i < otherPlayers.Count; i++)
            {
                if (otherPlayers[i].UserID.Equals(otherPlayerId))
                {
                    networkPlayer = otherPlayers[i];
                    break;
                }
            }
            if (networkPlayer != null)
            {
                otherPlayers.Remove(networkPlayer);
            }
        }

        public bool SamePlayerAsID(string playerName,  string playerID)
        {
            for (int i = 0; i < otherPlayers.Count; i++)
            {
                if (otherPlayers[i].Username.ToUpper() == playerName && otherPlayers[i].UserID == playerID)
                {

                    return true;
                }
            }
            return false;
        }

        public void HandlePositionMessage(string otherPlayerClientId, Vector2 newPos, AnimationNames animationNames, Direction direction)
        {
            for (int i = 0; i < otherPlayers.Count; i++)
            {
                if (otherPlayers[i].UserID.Equals(otherPlayerClientId))
                {
                    otherPlayers[i].Position = newPos;
                    otherPlayers[i].MapPoint = PositionConversions.ConvertPlayersWorldPointToMapPoint(newPos);
                    otherPlayers[i].Animation = animationNames;
                    otherPlayers[i].Direction = direction;

                    break;
                }
            }
        }

        public void HandlePlayerStatusIconUpdate(string otherPlayerClientId, StatusIconType icon)
        {
            for (int i = 0; i < otherPlayers.Count; i++)
            {
                if (otherPlayers[i].UserID.Equals(otherPlayerClientId))
                {
                    otherPlayers[i].StatusIcon = icon;

                    break;
                }
            }
        }


        public bool IsPlayerInWorld(string otherPlayerId)
        {
            //Logger.Log(bot.Player.myPlayerData.playerId);
            if (bot.Player.myPlayerData.playerId.Equals(otherPlayerId))
            {
                return true;
            }
            for (int i = 0; i < otherPlayers.Count; i++)
            {
                if (otherPlayers[i].UserID.Equals(otherPlayerId))
                {
                    return true;
                }
            }
            return false;
        }

        public void RenderPlayers()
        {
            if (!bot.IsSelected) return;
            foreach (NetworkPlayer player in otherPlayers)
            {
                if (ImGui.CollapsingHeader(player.Username))
                {
                    ImGui.Text("Player id: " + player.UserID);
                    ImGui.Text("Gems: " +player.gems);
                    ImGui.Text("Status: " + player.StatusIcon.ToString());
                    ImGui.Text("Animation: " + player.Animation.ToString());
                    ImGui.Text("Direction: " + player.Direction.ToString());
                    ImGui.Text("MapPoint: " + player.MapPoint.ToString());
                    ImGui.Text("Position: " + player.Position.ToString());
                }
            }
        }
    }
}
