﻿using ArhiBots.Constants;
using ArhiBots.Networking;
using ArhiBots.Structs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots
{
    public class WorldController : Behaviour
    {
        public bool isNetworkClientDisabled;
        public Bot bot;

        public World world
        {
            get
            {
                return bot.world;
            }
        }

        public WorldController(Bot bot) => this.bot = bot;

        public override void Start()
        {
            if (bot.NetworkClient != null)
            {
                this.isNetworkClientDisabled = !bot.NetworkClient.isActiveAndEnabled;
            }
            else
            {
                this.isNetworkClientDisabled = true;
            }

            IEnumerator coroutine = WaitForConnection();
            while (coroutine.MoveNext()) { }

            //if (bot.NetworkClient.playerConnectionStatus == PlayerConnectionStatus.InMenus)
            //{
            //bot.NetworkClient.UpdateConnectionStatus(PlayerConnectionStatus.JoiningRoom);
            //  bot.NetworkClient.outgoingMessages.SendGetWorldMessage(bot.NetworkClient.currentWorld, bot.NetworkClient.currentWorldEntryPointID);
            //}
        }

        public override void Update()
        {

        }


        public void DropStuffFromInventory(Vector2i mapPoint, InventoryKey inventoryKey, short amount)
        {
            if (this.isNetworkClientDisabled)
            {
                CollectableData collectableData = this.world.AddCollectable(inventoryKey.blockType, amount, inventoryKey.itemType, mapPoint);
                //this.DoCollectableBlock(collectableData);
            }
            else
            {
                this.bot.NetworkClient.outgoingMessages.SendDropItemMessage(mapPoint, inventoryKey, amount);
            }
        }



        //public void DestroyBlock(int x, int y) => DestroyBlock(new Vector2i(x, y));

        public void SetBlock(Vector2i mapPoint, BlockType block)
        {
            InventoryItemType type = ConfigData.GetBlockTypeInventoryItemType(block);

            switch (type)
            {
                case InventoryItemType.Block:

                    world.worldBlockLayer[mapPoint.x][mapPoint.y].blockType = block;

                    break;
                case InventoryItemType.BlockBackground:

                    world.worldBlockBackgroundLayer[mapPoint.x][mapPoint.y].blockType = block;

                    break;
                case InventoryItemType.BlockWater:

                    world.worldBlockWaterLayer[mapPoint.x][mapPoint.y].blockType = block;

                    break;
                case InventoryItemType.BlockWiring:

                    world.worldBlockWiringLayer[mapPoint.x][mapPoint.y].blockType = block;

                    break;

            }
        }

        public void DestroyBlock(Vector2i mapPoint, InventoryItemType type)
        {
            switch (type)
            {
                case InventoryItemType.Block:

                    world.worldBlockLayer[mapPoint.x][mapPoint.y].blockType = BlockType.None;

                    break;
                case InventoryItemType.BlockBackground:

                    world.worldBlockBackgroundLayer[mapPoint.x][mapPoint.y].blockType = BlockType.None;

                    break;
                case InventoryItemType.BlockWater:

                    world.worldBlockWaterLayer[mapPoint.x][mapPoint.y].blockType = BlockType.None;

                    break;
                case InventoryItemType.BlockWiring:

                    world.worldBlockWiringLayer[mapPoint.x][mapPoint.y].blockType = BlockType.None;

                    break;

            }
        }
        public bool SetBlockWithTool(BlockType blockType, Vector2i mapPoint, float timeToWait)
        {
            if (this.world.IsMapPointInWorld(mapPoint) && this.world.IsMapPointNearEnough(mapPoint, bot.Player.GetPlayerMapPoint(), 2)  && this.CanSetCheckByLocks(mapPoint, blockType) && (this.world.GetBlockWaterType(mapPoint.x, mapPoint.y) == BlockType.None || (ConfigData.CanBlockBeBehindWater(blockType) && this.world.GetBlockWaterType(mapPoint.x, mapPoint.y) != BlockType.None)))
            {
                bot.OutgoingMessages.SendSetBlockMessage(mapPoint, blockType);
                return true;
            }
            return false;
        }

        private bool CanSetCheckByLocks(Vector2i mapPoint, BlockType blockType)
        {
            return this.world.DoesPlayerHaveRightToModifyMapPoint(mapPoint, bot.Player.myPlayerData.playerId, ConfigData.GetBlockTypeInventoryItemType(blockType) == InventoryItemType.Block, blockType, bot.Player.myPlayerData);
        }

        

        public bool MineBlockWithTool(float timeToWait, bool doTouchBlockIndicatorEffect, Vector2i mapPoint, BlockType toolBlockType, bool isTouchingBlock)
        {
            if (this.world.IsMapPointInWorld(mapPoint) && this.world.IsMapPointNearEnough(mapPoint, bot.Player.currentPlayerMapPoint, 2) && this.world.GetBlockType(mapPoint.x, mapPoint.y) != BlockType.None && (this.world.GetBlockType(mapPoint.x, mapPoint.y) != BlockType.EntrancePortal || (this.world.GetBlockType(mapPoint.x, mapPoint.y) == BlockType.EntrancePortal)) && !this.ShouldHitThrough(this.world.GetBlockType(mapPoint.x, mapPoint.y)))
            {
                bot.OutgoingMessages.SendHitBlockMessage(mapPoint);
                return true;
            }
            return false;
        }

        public void LocalPlayerReadyToPlay()
        {
            Vector2i vector2i = this.ConvertWorldPointToMapPoint(bot.Player.CurrentPosition + ConfigData.convertWorldPointToMapPointPlayerPositionHelper);
        }
        private bool ShouldHitThrough(BlockType blockType)
        {
            return blockType == BlockType.TutorialBot || blockType == BlockType.BonusGrandPrize;
        }
        public Vector3 ConvertMapPointToWorldPoint(Vector2i mapPoint)
        {
            return this.ConvertMapPointToWorldPoint(mapPoint.x, mapPoint.y);
        }

        public Vector3 ConvertMapPointToWorldPoint(int x, int y)
        {
            return new Vector3((float)x * ConfigData.tileSizeX, (float)y * ConfigData.tileSizeY, 0f);
        }

        public Vector3 ConvertPlayerMapPointToWorldPoint(Vector2i mapPoint)
        {
            return this.ConvertPlayerMapPointToWorldPoint(mapPoint.x, mapPoint.y);
        }

        public Vector3 ConvertPlayerMapPointToWorldPoint(int x, int y)
        {
            return new Vector3((float)x * ConfigData.tileSizeX, (float)y * ConfigData.tileSizeY - ConfigData.tileSizeY * 0.5f, 0f);
        }

        public Vector2i ConvertWorldPointToMapPoint(Vector2 worldPoint)
        {
            return PositionConversions.ConvertWorldPointToMapPoint(worldPoint.X, worldPoint.Y);
        }

        public void ConvertWorldPointToMapPoint(Vector3 worldPoint, ref Vector2i mapPoint)
        {
            mapPoint.x = (int)((worldPoint.X + ConfigData.tileSizeX * 0.5f) / ConfigData.tileSizeX);
            mapPoint.y = (int)((worldPoint.Y + ConfigData.tileSizeY * 0.5f) / ConfigData.tileSizeY);
        }

        private IEnumerator WaitForConnection()
        {
            while (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InMenus)
            {
                System.Threading.Thread.Sleep(500); // Pause for 500 milliseconds
                yield return null;
            }
            bot.NetworkClient.UpdateConnectionStatus(PlayerConnectionStatus.JoiningRoom);
            bot.NetworkClient.outgoingMessages.SendGetWorldMessage(bot.NetworkClient.currentWorld, bot.NetworkClient.currentWorldEntryPointID);
            yield break;
        }




    }
}
