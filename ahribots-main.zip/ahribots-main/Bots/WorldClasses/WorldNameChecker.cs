﻿using ArhiBots.Constants;
using System.Text.RegularExpressions;

namespace ArhiBots.Bots
{
    public static class WorldNameChecker
    {
        private static readonly int minWorldNameLength = 2;

        private static readonly int maxWorldNameLength = 15;

        private const string tutorialWorldName = "TUTORIAL2";

        public static NameValidity Validate(string worldName)
        {
            if (worldName == null)
            {
                return NameValidity.IsNull;
            }
            if (worldName.Length < minWorldNameLength)
            {
                return NameValidity.TooShort;
            }
            if (worldName.Length > maxWorldNameLength)
            {
                return NameValidity.TooLong;
            }
            worldName = worldName.ToUpper();
            if (!Regex.IsMatch(worldName, "^([][A-Z_^{}][][A-Z_0-9^{}-]+)$"))
            {
                return NameValidity.ContainsIllegalChars;
            }
            if (worldName.Equals("TUTORIAL2"))
            {
                return NameValidity.Banned;
            }
            return NameValidity.Ok;
        }
    }
}
