﻿using ArhiBots.Auto;
using ArhiBots.Bots.Constants;
using ArhiBots.Constants;
using ArhiBots.Discord_bot;
using ArhiBots.Networking;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots
{
    public class Bot : IDisposable
    {
        // UI stuff
        public string Prefix = "Bot ";
        public bool IsSelected = false;

        public bool NoBotSelected = false;

        public string Username = "";
        public bool AlreadyConnected = false;

        // Networking stuff
        public OutgoingMessages OutgoingMessages;
        public NetworkClient NetworkClient;

        public Stopwatch UptimeTimer = new();


        // Game stuff
        public Player Player;
        public World world;
        public WorldController WorldController;
        public NetworkPlayers NetworkPlayers;
        public UserIdent ident = new();
        public BotHelper botHelper;

        // Auto
        public Automain auto;
        public bool ForceCollect = true;
        public bool RangedCollect = false;

        public string worldOnLoad = "swagbag69";
        public string StartingWorld = "swagbag69";

        public string os = "WindowsPlayer";

        private bool _disposed = false;

        public PlayerConnectionStatus status { get { return NetworkClient.playerConnectionStatus; } }

        public int mgemCount { get { return Player.GetTotalGems(); } }

        public Address address = new();

        public Bot(string cognitoId, string token, string worldOnLoad) {
            ident.SetupLoginInfo(cognitoId, token);

            os = Program.rand.Next(1, 100) > 50 ? "IPhonePlayer" : "WindowsPlayer";
            this.worldOnLoad = worldOnLoad;
            this.StartingWorld = worldOnLoad;
            
            NetworkPlayers = new(this);
            OutgoingMessages = new(this);
            NetworkClient = new(this);
            Player = new(this);
            auto = new Automain(this);
            botHelper = new BotHelper(this);
            BotManager.bots.Add(this);
            Prefix += BotManager.bots.Count;


            UptimeTimer.Start();
            
        }

        public Bot()
        {
            NoBotSelected = true;
            ident = null;
            UptimeTimer = null;
            address = null;
        }

        ~Bot() {
            Dispose(disposing: false);
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this._disposed)
            {

                if (disposing)
                {
                    NetworkClient.Disconnect();
                    NetworkClient.Dispose();
                    Player?.Dispose();
                    WorldController?.Dispose();
                }
                _disposed = true;
            }
        }


        public void UpdatePrefix()
        {
            Prefix = ((Username == "") ? Prefix : Username)+((AlreadyConnected) ? " (AC)" : "");

        }

        public static long GetTimeStamp()
        {
            // Don't even ask me what this math is
            return (((DateTime.UtcNow.Ticks - 621355968000000000) / 10000) * 10000) + 621355968000000000;
        }

        public void Reconnect()
        {
            if (worldOnLoad == "MINEWORLD") worldOnLoad = StartingWorld;
            this.Destroy();
            NetworkPlayers = new(this);
            OutgoingMessages = new(this);
            NetworkClient = new(this);
            Player = new(this);
        }

        public void Destroy()
        {

            NetworkClient.Disconnect();
            NetworkClient.Dispose();
            Player?.Dispose();
            WorldController?.Dispose();

        }

        public static Bot Create(string cognitoId, string token, string worldOnLoad) {
            Bot bot = new(cognitoId, token, worldOnLoad);
            return bot;
        }
    }
}
