﻿using Amazon;
using Amazon.CognitoIdentity;
using Amazon.Lambda;
using Amazon.Lambda.Model;
using ArhiBots.Bots.Constants;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArhiBots.Misc;
namespace ArhiBots.Bots
{
    [Incomplete]
    public static class AWSRequests
    {
        static AmazonLambdaClient LambdaClient;
        private static CognitoAWSCredentials credentials;

        public static LoginInfo loginInfo;

        private static readonly string IdentityPoolId = "us-east-1:b9d5be2b-8fae-4bc6-8a4b-e35fab411d76";

        public static void Start()
        {
            UpdateLamda();
        }
        private static void UpdateLamda()
        {
            var cfg = new AmazonLambdaConfig();
            cfg.RegionEndpoint = RegionEndpoint.USEast1;
            LambdaClient = new AmazonLambdaClient(credentials, cfg);
        }


        public static void ConnectCognito()
        {
            Logger.Log("Connecting to Cognito and get new ID");
            credentials = new CognitoAWSCredentials(IdentityPoolId, RegionEndpoint.USEast1);
            credentials.GetIdentityIdAsync();
            Logger.Log(credentials.GetIdentityId());

            string coid = credentials.GetIdentityIdAsync().ToString();

            loginInfo =  new LoginInfo()
            {
                identityId = coid,
                logintoken = coid
            };

        }

        public static void RecoverUsernameOrPassword(string email)
        {
            InvokeRequest invokeRequest = new InvokeRequest();
            invokeRequest.FunctionName = "TinyWorlds_LostPassword" + ":prod";
            invokeRequest.Payload = "{\"email\" : \"" + email + "\"}";
            invokeRequest.InvocationType = InvocationType.RequestResponse;
            UpdateLamda();
            var responseObject = LambdaClient.InvokeAsync(invokeRequest);
            if (responseObject.Exception != null)
            {
                Logger.Log(responseObject.Exception.ToString());
            }
            string @string = Encoding.ASCII.GetString(responseObject.Result.Payload.ToArray());
            Logger.Log(@string);


        }

        public static LoginInfo LoginWithUsernameAndPassword(string username, string password, bool loginAfterRegistration = false)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {

                GUI.SampleOverlay.ShowErrorWindow("Login failed (incorrect username or password)");
                return null;
            }
            username = username.ToUpper();
            InvokeRequest invokeRequest = new InvokeRequest();
            invokeRequest.FunctionName = "TinyWorlds_LoginWithUserNameAndPassword" + ":prod";
            invokeRequest.Payload = string.Concat(new string[]
            {
                 "{\"username\" : \"",
                 username,
                 "\", \"password\" : \"",
                 password,
                 "\"}"
            });
            invokeRequest.InvocationType = InvocationType.RequestResponse;
            UpdateLamda();

            var responseObject = LambdaClient.InvokeAsync(invokeRequest);


            if (responseObject.Exception != null)
            {
                Logger.Log("LOGIN FAILED");
                //Bot.OnLoginFailed();
                GUI.SampleOverlay.ShowErrorWindow("Login failed (incorrect username or password)");
                return null;
            }
            else
            {
                string @string = Encoding.ASCII.GetString(responseObject.Result.Payload.ToArray());
                 Console.WriteLine(@string);
                //{"login":false}
                if (@string == "{\"login\":false}")
                {
                    Logger.Log("Login failed.");
                    Logger.Log(@string);
                    GUI.SampleOverlay.ShowErrorWindow("Login failed (incorrect username or password)");
                    return null;
                }

                loginInfo = JsonConvert.DeserializeObject<LoginInfo>(@string);
                
                return loginInfo;
            }

        }

        public class LoginInfo
        {

            public string login { get; set; }


            public string identityId { get; set; }


            public string token { get; set; }


            public string logintoken { get; set; }

            public string GetLoginInfo()
            {
                return $"{identityId};{logintoken}";
            }

        }

    }
}
