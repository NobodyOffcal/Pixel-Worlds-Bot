﻿using ArhiBots.Misc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Constants
{
    public class BsonEventArgs : EventArgs
    {
        public BSONObject BSON { get; set; }

        public BsonEventArgs(BSONObject bSONObject)
        {
            this.BSON = bSONObject;
        }
    }
}
