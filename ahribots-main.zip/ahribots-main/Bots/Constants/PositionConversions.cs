﻿using ArhiBots.Bots;
using ArhiBots.Structs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Constants
{
    public static class PositionConversions
    {
        public static Vector2i ConvertWorldPointToMapPoint(float x, float y)
        {
            return new Vector2i((int)((x + ConfigData.tileSizeX * 0.5f) / ConfigData.tileSizeX), (int)((y + ConfigData.tileSizeY * 0.5f) / ConfigData.tileSizeY));
        }

        public static void ConvertWorldPointToMapPoint(float x, float y, ref Vector2i mapPoint)
        {
            mapPoint.x = (int)((x + ConfigData.tileSizeX * 0.5f) / ConfigData.tileSizeX);
            mapPoint.y = (int)((y + ConfigData.tileSizeY * 0.5f) / ConfigData.tileSizeY);
        }

        public static Vector2i ConvertPlayersWorldPointToMapPoint(float x, float y)
        {
            y += ConfigData.tileSizeY * 0.5f;
            return PositionConversions.ConvertWorldPointToMapPoint(x, y);
        }

        public static Vector2i ConvertPlayersWorldPointToMapPoint(Vector2 xx)
        {
            xx.Y += ConfigData.tileSizeY * 0.5f;
            return PositionConversions.ConvertWorldPointToMapPoint(xx.X, xx.Y);
        }




        public static Vector2i ConvertPlayersWorldPointToMapPointFromFeet(float x, float y)
        {
            y += ConfigData.tileSizeY * 0.01f;
            return PositionConversions.ConvertWorldPointToMapPoint(x, y);
        }

        public static Vector2 ConvertMapPointToPlayersWorldPointFromFeet(Vector2i mapPoint)
        {
            Vector2 worldPoint;
            worldPoint.X = mapPoint.x * ConfigData.tileSizeX;
            worldPoint.Y = (mapPoint.y * ConfigData.tileSizeY) - (ConfigData.tileSizeY * 0.01f);
            return worldPoint;
        }

        public static Vector2i ConvertCollectablePosToMapPoint(float x, float y)
        {
            return PositionConversions.ConvertWorldPointToMapPoint(x * ConfigData.tileSizeX, y * ConfigData.tileSizeY);
        }
    }

}
