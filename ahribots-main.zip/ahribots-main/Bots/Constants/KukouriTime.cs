﻿using ArhiBots.Misc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Constants
{
    public class KukouriTime
    {
        private TimeSpan timeOffSet = default;

        private readonly string syncTimeKey = "STime";

        public void SetTimeOffset(DateTime serverTime, int roundTripTimeInMilliseconds)
        {
            timeOffSet = DateTime.UtcNow - serverTime.AddMilliseconds(roundTripTimeInMilliseconds / 2);
        }

        public DateTime Get()
        {
            return DateTime.UtcNow - timeOffSet;
        }

        public DateTime ParseServerTimeFromBSON(BSONObject bson)
        {
            return new DateTime(bson[syncTimeKey].int64Value);
        }

        public void AddServerTimeToBSON(BSONObject bson, DateTime dateTimeValue)
        {
            bson["ID"] = "ST";
            bson[syncTimeKey] = dateTimeValue.Ticks;
        }
    }

}
