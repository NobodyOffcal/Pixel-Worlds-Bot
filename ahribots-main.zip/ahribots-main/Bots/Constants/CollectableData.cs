﻿using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Structs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Constants
{
    public class CollectableData
    {
        public int CollectableId;
        public BlockType blockType;
        public InventoryItemType InventoryType;
        public bool IsGem;
        public GemType GemType;
        public short Amount;
        public float PosX;
        public float PosY;

        public CollectableData(int collectableId, BlockType blockType, InventoryItemType inventoryType, bool isGem, GemType gemType, short amount, float posX, float posY)
        {
            CollectableId = collectableId;
            this.blockType = blockType;
            InventoryType = inventoryType;
            IsGem = isGem;
            GemType = gemType;
            Amount = amount;
            PosX = posX;
            PosY = posY;
        }

        public CollectableData(BSONObject _bson)
        {
            CollectableId = _bson["CollectableID"].int32Value;
            this.blockType = (BlockType)_bson["BlockType"].int32Value;
            this.InventoryType = (InventoryItemType)_bson["InventoryType"].int32Value;
            Amount = (short)_bson["Amount"].int32Value;
            PosX = (float)_bson["PosX"].doubleValue;
            PosY = (float)_bson["PosY"].doubleValue;
            IsGem = _bson["IsGem"].boolValue;
            GemType = (GemType)_bson["GemType"].int32Value;
        }

        public CollectableData(int newInventoryId, BlockType blockType, short amount, InventoryItemType inventoryItemType, float x, float y)
        {
            this.CollectableId = newInventoryId;
            this.blockType = blockType;
            Amount = amount;
            this.InventoryType = inventoryItemType;
            this.PosX = x;
            this.PosY = y;
        }

        public CollectableData(BlockType block, short amount, InventoryItemType type)
        {
            this.blockType = block;
            this.Amount = amount;
            this.InventoryType = type;
        }

        public BSONObject GetAsBson()
        {
            BSONObject bson = new();
            bson.Add("CollectableID", CollectableId);
            bson.Add("BlockType", (int)blockType);
            bson.Add("InventoryType", (int)InventoryType);
            bson.Add("Amount", Amount);
            bson.Add("PosX", PosX);
            bson.Add("PosY", PosY);
            bson.Add("IsGem", IsGem);
            bson.Add("GemType", (int)GemType);
            return bson;
        }

        public InventoryKey GetInventoryKey()
        {
            return new InventoryKey(blockType, InventoryType);
        }

        public override string ToString()
        {
            return string.Format("CollectableData(CollectableId={0}, BlockType={1}, InventoryType={2}, IsGem={3}, GemType={4}, Amount={5}, PosX={6}, PosY={7})",
            CollectableId, blockType, InventoryType, IsGem, GemType, Amount, PosX, PosY);
        }
    }
}
