﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Constants
{
    public class GenericStorage
    {
        public static AnimationHotSpots[] GetAnimationHotSpots(BlockType blockType)
        {
            List<AnimationHotSpots> hotspots = new();
            switch (blockType)
            {
                case (BlockType.BasicFace):
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.BasicEyebrows):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.BasicEyeballs):
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.BasicMouth):
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.BasicLegs):
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.BasicTorso):
                    hotspots.Add(AnimationHotSpots.Torso);
                    return hotspots.ToArray();
                case (BlockType.BasicTopArm):
                    hotspots.Add(AnimationHotSpots.TopArm);
                    return hotspots.ToArray();
                case (BlockType.BasicBottomArm):
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    return hotspots.ToArray();
                case (BlockType.BasicEyelashes):
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.PantsBatman):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBatman):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponClaymore):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponExecutionerAxe):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponKatana):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickAxe):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPitchFork):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponShortSword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSpartanSword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponWalkingCane):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunBeretta):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtBatman):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskBatman):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.CapeBatman):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.PantsSweat):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBrown):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesRubberBootsYellow):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlassesBasic):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesNerdy):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesWhite):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesSunBasic):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.BeardBasic):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardGoatee):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardLong):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardBlack):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatAcademic):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCapBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCapGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCapPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCapRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCapWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskExecutioner):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatFireFighter):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatGolfBeret):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskMedievalKnight):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatNavy):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatNurse):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskPaperBagBrown):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatPolice):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskSkimask):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatSombrero):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatStetson):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatStrawHat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTennisHeadband):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTopHat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWoolcapGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairBeadedBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBradedBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongGolden):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongPink):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongCurlyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPigtailRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPunkBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAfroDark):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairArchyGrey):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBuzzCutBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCasualBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairClownRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPonytailBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSideyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShirtTBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtTSkullRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeSparta):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsDemon):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunRevolver):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunAK47):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.TightsRed):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.TailTiger):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.ShirtFlash):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtHeart):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsCamo):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatWolf):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressPink):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesLightBlue):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesLoafers):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatLong):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSaggy):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesUggBoots):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.DressWhite):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtSweaterWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.JacketBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesGroxsYellow):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtJerseyPurple):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesFootwraps):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsLeatherBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsShortsJean):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsJeansGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesWhite):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatRain):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.SuitOnepiece):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHardHat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtSoccer):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtAdventurer):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsAdventurer):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesAdventurer):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsSoccer):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.NoseClown):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.PantsCargo):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsJeansRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesOnepiece):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSneakersRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.EarPointy):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HeadphonesBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HairBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatAdventurer):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.BeardMoustache):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskCarneval):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskDevil):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesMirrorShades):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesSkiGogglesWhite):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.SuitToga):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHeadScarfLightBlueHead):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskMime):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatGlassHelmet):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.GloveMittensPink):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.SuitScifi):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtJerseyGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtTSkullBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairPunkGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.DressLongBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.TightsWhite):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.SuitClown):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtDressWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtBlouseRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesBallerinaWhite):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SkirtGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.SkirtRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatCapWoolWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShoesBallerinaRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesBallerinaBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.JacketSuede):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.DressSkaterYellow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsJeansGanstaBaggy):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBasketballGansta):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtJerseyGanstaRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.NeckChainGanstaGold):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.SkirtFarmDenim):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.SuitFarmOveralls):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtFarmPlaidRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WeaponSickleFarm):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponMicrophoneGansta):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingGanstaBlin):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.PantsLeatherMedievalBrown):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.TunicMedievalExecutioners):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.TunicMedievalLords):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtMedievalPeasantRags):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.ShirtMedievalRingMail):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeMedievalLords):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesMittensWoolWhite):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShirtWoolWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GloveClown):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesClown):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsMedievalLords):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.JumpsuitMale):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.Underwear):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.JumpsuitFemale):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatJumpsuitMale):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatJumpsuitFemale):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSanta):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairSanta):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShoesSanta):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsSanta):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtSanta):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.BeardSanta):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskAlien1):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskAlien2):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.SuitAlien1):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.SuitAlien2):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtHospitalGown):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesSneakersPink):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSneakersGreen):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtTanktopGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.ShirtTanktopBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.TightsBlack):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.HatHeadScarfBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHeadScarfRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtBlouseOrange):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuitAlien1):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuitAlien2):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SkirtMaxiYellow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.DressMaxiLightGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.DressDecoMaxiLightGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.DressDecoLongBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatSlouchyBeanieGrey):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HeadphonesRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HeadphonesBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlassesNerdyPurple):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.EarringsGold):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.CapeGreen):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.DressDecoSkaterYellow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GloveSuitAlien1):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GloveSuitAlien2):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.WeaponGlowStickRed):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGlowStickBlue):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGlowStickGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairBuzzCutWhite):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongOrange):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBlondeSpiky):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPonytailBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.GloveLeather):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.DressDecoWhite):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WingsPixie):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HairAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.JacketAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.PantsJeansAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesSneakersAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponKatanaAdminJaakko):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackKatanaNoHiltAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.GlassesAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponSantaCane):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HeadphonesAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.BackKatanaHiltAdminJaakko):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShoesRubberBootsRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WingsDarkPixie):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesRed):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.GlassesScifi):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShoesAdminCommander):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesAdminCommander):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.SuitAdminCommander):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorUpAdminCommander):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorDownAdminCommander):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GloveMittensRed):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GloveMittensGreen):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.PantsElf):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesElf):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatElf):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatElf):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsKrampus):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesKrampus):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairKrampus):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHornsKrampus):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatKrampus):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ScarfRed):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ScarfGreen):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.EarMuffsRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponCandyCane):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeFrost):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieGrey):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.DressSkaterLightBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GlassesEyepatch):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.CapeTowel):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.GlassesScifiRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesScifiGreenVIP):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesMonocle):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponShortSwordGolden):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponFlameSword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordAdminMidnightWalker):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitAdminMidnightWalker):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Tail);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.MaskRobbers):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShirtPonchoLightGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.SuitJumpPrison):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatCandyKing):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWinterPurple):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWonky):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskTeddyPink):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskTeddyBlue):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.PantsShortsLove):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.DressBallerina):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesBallerinaLacedPink):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesLeisure):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsLeisure):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtLeisure):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsCandyShorts):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesChoco):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesCandyShoes):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponLollipop):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesHeffnerSlippers):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.BeardMoustachePink):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HairCottonCandy):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CoatHeffner):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairHairbandBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.DressCocktailBubblegum):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesBubbleGum):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.NeckRedRubyAdminEndless):
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.HairAdminEndless):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CoatAdminEndless):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskAdminEndless):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.SuitTeddyPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.SuitTeddyBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesTeddyPink):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesTeddyBlue):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WingsCherubPink):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.SuitOverallsCandy):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponCandySceptre):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlassesSunHeart):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.CoatCandy):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairPonytailRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponAdminBanHammer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.PantsCamoBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatSlouchyBeanieBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShoesSneakersWhite):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtJerseyYellow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CoatRainBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtTSkullBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtTanktopBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.SkirtYellow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatStetsonBeige):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtTGrey):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeAchievementBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskPlagueDoc):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.HairAdminDev):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.PantsSpandexGreen):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.GlovesWristbandStPaddy):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HatStetsonGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairBobstyleGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.DressIrishMaid):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatTophatIrish):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatLeprechaun):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsLeprechaun):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesLeprechaun):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatGnome):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsShortsGnome):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlassesRoundGlassesGreen):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ScarfIrish):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HairStPaddy):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.BeardStPaddy):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShoesGnome):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatStPaddy):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponFluteStPaddy):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.InfluencerWickerHat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordGallowglass):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatBowlerLeprechaun):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponStickLeprechaun):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeLeprechaunCape):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsCloverWings):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskIrishCharm):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.NeckLuckyCharm):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponGuitarAdminDev):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BeardAdminDev):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLion):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatCapBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTophatDecoBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatBunnyEarsPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.TailEasterBunny):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.NoseEasterBunny):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.WeaponAxeEaster):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesEasterBunny):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorPWR):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesPWR):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesPWR):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitPWR):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordLaserGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordLaserRed):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordLaserBlue):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeDark):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskBunnyDark):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.SuitBunnyDark):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBunnyDark):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskTiki):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.JetPackPlasma):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.NecklaceGlimmer):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieSupport):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WingsDragonBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.JetPackSoda):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskChick):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.SuitChick):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesChick):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskBunnyGreen):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.SuitBunnyGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBunnyGreen):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairChick):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CapeEasterWitch):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatBunnyEars):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.MaskEggDetector):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatEasterWitchHeadScarf):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.WeaponEasterBranch):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesEasterWitch):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.DressEasterWitch):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponEasterWitchBroom):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlovesSkiGlovesGreen):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesSkiBoots):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitOverallsSkiSuitRetro):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HairSkimaskedBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairSkimaskedBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairSkimaskedBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairFringeSpikyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesBlue):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesGreen):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesGold):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesBrown):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesSilver):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesPurple):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesWhite):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesPink):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesTurquoise):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutLongBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutLongBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutLongBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutLongRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutWavyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutWavyReddish):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutWavyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairUndercutWavyBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairRockaBillyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJPopRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJPopBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJPopPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJPopGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAfroBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAfroBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAfroReddish):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCurlyCurtainsBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCurlyCurtainsBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCurlyCurtainsBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairEmoBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingFrost):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingGoblin):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HairPuffyBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPuffyRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSideyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSiippaLongBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSiippaLongBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSiippaLongRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairZefBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairZefBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyPunkBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyPunkRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairMohawkGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairMohawkRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongArchyBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongArchyRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairFringeSpikyBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairFringeSpikyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairFringeSpikyPink):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CapeAdminMidnightWalkerDouble):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CapeAdminMidnightWalkerParachute):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskHorseHead):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetSamuraiRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtSamuraiArmorRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSamuraiArmorRedBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesSamuraiArmorYellowBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetSamuraiBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtSamuraiArmorBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSamuraiArmorRedYellow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesSamuraiArmorWhiteBrown):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskSamuraiRed):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskSamuraiBlack):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.GloveNinjaPurple):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GloveNinjaGreyBlue):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GloveNinjaDarkRed):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HatHoodNinjaPurple):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHoodNinjaBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskNinjaRed):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtNinjaBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtNinjaPurple):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtNinjaDarkRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsNinjaBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsNinjaDark):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsNinjaGrey):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesNinjaGrey):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesNinjaRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesNinjaPurple):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.DressGeishaBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.DressGeishaRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HairSamurai):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairShogun):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairGeisha):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponSai):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSamuraiKatana):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponNaginata):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesGeishaRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesGeishaBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsBrokenHoleBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieSupportFemale):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlassesRetro):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.TailDevil):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatSteampunk):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponShogunKatana):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeShogunRed):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.BackDecorativeBackKatana):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HairBuzzcutBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieMod):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtSportsTopBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.ShirtSportsTopRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.ShirtSportsTopGold):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.PantsSpeedosBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsSpeedosRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsSpeedosGolden):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlassesSunBlue):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesSunRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesSunGolden):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterDuck):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterWalrus):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterDog):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShoesFlippersBlue):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesFlippersRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesFlippersGold):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskSnorkelBlue):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskSnorkelRed):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskSnorkelGold):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunWaterSmall):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunWaterMedium):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunWaterLarge):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSummerHammer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtLifeVestOrange):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.WeaponSurfboardGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSurfboardYellow):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSurfboardPurple):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairTrump):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAdminEndlessDeath):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShirtTopAdminEndlessDeath):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.GlassesAdminEndlessDeath):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WristBandsAdminEndlessDeath):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesAdminEndlessDeath):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsAdminEndlessDeath):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WingsSongo):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponCleaver):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatBucketRed):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.BeardGoateeBlack):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorPWRRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesPWRRed):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesPWRRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitPWRRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HairLongNutturaBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongNutturaBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairEmoBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairEmoRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongStripedBlackPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponBone):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetBone):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.SuitArmorBone):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponMace):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingChainMail):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingSkyrim):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingTHorns):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingSimpleMasked):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingSideIron):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingWarlord):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVikingThor):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHoodVikingLadyBlonde):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHoodVikingLadyBrown):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HairVikingSideyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingSideyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingSideyBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingMaidenBraidFrontBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingMaidenBraidSideBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingMaidenBraidSideBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingOpenBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairVikingOdinLongWhite):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.BeardOdinLongWhite):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardVikingLongBrown):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardVikingBrown):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardVikingBlonde):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardVikingBlack):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardVikingSideburnsBrown):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.FacialVikingMoustacheBrown):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingWarlord):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatVikingWarlord):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeVikingWarlord):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.DressVikingShieldmaidenGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingShieldmaidenGreen):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingBerserker):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsVikingBerserker):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtVikingBerserker):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeVikingBerserker):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingThor):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatVikingThor):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CoatVikingSeer):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.CoatDracula):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtVikingWarriorChainmail):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingWarriorBrown):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtVikingWarriorLeather):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingWarriorStrapped):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskMummy):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CoatVikingLady):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairJHorror):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShoesVikingLadyPurple):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatVikingSwordThroughHead):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingAxeDouble):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingAxeGreat):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingAxeCurved):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingAxeMedium):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingSword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingSpear):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingShieldRed):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingShieldGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingShieldBlue):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingShieldThor):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponVikingHammerThor):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemVikingShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsValkyria):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.VampireFangs):
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemVikingShieldGold):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemVikingShieldIron):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSeerStaff):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairDracula):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingDemon):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HatHornsDemon):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatBrainsOut):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskJason):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.MaskPumpkin):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.CapeDracula):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.DressCountessBathory):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatBrownFedora):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtKruger):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GlovesKrugerClaw):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.PantsKruger):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.MaskKruger):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.WeaponScythe):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPoisonBlade):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponBreadKnife):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.DressMistressOfTheDark):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairMistressOfTheDark):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskPaintSkull):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.MaskCorpsePaint):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskHoodBlack):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.MaskPinhead):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CoatPinhead):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairCountessBathory):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairChucky):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.OverallsChucky):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.MaskChuckyScars):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.CostumeWerewolf):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Magic);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Tail);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    return hotspots.ToArray();
                case (BlockType.MaskPhantom):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskNamelessGhoul):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskIt):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskFrankenstein):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskCthulhu):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskSawBillyPuppet):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WingsDarkCherub):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskSkull):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesSnake):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.CapeMidnight):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WingsCthulhu):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.JumpsuitAnniversary):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.CapeAdminMidnightWalkerLongJump):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CapeAdminMidnightWalkerNormal):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatVainamoinen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatPilgrim):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponNetherBlade):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatNetherHood):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShoesNetherPaws):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.TailNetherTail):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.PantsNetherPants):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtNetherArmor):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemNetherShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsAnniversary):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskSnowman):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.SuitSnowman):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HairIcicleMohawk):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MoustacheFrostache):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponFrostSpear):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SkirtXmas17):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatXmas17Blonde):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatXmas17Brunette):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatXmas17Black):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShoesXmas17Red):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieXmas17):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ScarfXmas17):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NecklaceFrost):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShirtXmas17Sweater):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemFrostShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesIceSkatesXmas17):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponFrostSword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponDarkSword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatNetherMask):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponNetherAxe):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.JetPackDark):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MagicSpeechBubbleDark):
                    hotspots.Add(AnimationHotSpots.Magic);
                    return hotspots.ToArray();
                case (BlockType.HatRoyale):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWinterCap):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesClearLight):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.NecklaceUntouchable):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShoesHighheelsPink):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.DressMaidPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatBowtiePink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlovesWristbandPink):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.EarRingPink):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Magic);
                    return hotspots.ToArray();
                case (BlockType.HatTieraCandyQueen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponUmbrellaPink):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtRainbow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeLove):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MouthTeethCandy):
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemHeartShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.BeardPink):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskBubbleGum):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskPacifierPink):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.MaskPacifierBlue):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HairAfroPink):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesPinkLove):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.HairHarlequin):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponDusterRainbow):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatUnicornHornPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressMaidBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GlassesVisorAchievement):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShirtBaseballHeart):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.SuitUnelias):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskGas):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.CoatLeafBoi):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.BeardLeaf):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HairLeaf):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffLeaf):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskTurtle):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShoesTurtle):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitTurtle):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlassesTintedGreen):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesFunnyMan):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatMushroom):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.SuitMushroom):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HairIrishRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WingsLeaf):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesWearyEyes):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.BackTurtleShell):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatWingDecorationRaven):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WingsButterfly):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieNether):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesMulticolored):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.GlassesButterfly):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ScarfButterfly):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskRamSkull):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.HatEggbasket):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSpring):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatCatEarsBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatBunnyEarsFloppyPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperBunnyBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperBunnyPink):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponCarrot):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyJPopYellow):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MouthTeethBunny):
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.WeaponMachette):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairArtemis):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPartzival):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatEasterRichboy):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShoesEasterRichboy):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatEasterRichboy):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GlassesEasterRichboy):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponCaneEasterRichboy):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyJPopBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyJPopRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyJPopBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.PantsEasterRichboy):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponEggHunterTribe):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SkirtEggHunterTribe):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.TopEggHunterTribe):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.MaskEggHunterTribe):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.HatPacifist):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.JumpsuitBruceLee):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtClassyBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsClassyBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesClassyBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtPunk):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsPunk):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesPunk):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairPunkPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.EarringPunk):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.BeardPiercingPunk):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.PantsJeansBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtJeanVest):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtConstructionVest):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatConstructionHelmet):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressClassyBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuspendersWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtMcFlyVest):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsBaggyOrange):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsDropping):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtCollegeBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtCollegeRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatRapperScarfWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSkaterCapBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatPorkPieRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatFlatCapWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCapWithScarfBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairRapperBraids):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.NeckRapperGold):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShoesBasketballWhite):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponShovel):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskBoxHead):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtTopRapperBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.MaskStreetArtist):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.ScarfStreetArtist):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsStreetArtist):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtStreetArtist):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesStreetArtist):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSloMo):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraPeige):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatFedoraYellow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.Glasses3D):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesRadioActive):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.HatHazMat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.SuitHazMat):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponBaseballBat):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskTopHeadHeroBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskTopHeadHeroBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskTopHeadHeroGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskTopHeadHeroRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskTopHeadHeroPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskEyesHeroBlack):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskEyesHeroBlue):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskEyesHeroGreen):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskEyesHeroRed):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskEyesHeroPurple):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroPurple):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroPurple):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperHeroRed):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperHeroWhite):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroWhite):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroPurple):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroGreen):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroPurple):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroBlack):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroKettle):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroGreen):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroBlack):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.EarsSuperHeroFox):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.TailSuperHeroFox):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.WeaponSuperHeroShieldGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroineBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroineBlack):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperHeroineWristBlack):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShirtLabCoat):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroineBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairSuperHeroineBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSuperHeroGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.GlassesSuperHeroVisorRed):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponShoutGun):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesBouncy):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJump):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponLaserGunSmall):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlovesCrabHands):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroGenericBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroGenericBlack):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroGenericGreen):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroGenericRed):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperHeroGenericPurple):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroineBlack):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.PantsHeroTightsBlack):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.PantsHeroTightsBlue):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.PantsHeroTightsRed):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.PantsHeroTightsGreen):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.PantsHeroTightsPurple):
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.GlassesBlindfold):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatHeadbandRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHeroHoodBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperHeroBlack):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.TailCatBlack):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatEarsCatBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponCrowbar):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitInvisibility):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.PantsSummerShorts):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.DressSummerRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatSummerHiabi):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.GlassesSummerRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShirtSailorSweater):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatSummerWide):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponFish):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatOctopus):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponIceCream):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskScubagear):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsFishfins):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponHarpoon):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesRollerblades):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponSunHammer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterTurtle):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLords):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesScifiVisorBlack):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunLaserScifi):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSlayer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitUnisexSwimsuit):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorPWRBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesPWRBlack):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesPWRBlack):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitPWRBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatFishFin):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressFantasyRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesFantasyRed):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatFantasyWoodElf):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsFantasyWoodElf):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesFantasyWoodElf):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairFantasyWoodElf):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskFantasyWoodElf):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordsDualWoodElf):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeFantasyWoodElf):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.EarsFantasyElf):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.CoatFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CapeFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponLanceHighElf):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHalo):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WingsGoldNBlack):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetChaos):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorChaos):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsChaos):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesChaos):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordChaos):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordBlood):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroSirLaser):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroSirLaser):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroSirLaser):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperHeroSirLaser):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperHeroGloomyClubber):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperHeroGloomyClubber):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperHeroGloomyClubber):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.BackSuperHeroGloomyDualSticks):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponSuperHeroGloomyDualSticks):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperHeroGloomyClubber):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemFantasyHighElf):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeBerserkerPolar):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.MaskHorseHeadUnicorn):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.SuitOnepiecePink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetBloodLord):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtBloodLord):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsBloodLord):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBloodLord):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsFaun):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.BeardFaun):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatHornsFaun):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NeckFaun):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.EarsFaun):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.TailFaun):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.CoatWarlock):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.EyebrowsFaun):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.EarsOrc):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordExcalibur):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BeardMoustacheHandlebarBlack):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatJingasa):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponCrookStaff):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CoatElfMage):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHornsElk):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHoodBloodLord):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.HatHornsTormentor):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.BeardHornsTormentor):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.TailTormentor):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesTormentor):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetPaladin):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorPaladin):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsPaladin):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesPaladin):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponMacePaladin):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsTormentor):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponScytheWarlock):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHoodWarlock):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHoodElfMage):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.CapeChaos):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemChaosShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.BeardOrcChin):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.ShirtTopTribalOrc):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSkirtTribalOrc):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesTribalOrc):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairTribalOrc):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponOrcClub):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordCalibur):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponThrowableAxe):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairInfluencerTery):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.BeardInfluencerTery):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.OverallsSkeleton):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtBlackbird):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GlovesBlackbird):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesBlackbird):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskBlackbird):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.CapeBlackbird):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShirtStraightJacket):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskScarecrow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.MaskScream):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.MaskFlaming):
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.WingsRaven):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJumpPumpkin):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsSkeleton):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskCrow):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.WeaponGuitarCrow):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskHannibal):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatTopHatRocker):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairCrow):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CoatCrow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsCrow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.MaskDemonic):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunGoldenEagle):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponThrowableHammer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordButcher):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponInsultingBat):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponFlyingCane):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapePurpleHeroGlide):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponMaceOfCorruption):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskTormentor):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsBlackbird):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorPumpkinBlackTower):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsPumpkinBlackTower):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.MaskPumpkinBlackTower):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordPumpkinBlackTower):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemShieldPumpkinBlackTower):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodiePurple):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.PantsSweatPurple):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.CoatRobecaster):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.OverallsMummy):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.TailWolf):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.FishingRodBambooBasic):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodBambooFine):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodBambooSuperior):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodBambooFlawless):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodFiberglassBasic):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodFiberglassFine):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodFiberglassSuperior):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodFiberglassFlawless):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodCarbonFiberBasic):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodCarbonFiberFine):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodCarbonFiberSuperior):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodCarbonFiberFlawless):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodTitaniumBasic):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodTitaniumFine):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodTitaniumSuperior):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodTitaniumFlawless):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CoatNetherWright):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmoredWalker):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsArmoredWalker):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesArmoredWalker):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetArmoredWalker):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordArmoredWalker):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetOldDiveSuit):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.OverallsOldDiveSuit):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesOldDiveSuit):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesOldDiveSuit):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesArmoredWalker):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.RobeStaffCaster):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatFisherRainYellow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShirtFisherRainYellow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsFisherWoodenLeg):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.BeardFisherSeadog):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatFisherRodman):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtFisherRodman):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesFisherRodmanSandals):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemFisherRodmanNet):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackFisherRodmanBasket):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatFisherProBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesFisherProBlue):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskFisherScarfProBlue):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.OverallsFisherProBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatFisherBaitHatBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatFisherBaitHatGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtFisherVestPeige):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtFisherVestGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatFisherFishHead):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShoesFisherFishes):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.TailFisherWorm):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatFisherSnufnomad):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NeckFisherScarfSnufnomad):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskFisherPipeBubble):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.MaskFisherWhistle):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.NeckFisherTalisman):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.TopEarRingFisherBait):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.PantsXMasCalendar):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesXMasCalendar):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HatHoodXMasCalendar):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShoesXMasCalendar):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatLuckyCapRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.BeardMoustacheStanLee):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.GlassesStanLee):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.TeethSuperheroTridentist):
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.OnepieceGingerbread):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHollyWreath):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatAntlersReindeer):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCrownFrostLord):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponSceptreFrostLord):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponHandBell):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatXmasBeanieRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatXmasBeanieGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatXMasTophat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WingsWinter):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponAnniversarySword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MoustacheSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtAugmented):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.PantsAugmented):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesAugmented):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskAugmented):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatAntennasAugmented):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesMonocleAugmented):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetGalacticChampion):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ShirtGalacticChampion):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsGalacticChampion):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesGalacticChampion):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordLaserClaymore):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunGalacticChampion):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.TailNanotech):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.PantsStellarScout):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.ShirtStellarScout):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetStellarScout):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.EarsHeadphonesScifi):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Magic);
                    return hotspots.ToArray();
                case (BlockType.BeardRavenous):
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.HairTentacles):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatExtraEyes):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.BeardTrunkNose):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.WeaponDualWinterAxes):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatWinterSeal):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponSuperheroDaBomba):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatCrownFae):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWeddingVeil):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressWedding):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.EarRingRuby):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GloveRingRuby):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HairPinkbowtieBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponBoquette):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairClassyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShirtTuxedo):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsTuxedo):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesTuxedo):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HairIcecream):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponCandyFloss):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlassesLovePatch):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WingsHeart):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorPWRPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesPWRPink):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesPWRPink):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitPWRPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HairBieberBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairWitcher):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBobRoss):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJPopBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJPopBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairHighPonytailPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairTentacious):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPonytailBluePurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairOldtimer):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSideyBlack2):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLovejoy):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatSheriff):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLeaf):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorLeaf):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsLeaf):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesLeaf):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemShieldLeaf):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordClaymoreLeaf):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordRapierClover):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatBowtieGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.EarEarringGreen):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.NeckTieGreen):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatBowlerPatrick):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.SkirtKiltGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WingsFaerie):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.DressFaerieGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.WeaponPaintbrushGreen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtSmokingJacketBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WeaponGlovesBoxing):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.TailPeafowl):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskBunnynator):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.SuitBunnynator):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBunnynator):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesBunnynator):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunBunnynator):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskEggHunterTribe19):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.TailSuperheroRetributor):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperheroRetributor):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperheroRetributor):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJumpRetributor):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperheroRetributor):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.WingsSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShirtSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.ShoesSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HairSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponSuperheroBuzzkill):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunEasterBazooka):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsFaerieEaster):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatEasterFlowers):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressFaerieEaster):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.SuitBarrel):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.PantsBunny):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesSuperheroRetributor):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackDecorativeBackpack):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatEarsFoxySkin):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NeckSpaceStrapsPurple):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NeckSpaceStrapsGreen):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskDeepOne):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    return hotspots.ToArray();
                case (BlockType.WingsMechanicalGolden):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.TailAlien):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingYellow):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingTurquoise):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.GlovesRingRose):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesAlien):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.HatSombrero2019):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponWiringTool):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatFrog):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponSunUmbrella):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlassesSwimGoggles):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterCat):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.DressHawaiian):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtFakeMuscles):
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.PantsMermaid):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.NeckHawaiianFlowers):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShoesBeachSlippers):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponLifeguardFloater):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackSharkFin):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponTridentPoseidon):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatCrownPoseidon):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CapePoseidon):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatHavaiianFlower):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsShortsLifeguard):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatSummerTurquoise):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetIceHockey):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskTurtlesHeroTurquoise):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.MaskTurtlesHeroYellow):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.MaskTurtlesHeroPink):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.MaskTurtlesHeroOrange):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.NeckHeroUtilityBeltTurquoise):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NeckHeroUtilityBeltYellow):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NeckHeroUtilityBeltPink):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NeckHeroUtilityBeltOrange):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShirtSailor):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSailor):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatScarfSailor):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsWheelchair):
                    hotspots.Add(AnimationHotSpots.Tail);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.EarPirateRing):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HairPirateDreadlocks):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatPrivateerRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatPrivateerBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatPrivateerPurple):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesPirateEyepatch):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.BeardPirateBlackBeard):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatBlackBeard):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatBlackBeard):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsBlackBeard):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesBlackBeard):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.DressColonialLady):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.GlassesEyesmudge):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatBuccaneer):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtBuccaneer):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsBuccaneer):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.CoatNavalOfficer):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairWigNavalOfficer):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatNavalOfficer):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsNavalOfficer):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesNavalOfficer):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.CoatPirateCaptain):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatPirateCaptain):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsPirateCaptain):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesPirateCaptain):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtPirateCaribbean):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsPirateCaribbean):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.BeardPirateCaribbean):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordFalchion):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordRapier):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSabre):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponAxeBoarding):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunFlintlock):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatColonialLady):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtBirdTribe):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.PantsBirdTribe):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.MaskBirdTribe):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HairBirdTribe):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.MaskPixelbot):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.HatPixelJester):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskPixelJester):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.OverallsPixelJester):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShoesPixelJester):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponClubPixelJester):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGoldenClaymore):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeThousandDays):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskSnorkelGreen):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShoesFlippersGreen):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitMannequin):
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.PantsWoodyTwoLegs):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffCaster):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetJigasa):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHoodNinjaBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskSamuraiGolden):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordNinjato):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtNinjaBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorKnight):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.PantsArmorKnight):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetArmorKnight):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordKnight):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordWooden):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeAchievement120):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunBazookaDubstep):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskTentacleshooter):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlovesFlameEnemy):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.EarsTiger):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieOrange):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShoesLemmy):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.PantsLemmy):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtLemmy):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HairPuffyYellow):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyJPopGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCynthia):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAfroAuburn):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairEtika):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairArchyBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPuffyPurple):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairDeVil):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCurlyCurtainsPink):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairFringeSpikyBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongRedBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairFringeSpikyGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCarrotTop):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairKhaleesiBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WingsDarkSprite):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatHaloBlood):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponSpiritClaw):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskTaunter):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetDemonic):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesScreamingEyes):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.MaskScaryFace):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.TailTaunter):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatHornsTaunter):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtScaryGreenStripe):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.MaskGhoulFemale):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.HairFranksBride):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.SuitGhost):
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatImmisCat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NecklaceSpectral):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatCleaverThroughHead):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskHauntedMonkey):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.ShirtHauntedMonkey):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsHauntedMonkey):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.TailHauntedMonkey):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.WeaponDualBananas):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordWolfBlade):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordFish):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtFrostBorn):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsFrostBorn):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesFrostBorn):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HoodFrostBorn):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordFrostBorn):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemShieldFrostBorn):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacingSanta):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.BeardSideburnsSanta):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatWinterHat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.OverallsPenguin):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatHoodPenguin):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.JetPackSnow):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffSunrise):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsCombo):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskFacePaintClanLight):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskFacePaintClanDark):
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieClanLight):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieClanDark):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WingsClanLight):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsClanDark):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordClanLight):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordClanDark):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskGasClanLight):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskGasClanDark):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.GlassesVisorClanLight):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesVisorClanDark):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatCrownClanLight):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCrownClanDark):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NecklaceClanLight):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NecklaceClanDark):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponShieldClanLight):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponShieldClanDark):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtFatSanta):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Torso);
                    return hotspots.ToArray();
                case (BlockType.GlovesWristbandsRed):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.HatWoolyBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWoolyRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskKitsune):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.HatTophatSilly):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskFaceScarfRed):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskFaceScarfGreen):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunIceRifle):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatBaseballCapRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatChineseCapRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSabreChinese):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordHellhound):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponAxeClover):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatPatricksHorned):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatEarsCatGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtTartan):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.SkirtTartan):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesTartan):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatTartan):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HairAfroGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.SuitMorphsuitGreen):
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.HatCrownRat):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CapeAdminMidnightWalkerTriple):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtPinkTuxedo):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordHeartBreaker):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtGopnik):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsGopnik):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHeartAntennas):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressWedding20):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodiePink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordBananasplit):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.PantsSnake):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.ShirtPyjamasPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsPyjamasPink):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.MaskOldTV):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.WingsPegasus):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.NecklaceWorm):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunPlasmaBazooka):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordMantel):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponAxeOutlander):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsEmerald):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.OverallsRobochick):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesRobochick):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.MaskRobochick):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunTeslapistol):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordTentacle):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtTuxedoGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatEarmuffsSilencer):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskLiarsNose):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.MaskSurgicalWhite):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskEggHunterTribe20):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.WeaponEggHunterTribe20):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.EarRingGoldspeech):
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Magic);
                    return hotspots.ToArray();
                case (BlockType.WeaponNetherKey):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponDualNetherBlades):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.OverallsHotDog):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatFoil):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorPWRYellow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesPWRYellow):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesPWRYellow):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitPWRYellow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatStrawberry):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatCookingPot):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTrafficCone):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskOwl):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskEarth):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskSynthwave):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.HatAlienController):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkYellow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatCrab):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLegionaryPlain):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLegionaryOfficer):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLegionaryGeneral):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetSpartan):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShoesLegionary):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShoesSpartan):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtLegionaryPlain):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtLegionaryOfficer):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtSpartan):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    return hotspots.ToArray();
                case (BlockType.TogaSenator):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatCrownSenator):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetGladiator):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.GlovesSpartanWristGuards):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.DressGreek):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.SuitSleevlesRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatSombrero2020):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.DressWaterfall):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatIceCream):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesSunRetrospectacular):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterDoughnut):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponVihta):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsWatermelon):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffStarfish):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.OverallsBanana):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.RobesLight):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHoodLight):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetSpace):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Face);
                    return hotspots.ToArray();
                case (BlockType.ShoesSpace):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlowesSpace):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.OverallsSpace):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetLight):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorLight):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsArmorLight):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesLight):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetHercules):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorHercules):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WeaponClubHercules):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSpearRoman):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSpartan):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordRoman):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackHandShieldRoman):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackHandShieldSpartan):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPopsicle):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHaloSpectral):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.JetPackSpectral):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsSpectral):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesSpectral):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.NecklaceRainbow):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.GlassesVisorSpectral):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSpectral):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunSpectral):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairSpectral):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordPiranha):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairDreadlocksBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.ShirtBeachBelly):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatBeach):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.SkirtTowel):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsShortsGreen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponBoomerang):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatSteam3yo):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeCrappy):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeFlimsy):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeBasic):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeSturdy):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeHeavy):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeMaster):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeEpic):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.NecklacePendantBrightness):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.NecklacePendantMoment):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.GlassesDeepDweller):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesExcavator):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatBandHeadlamp):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetMining):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetExcavator):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatDeepDweller):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlassesMonocleAppraisal):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.ShoesExcavator):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesExcavator):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesDeepDweller):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MoustacheExcavator):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardDeepDweller):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BackMinerBackpack):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskGasMiner):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HatEarsMouse):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.TailMouse):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.ShirtDeepDweller):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsDeepDweller):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemCanaryBird):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtExcavator):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetWatermelon):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskFaceSkull):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.CapeNecromancer):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJumpAchievement):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.ShirtHoodieWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponAxeBone):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSabreGolden):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CoatWitchHunter):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsWitchHunter):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatWitchHunter):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShoesWitchHunter):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.MaskWitchHunter):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponDualWitchHunter):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponCrossbowMechanical):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordSwiftSlicer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetMiningGolden):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponPickaxeDark):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.FishingRodCarbonFiberDark):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsTripple):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.CoatRainRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingJetRed):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MaskDraugr):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskFacehugger):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskDarkIfrit):
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WingsFlaming):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsGhost):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsDarkIfrit):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.SuitGhostBlue):
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.BeardDarkIfrit):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.PantsDarkIfrit):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.SuitMorphsuitBlack):
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.PantsJorogumo):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Tail);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.MaskBurger):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.RobesCultist):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordsDualSpirit):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.GlowesBraceletDarkEfreet):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingUfoBasic):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingPropellerWooden):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingRocketSkull):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.OverallsJetPilot):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetJetPilot):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenJetPilot):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.OverallsBumblebee):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.HatBumblebee):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlassesBumblebee):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WingsBumblebee):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatFlightCaptain):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatFlightCaptain):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsFlightCaptain):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtFlightCaptain):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CoatAviator):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsAviator):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatAviatorBrown):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatAviatorBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlassesAviator):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.NeckScarfAviator):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatForeheadGlasses):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.CoatPilotGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CoatPilotBrown):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilot):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerVisorUpYellow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerVisorUpRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerVisorUpGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerVisorUpBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerVisorUpWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerVisorUpBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerYellow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetRacerBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenRacerYellow):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenRacerRed):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenRacerGreen):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenRacerBlue):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenRacerWhite):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.MaskOxygenRacerBlack):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetSpaceFighterPilot1):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetSpaceFighterPilot2):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.OverallsSpaceFighterPilot):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.MoustacheBaron):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HatTiaraGoldenWings):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTiaraBirdTribeShaman):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NeckAmuletBirdTribeShaman):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WingsBirdTribeShaman):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.TailBirdTribeShaman):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.BackParachute):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatParatrooperBeretPurple):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatPropeller):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSideCapBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSideCapBrown):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSideCapGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilotVisorBlack):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilotVisorClear):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilotVisorRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilotVisorGreen):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilotVisorBlue):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.GlassesPilotVisorYellow):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatEarmuffsPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingBathtub):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingRocketBomb):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingEasterEgg):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingHotRod):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingPropellerYellow):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingPropellerFighter):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingPropellerBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingStarFighter):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingJetBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingRocketSpace):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingSantaSledge):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.ShirtXmasWoollyRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsSeasonalRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatSeasonalRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatPomPomPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.NeckScarfSeasonalBlue):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.MaskNoseRudolf):
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.HoodieXmasBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatBabyCloud):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatWinterFox):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    return hotspots.ToArray();
                case (BlockType.ShoesWinterFox):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlowesWinterFox):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.OverallsWinterFox):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.TailWinterFox):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatCrownIceQueen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    return hotspots.ToArray();
                case (BlockType.DressIceQueen):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.CapeIceQueen):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffIceQueen):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskFlamingIce):
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.RobesIceShaman):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHoodIceShaman):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffIceShaman):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairPuffyGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBieberBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCottonCandyDream):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairSemilongBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairShortAnimeRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCrewcutPink):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCrewcutBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairStarbridge):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairExotic):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairCurlySideyBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairRetroPotBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairEilish):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPamela):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBiden):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.GlassesThick):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    return hotspots.ToArray();
                case (BlockType.NeckTieBlue):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunSnowball):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingTurboSledge):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorCandyKnight):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsArmorCandyKnight):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetArmorCandyKnight):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordCandyKnight):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtTuxedoRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsTuxedoRed):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordAcidFlame):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetOx):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatOrientalRed):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsBrokenHoleBlue):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShirtVestedRed):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ShirtWintercoatYellow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatHoodWinterCoatYellow):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShoesWinterbootsYellow):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtBowlingBlack):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesOdin):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    return hotspots.ToArray();
                case (BlockType.ShirtWintercoatBlue):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatHoodWinterCoatBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtWintercoatPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatHoodWinterCoatPink):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.ShirtWintercoatGreen):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.HatHoodWinterCoatGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordCrimson):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesCandyKnight):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponBaseballbatStPatricks):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponEggHunterTribe21):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskEggHunterTribe21):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.WingsStPatricks21):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.DressEasterYellow):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WeaponStPatricks21):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtCollegePurple):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.MaskDragonBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatCrownStPatricks):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    return hotspots.ToArray();
                case (BlockType.MaskFaceStPatricks):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.BeardStubbed):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunStPatricks):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.DressStPatricks):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.PantsBorat):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Tights);
                    return hotspots.ToArray();
                case (BlockType.OverallsPickle):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatHoodGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponChineseDualMaces):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.MountFlyingJetSpaceWarrior):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Mount);
                    return hotspots.ToArray();
                case (BlockType.WeaponEasterBynnyrai):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtEasterBunnyrai):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsEasterBunnyrai):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetEasterBunnyrai):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShoesEasterBunnyrai):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatEasterEggShell):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.EarsCatAlbino):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskBunnyrai):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.SuitSwimsuitRetro):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.SuitSwimsuitPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.DressLongSummerYellow):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.NeckFannyBag):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.FishingRodBambooReinforced):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.NeckFloaterFlamingo):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetMiningFlameBooster):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumePig):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumePig):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumePig):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumePig):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumePig):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeWolf):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeWolf):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumeWolf):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeWolf):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumeWolf):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeKangaroo):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeKangaroo):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumeKangaroo):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeKangaroo):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumeKangaroo):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeMallard):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeMallard):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeMallard):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeCat):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeCat):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumeCat):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeCat):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumeCat):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeDog):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeDog):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumeDog):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeDog):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumeDog):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeMouse):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeMouse):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumeMouse):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeMouse):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumeMouse):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCostumeRacoon):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.SuitCostumeRacoon):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ShoesCostumeRacoon):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.GlovesCostumeRacoon):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.TailCostumeRacoon):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskCarnivorousPlant):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.SuitCamouflageSoilblock):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Magic);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Tail);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsDrakeBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.HatSombrero2021):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSummerPride):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskClanBot):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponGunGoldenM16):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskRedOnion):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WingsMechanical):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WingsOcean):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponShieldApollo):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponBeeHiveStaff):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.CapeDoggo):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.GlassesShutterPink):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HatPastaBowl):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTurbanBlue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.GlassesTintedRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.BackBackpackWanderer):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.ShoesSocksWithSandals):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatSummerVogue):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.ShoesSummerBouncy):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.WeaponLongsword):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemKiteShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatIronHelmet):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskFaceTentacles):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WingsIonThrusters):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponScytheSpirit):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponArcaneSpell):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskNosferatu):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.MaskScorcher):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.MaskGolemGolden):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponBladesTurok):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsScorcher):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsWhirlwindHair):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatCrownMedusa):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.TailScorcher):
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.HatHornsScorcher):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.PantsScorcher):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJumpExplosive):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.WingsBackgoyle):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJumpAncientGolem):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordInferno):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitGhostPurple):
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.MaskAnubis):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.SkirtAnubis):
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.BackhandItemAnubisShield):
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShoesAnubis):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.ShirtAnubis):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.WingsNightmare):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordAnubis):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatWoolcapBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatTopHatWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponShuriken):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.NeckScarfXMas):
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.GlassesEternalTears):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponPlunger):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatConeFestive):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskEggHunterTribe22):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.HatSombreroGeneric):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WingsRetroButterfly):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.DressWeddingPink):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.CapeUndead):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Neck);
                    return hotspots.ToArray();
                case (BlockType.JetPackLongJumpDimensionArms):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsIceBlade):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordDadaoJade):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordCyberBlade):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitMorphsuitWhite):
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetVisorPWRWhite):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.GlovesPWRWhite):
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    return hotspots.ToArray();
                case (BlockType.ShoesPWRWhite):
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.SuitPWRWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesFrost):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.WeaponMaceFrostGiants):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.SuitSuperheroHulkWhite):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Torso);
                    hotspots.Add(AnimationHotSpots.TopArm);
                    hotspots.Add(AnimationHotSpots.BottomArm);
                    hotspots.Add(AnimationHotSpots.Legs);
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.TopArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmGlove);
                    hotspots.Add(AnimationHotSpots.BottomArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponGuitarStPatricks):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ShirtArmorValentine2022):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    return hotspots.ToArray();
                case (BlockType.PantsArmorValentine2022):
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    return hotspots.ToArray();
                case (BlockType.HatHelmetArmorValentine2022):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordValentine2022):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatWizard):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskCoffee):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    return hotspots.ToArray();
                case (BlockType.NeckEmeraldEagleStone):
                    hotspots.Add(AnimationHotSpots.Neck);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    return hotspots.ToArray();
                case (BlockType.HatCandle):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSiren):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatPoop):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.BeardGaribaldi):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordNetherCrystal):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairKhaleesiBlack):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.WingsDrakePurpleWhite):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.GlassesVisorRed):
                    hotspots.Add(AnimationHotSpots.Glasses);
                    return hotspots.ToArray();
                case (BlockType.HairSpikyJPopWhite):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HatHaloBloodBlack):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.HatSteampunkPurple):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.MaskDragonGreen):
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.CapeMedievalLordsGhost):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.CapeMedievalLordsBlue):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.BeardMoustacheHandlebarOrange):
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.WeaponSuperheroTridentistRed):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsDragonBlack):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsDrakeOrange):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsSpriteYellow):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WingsAngelic):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordChain):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.MaskWickedWitch):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.HatWickedWitch):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.RobesWickedWitch):
                    hotspots.Add(AnimationHotSpots.Shirt);
                    hotspots.Add(AnimationHotSpots.TopArmSleeve);
                    hotspots.Add(AnimationHotSpots.BottomArmSleeve);
                    hotspots.Add(AnimationHotSpots.Pants);
                    return hotspots.ToArray();
                case (BlockType.WeaponBroomWickedWitch):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsOneWing):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.PantsSeaHag):
                    hotspots.Add(AnimationHotSpots.Tights);
                    hotspots.Add(AnimationHotSpots.Tail);
                    hotspots.Add(AnimationHotSpots.Pants);
                    hotspots.Add(AnimationHotSpots.Shoes);
                    hotspots.Add(AnimationHotSpots.Legs);
                    return hotspots.ToArray();
                case (BlockType.WeaponHammerSpirit):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.ContactLensesDarkness):
                    hotspots.Add(AnimationHotSpots.ContactLensLeft);
                    hotspots.Add(AnimationHotSpots.ContactLensRight);
                    hotspots.Add(AnimationHotSpots.PupilLeft);
                    hotspots.Add(AnimationHotSpots.PupilRight);
                    hotspots.Add(AnimationHotSpots.Eyeballs);
                    return hotspots.ToArray();
                case (BlockType.MaskRectangleHead):
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Hat);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    return hotspots.ToArray();
                case (BlockType.MaskMummyRoyal):
                    hotspots.Add(AnimationHotSpots.Beard);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyelashes);
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WeaponSandalSummer):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponCrossbowStake):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WingsKitsuneTail):
                    hotspots.Add(AnimationHotSpots.Back);
                    hotspots.Add(AnimationHotSpots.Tail);
                    return hotspots.ToArray();
                case (BlockType.WingsSinisterMoth):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.MaskGhoulWintersEnd):
                    hotspots.Add(AnimationHotSpots.Face);
                    hotspots.Add(AnimationHotSpots.Eyebrows);
                    hotspots.Add(AnimationHotSpots.Mouth);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    return hotspots.ToArray();
                case (BlockType.WeaponScytheWintersEnd):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.WeaponStaffStPatricks):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HatMitreStPatricks):
                    hotspots.Add(AnimationHotSpots.Hat);
                    return hotspots.ToArray();
                case (BlockType.WingsJadeStPatricks):
                    hotspots.Add(AnimationHotSpots.Back);
                    return hotspots.ToArray();
                case (BlockType.WeaponSwordJadeStPatricks):
                    hotspots.Add(AnimationHotSpots.TopArmItem);
                    return hotspots.ToArray();
                case (BlockType.HairAfroDeepBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairAfroBlonde):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairJHorrorRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HairJHorrorBlackWhite):
                    hotspots.Add(AnimationHotSpots.Hair);
                    hotspots.Add(AnimationHotSpots.TopEarRing);
                    hotspots.Add(AnimationHotSpots.Mask);
                    hotspots.Add(AnimationHotSpots.Beard);
                    return hotspots.ToArray();
                case (BlockType.HairEmoGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairZefLightBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongViolet):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairLongStripedBlackWhite):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPartzivalGreen):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairKhaleesiBrown):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairPixieRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairModestRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairFloweryRed):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();
                case (BlockType.HairBubblegumBlue):
                    hotspots.Add(AnimationHotSpots.Hair);
                    return hotspots.ToArray();

                default:
                    return hotspots.ToArray();
            }
        }
    
    }
}
