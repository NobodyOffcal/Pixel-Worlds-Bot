﻿using ArhiBots.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Bots.Constants
{
    public class UserIdent
    {

        public string CognitoID = string.Empty;
        public string Token = string.Empty;

        private UserIdentState idReady = UserIdentState.Success;

        public void SetupLoginInfo(string coid, string token)
        {
            CognitoID = coid;
            Token = token;
        }

        public string[] GetLoginInfo()
        {
            return new string[2]
                {
                CognitoID,
                Token
                };
        }

        public UserIdentState IsIdReady()
        {
            return idReady;
        }

        private class LoginInfo
        {
            public string login;

            public string identityId;

            public string token;

            public string created;
        }
    }
}
