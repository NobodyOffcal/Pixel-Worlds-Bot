﻿using System;
using System.IO;
using SevenZip;
using SevenZip.Compression.LZMA;

namespace ArhiBots.Bots
{
    public static class LZMATools
    {
        public enum LZMADictionarySize
        {
            Dict256KiB = 0x40000,
            Dict512KiB = 0x80000,
            Dict1MiB = 0x100000,
            Dict2MiB = 0x200000,
            Dict4MiB = 0x400000
        }

        public static void CompressFileToLZMAFile(string inFile, string outFile)
        {
            FileStream inputStream = new FileStream(inFile, FileMode.Open);
            FileStream outputStream = new FileStream(outFile, FileMode.Create);
            Compress(inputStream, outputStream);
        }

        public static void CompressByteArrayToLZMAFile(byte[] inByteArray, string outFile)
        {
            Stream inputStream = new MemoryStream(inByteArray);
            FileStream outputStream = new FileStream(outFile, FileMode.Create);
            Compress(inputStream, outputStream);
        }

        public static byte[] CompressByteArrayToLZMAByteArray(byte[] inByteArray)
        {
            Stream inputStream = new MemoryStream(inByteArray);
            MemoryStream memoryStream = new MemoryStream();
            Compress(inputStream, memoryStream);
            return memoryStream.ToArray();
        }

        public static void CompressFileToLZMAFile(string inFile, string outFile, LZMADictionarySize dictSize)
        {
            FileStream inputStream = new FileStream(inFile, FileMode.Open);
            FileStream outputStream = new FileStream(outFile, FileMode.Create);
            Compress(inputStream, outputStream, dictSize);
        }

        public static void CompressByteArrayToLZMAFile(byte[] inByteArray, string outFile, LZMADictionarySize dictSize)
        {
            Stream inputStream = new MemoryStream(inByteArray);
            FileStream outputStream = new FileStream(outFile, FileMode.Create);
            Compress(inputStream, outputStream, dictSize);
        }

        public static byte[] CompressByteArrayToLZMAByteArray(byte[] inByteArray, LZMADictionarySize dictSize)
        {
            Stream inputStream = new MemoryStream(inByteArray);
            MemoryStream memoryStream = new MemoryStream();
            Compress(inputStream, memoryStream, dictSize);
            return memoryStream.ToArray();
        }

        public static void DecompressLZMAFileToFile(string inFile, string outFile)
        {
            FileStream inputStream = new FileStream(inFile, FileMode.Open);
            FileStream outputStream = new FileStream(outFile, FileMode.Create);
            Decompress(inputStream, outputStream);
        }

        public static void DecompressLZMAByteArrayToFile(byte[] inByteArray, string outFile)
        {
            Stream inputStream = new MemoryStream(inByteArray);
            FileStream outputStream = new FileStream(outFile, FileMode.Create);
            Decompress(inputStream, outputStream);
        }

        public static byte[] DecompressLZMAByteArrayToByteArray(byte[] inByteArray)
        {
            Stream inputStream = new MemoryStream(inByteArray);
            MemoryStream memoryStream = new MemoryStream();
            Decompress(inputStream, memoryStream);
            return memoryStream.ToArray();
        }

        private static void Compress(Stream inputStream, Stream outputStream)
        {
            Encoder encoder = new Encoder();
            encoder.WriteCoderProperties(outputStream);
            outputStream.Write(BitConverter.GetBytes(inputStream.Length), 0, 8);
            encoder.Code(inputStream, outputStream, inputStream.Length, -1L, null);
            outputStream.Flush();
            outputStream.Close();
        }

        private static void Compress(Stream inputStream, Stream outputStream, LZMADictionarySize dictSize)
        {
            Encoder encoder = new Encoder();
            encoder.SetCoderProperties(new CoderPropID[1] { CoderPropID.DictionarySize }, new object[1] { (int)dictSize });
            encoder.WriteCoderProperties(outputStream);
            outputStream.Write(BitConverter.GetBytes(inputStream.Length), 0, 8);
            encoder.Code(inputStream, outputStream, inputStream.Length, -1L, null);
            outputStream.Flush();
            outputStream.Close();
        }

        private static void Decompress(Stream inputStream, Stream outputStream)
        {
            Decoder decoder = new Decoder();
            byte[] array = new byte[5];
            inputStream.Read(array, 0, 5);
            byte[] array2 = new byte[8];
            inputStream.Read(array2, 0, 8);
            long outSize = BitConverter.ToInt64(array2, 0);
            decoder.SetDecoderProperties(array);
            decoder.Code(inputStream, outputStream, inputStream.Length, outSize, null);
            outputStream.Flush();
            outputStream.Close();
        }
    }
}
