﻿using System.Diagnostics;
using Discord.Webhook;
using Discord;
using ImGuiNET;
using ArhiBots.Misc;

namespace ArhiBots.Bots
{
    public class WebhookLogs
    {

        static string wbURl { get { return Globals.webhook; } }
        static ulong msg = 0;

        public static bool WebhookMessageSent = false;

        public static async Task SendBotsStatus()
        {
            WebhookMessageSent = false;

            string idk = $"This was made by krak. Please do not distibute this product without consent of krak :)";
            DiscordWebhookClient wbc = new DiscordWebhookClient(wbURl);

            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.WithAuthor("Arhi bots (made by krak)");
            embed.WithDescription(idk);
            embed.WithThumbnailUrl("https://media.discordapp.net/attachments/1074756916011618324/1081686624666132530/logo.png?width=929&height=671");
            embed.WithFooter(new EmbedFooterBuilder().WithIconUrl("https://images-ext-1.discordapp.net/external/3MYDXr6RzJrAby5O7RN5PZC0PV5YaGoJhCMxgqDyYG8/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/959197199860903956/d707532028b95e8f78239daebe3dc2bd.png?width=320&height=320")
                .WithText("made by krak"));
            Embed[] embeds = { embed.Build() };
            msg = await wbc.SendMessageAsync("", false, embeds.AsEnumerable());
            WebhookMessageSent = true;
            
        }

        static int totalGems = 0;
        public static async Task UpdateBots()
        {
            if (!WebhookMessageSent)
            {
                return;
            }

            totalGems = 0;
            Process process = Process.GetCurrentProcess();
            process.Refresh();
            TimeSpan cpuTime = process.TotalProcessorTime;
            TimeSpan elapsedTime = DateTime.Now - process.StartTime;
            float cpuUsage = (float)cpuTime.TotalMilliseconds / (float)elapsedTime.TotalMilliseconds / Environment.ProcessorCount * 100;

            long memoryUsage = process.WorkingSet64;

            string idk = $"CPU {(int)cpuUsage}%\nMem {(memoryUsage / 1024 / 1024)} MB";

            DiscordWebhookClient wbc = new DiscordWebhookClient(wbURl);
            WebhookMessageProperties props = new WebhookMessageProperties();
            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Green); 
            embed.WithTitle($"Arhi Bots info");
            embed.WithThumbnailUrl("https://media.discordapp.net/attachments/1074756916011618324/1081686624666132530/logo.png?width=929&height=671");
            
            string descript = $"**{idk}**\n";

            int i = 0;
            foreach (Bot bot in BotManager.bots)
            {
                
                EmbedFieldBuilder fefe = new EmbedFieldBuilder();
                fefe.WithName($"{bot.Prefix}");
                totalGems += bot.mgemCount;
                string status = $"status: {bot.NetworkClient?.playerConnectionStatus}{((bot.NetworkClient?.playerConnectionStatus == ArhiBots.Constants.PlayerConnectionStatus.InRoom) ? $" ({bot.world?.WorldName})" : "")}";
                string ping = $"ping: {bot.NetworkClient?.ping}";
                
                string miningInfo = "";
                if (bot.auto != null)
                {
                    if (bot.auto.autoMine.Automine)
                    {
                        miningInfo += "--- mining info ---\n";
                        miningInfo += $"Current mine level ({bot.Player.currentMineLevel})\n";
                        miningInfo += $"{bot.auto.autoMine.autoMinePath.Count} nodes left\n";
                        miningInfo += $"completion time: {MathF.Round(bot.auto.autoMine.estimatedCompletionTime, 2)}";
                    }
                }
                
                
                fefe.WithValue($"{status}\n{ping}\nGems: {bot.mgemCount}\n{miningInfo}");
                fefe.WithIsInline(true);
                embed.AddField(fefe);
                i++;

            }
            embed.WithFooter(new EmbedFooterBuilder().WithIconUrl("https://images-ext-1.discordapp.net/external/3MYDXr6RzJrAby5O7RN5PZC0PV5YaGoJhCMxgqDyYG8/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/959197199860903956/d707532028b95e8f78239daebe3dc2bd.png?width=320&height=320")
                .WithText("made by krak"));


            DateTime uptime = new DateTime(Program.UPTIME.Elapsed.Ticks);
            string upt = uptime.ToString("H 'hours' m 'mins' s 'secs'");
            if (uptime.Day > 1) upt = uptime.ToString("d 'days' H 'hours' m 'mins' s 'secs'");
            string seperator = "- - - - - - - - - - - -";
            embed.WithDescription($"{seperator}\n{descript}**Total Gems: {totalGems}\nUptime: {upt}**\n{seperator}");
            Embed[] embeds = { embed.Build() };
            await wbc.ModifyMessageAsync(msg, props => { props.Embeds = embeds; });
        }

        public static async Task SendStopped()
        {
            if (!WebhookMessageSent)
            {
                return;
            }

            DiscordWebhookClient wbc = new DiscordWebhookClient(wbURl);
            WebhookMessageProperties props = new WebhookMessageProperties();
            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.WithTitle($"Arhi Bots info");
            embed.WithThumbnailUrl("https://media.discordapp.net/attachments/1074756916011618324/1081686624666132530/logo.png?width=929&height=671");
            embed.WithDescription("Webhook was stopped");
            embed.WithFooter(new EmbedFooterBuilder().WithIconUrl("https://images-ext-1.discordapp.net/external/3MYDXr6RzJrAby5O7RN5PZC0PV5YaGoJhCMxgqDyYG8/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/959197199860903956/d707532028b95e8f78239daebe3dc2bd.png?width=320&height=320")
                .WithText("made by krak"));
            Embed[] embeds = { embed.Build() };
            await wbc.ModifyMessageAsync(msg, props => { props.Embeds = embeds; });
        }


        public static bool RenderWebhookSetupMenu()
        {
            if (Globals.WebhookSetup) return false;

            ImGui.Begin("Webhook setup (Arhi bots made by krak)");

            ImGui.Text("It looks like you haven't setup a webhook!");
            ImGui.PushItemWidth(ImGui.GetWindowWidth());
            ImGui.InputText("##webhookinputtext123", ref Globals.webhook, 500);
            ImGui.PopItemWidth();
            ImGui.Text("Would you like to use a webhook?");
            if (ImGui.Button("yes", new(75, 50)))
            {
                Globals.WebhookSetup = true;
                Globals.UseWebhook = true;
                Config.SaveSettings();
                SendBotsStatus();
            }

            ImGui.SameLine();

            if (ImGui.Button("nah", new(75, 50)))
            {
                Globals.WebhookSetup = true;
                Globals.UseWebhook = false;
                Config.SaveSettings();
            }


            ImGui.End();

            return true;
        }

        public async static Task SendBugMessage(DSharpPlus.Entities.DiscordUser user, string topic,  string description)
        {
            DiscordWebhookClient wbc = new DiscordWebhookClient("https://discord.com/api/webhooks/1101454563233497148/HBUJaqhX6aeYSvPsopLX_B4hdv_EFhyl-5uM-Arx1jFSVPe5HRMY-QN5eQ64lj7MsdWS");
            WebhookMessageProperties props = new WebhookMessageProperties();
            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.WithAuthor(user.Username + "#" + user.Discriminator, user.AvatarUrl);
            embed.WithTitle(topic);
            embed.WithDescription(description);
            embed.WithFooter(new EmbedFooterBuilder().WithIconUrl("https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662")
                .WithText("made by penjamin#0236"));
            Embed[] embeds = { embed.Build() };
            await wbc.SendMessageAsync("", false, embeds.AsEnumerable());
        }

        public async static Task SendWithdrawLog(DSharpPlus.Entities.DiscordUser user, bool depositing, int amount)
        {
            DiscordWebhookClient wbc = new DiscordWebhookClient("https://discord.com/api/webhooks/1104701090747928586/3Z8wUxSuTtUcpDrRY8jeC-vagnWzEweAduBPUgvT4Eq_fcyJ8BnlEnaUoOBuCR7RKdzh");
            WebhookMessageProperties props = new WebhookMessageProperties();
            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.WithAuthor(user.Username + "#" + user.Discriminator, user.AvatarUrl);
            embed.WithTitle("Deposit / withdraw log");
            embed.WithDescription(user.Username + " has " + ((depositing) ? "deposited" : "withdrawed") + " " + amount + " bytes!\nDiscord id: " + user.Id);
            embed.WithFooter(new EmbedFooterBuilder().WithIconUrl("https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662")
                .WithText("made by penjamin#0236"));
            Embed[] embeds = { embed.Build() };
            await wbc.SendMessageAsync("", false, embeds.AsEnumerable());
        }

        public static void ResetWindow()
        {
            Globals.WebhookSetup = false;
            Config.SaveSettings();
        }
    }
}
