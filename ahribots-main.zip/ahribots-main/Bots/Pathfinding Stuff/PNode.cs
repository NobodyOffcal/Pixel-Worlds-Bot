using ArhiBots.Structs;
using Priority_Queue;
using System.Collections;
using System.Collections.Generic;
namespace ArhiBots.Pathfinding;

public class PNode : FastPriorityQueueNode
{
    public int x { get; private set; }
    public int y { get; private set; }

    private PNode(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public static PNode Create(int x, int y)
    {
        return new PNode(x, y);
    }

    public static implicit operator Vector2i(PNode pn)
    {
        return new Vector2i(pn.x, pn.y);
    }

    public override bool Equals(object obj)
    {
        var other = (PNode)obj;
        return x == other.x && y == other.y;
    }

    public override int GetHashCode()
    {
        return x + y * 7;
    }

    public override string ToString()
    {
        return x + ", " + y;
    }
}
