using System.Collections;
using System.Collections.Generic;
using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Structs;
using Priority_Queue;
namespace ArhiBots.Pathfinding;
public class Pathfinding
{
	public Bot bot;

    public const int Max = 5000;

    public const float DIAGONAL_DST = 1.41421356237f;

	private FastPriorityQueue<PNode> open = new(Max);
	private Dictionary<PNode, PNode> cameFrom = new();
	private Dictionary<PNode, float> costSoFar = new();
	private List<PNode> near = new();
	private bool left, right, below, above;

	public Pathfinding(Bot bot)
    {
		this.bot = bot;
    }

	public PathfindingResult Run(int startx, int starty, int endx, int endy, TileProvider provider,
		out List<PNode> path)
	{	
		provider.currentPos = new Vector2i(startx, starty);

		if (provider == null)
		{
			path = null;
			return PathfindingResult.Path_Not_Found;
		}

		// Validate start and end points.
		if (!provider.TileInBounds(startx, starty))
		{
			/*path = null;
            return PathfindingResult.ERROR_START_OUT_OF_BOUNDS;*/
		}

		if (!provider.TileInBounds(endx, endy))
		{
			path = null;
			return PathfindingResult.ERROR_END_OUT_OF_BOUNDS;
		}

		if (!provider.IsTileWalkable(startx, starty))
		{
			/*path = null;
            return PathfindingResult.Start_Not_Valid;*/
		}

		if (!provider.IsTileWalkable(endx, endy) && !provider.IsBlockCloudOn(endx, endy) && !provider.IsBlockInstaKillOn(endx, endy) && !ConfigData.IsBlockPlatform(bot.world.GetBlockType(endx, endy)))
		{
			path = null;
			return PathfindingResult.Invalid_Ending_Pos;
		}

		// Clear everything up.
		Clear();

		var start = PNode.Create(startx, starty);
		var end = PNode.Create(endx, endy);

		// Check the start/end relationship.
		if (start.Equals(end))
		{
			/*path = null;
            return PathfindingResult.Same_Block;*/
		}

		// Add the starting point to all relevant structures.
		open.Enqueue(start, 0f);
		cameFrom[start] = start;
		costSoFar[start] = 0f;

		int count;
		while ((count = open.Count) > 0)
		{
			// Detect if the current open amount exceeds the capacity.
			// This only happens in very large open areas. Corridors and hallways will never cause this, not matter how large the actual path length.
			if (count >= Max - 8)
			{
				path = null;
				return PathfindingResult.ERROR_PATH_TOO_LONG;
			}

			var current = open.Dequeue();
			provider.currentPos = new Vector2i(current.x, current.y);
			if (current.Equals(end))
			{
				// We found the end of the path!
				path = TracePath(end);
				return PathfindingResult.SUCCESSFUL;
			}

			// Get all neighbours (tiles that can be walked on to)
			var neighbours = GetNear(current, provider);
			foreach (var n in neighbours)
			{
				var newCost =
					costSoFar[current] +
					GetCost(current, n); // Note that this could change depending on speed changes per-tile.

				if (!costSoFar.ContainsKey(n) || newCost < costSoFar[n])
				{
					costSoFar[n] = newCost;
					var priority = newCost + Heuristic(current, n);
					open.Enqueue(n, priority);
					cameFrom[n] = current;
				}
			}
		}

		path = null;
		return PathfindingResult.Path_Not_Found;
	}

	private List<PNode> TracePath(PNode end)
	{
		var path = new List<PNode>();
		var child = end;

		var run = true;
		while (run)
		{
			var previous = cameFrom[child];
			path.Add(child);
			if (previous != null && child != previous)
				child = previous;
			else
				run = false;
		}

		path.Reverse();
		return path;
	}

	public void Clear()
	{
		costSoFar.Clear();
		cameFrom.Clear();
		near.Clear();
		open.Clear();
	}

	private float Abs(float x)
	{
		if (x < 0)
			return -x;
		return x;
	}

	private float Heuristic(PNode a, PNode b)
	{
		// Gives a rough distance.
		return Abs(a.x - b.x) + Abs(a.y - b.y);
	}

	private float GetCost(PNode a, PNode b)
	{
		// Only intended for neighbours.

		// Is directly horzontal
		if (Abs(a.x - b.x) == 1 && a.y == b.y) return 1;

		// Directly vertical.
		if (Abs(a.y - b.y) == 1 && a.x == b.x) return 1;

		// Assume that it is on one of the corners.
		return DIAGONAL_DST;
	}

	private List<PNode> GetNear(PNode node, TileProvider provider)
	{
		// Want to add nodes connected to the center node, if they are walkable.
		// This code stops the pathfinder from cutting corners, and going through walls that are diagonal from each other.

		near.Clear();

		// Left
		left = provider.IsTileWalkable(node.x - 1, node.y);

		// Right
		right = provider.IsTileWalkable(node.x + 1, node.y);

		// Above
		above = provider.IsTileWalkable(node.x, node.y + 1);

		// Below
		below = provider.IsTileWalkable(node.x, node.y - 1);

		/* ---- */

		bool aboveLeft = provider.IsBlockInstaKillOn(node.x - 1, node.y + 1) || provider.IsTileWalkable(node.x - 1, node.y + 1);
		bool aboveRight = provider.IsBlockInstaKillOn(node.x + 1, node.y + 1) || provider.IsTileWalkable(node.x + 1, node.y + 1);
		bool belowLeft = provider.IsBlockInstaKillOn(node.x - 1, node.y - 1) || provider.IsTileWalkable(node.x - 1, node.y - 1);
		bool belowRight = provider.IsBlockInstaKillOn(node.x + 1, node.y - 1) || provider.IsTileWalkable(node.x + 1, node.y - 1);

		if (above) near.Add(PNode.Create(node.x, node.y + 1));
		if (below && bot.world.GetBlockType(node.x, node.y) != BlockType.EntrancePortal) near.Add(PNode.Create(node.x, node.y - 1)); /* Entrance Check */

		if (left) near.Add(PNode.Create(node.x - 1, node.y));
		if (right) near.Add(PNode.Create(node.x + 1, node.y));

		if (aboveLeft && (above || left)) near.Add(PNode.Create(node.x - 1, node.y + 1));
		if (aboveRight && (above || right)) near.Add(PNode.Create(node.x + 1, node.y + 1));
		if (belowLeft && (below || left)) near.Add(PNode.Create(node.x - 1, node.y - 1));
		if (belowRight && (below || right)) near.Add(PNode.Create(node.x + 1, node.y - 1));

		return near;
	}
}
