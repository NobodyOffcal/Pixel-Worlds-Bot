
using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Structs;

namespace ArhiBots.Pathfinding;
public abstract class TileProvider
{
	public Bot bot;
    public Vector2i currentPos = new();
    public int Width { get; private set; }
	public int Height { get; private set; }

	public TileProvider(int width, int height)
	{
		Width = width;
		Height = height;
	}

	public virtual void ResetSize(int width, int height)
	{
		Width = width;
		Height = height;
	}

	public virtual bool TileInBounds(int x, int y)
	{
		return x >= 0 && x < Width && y >= 0 && y < Height;
	}

	public abstract bool IsTileWalkable(int x, int y);

	public abstract bool IsBlockInstaKillOn(int x, int y);
	public bool IsBlockInstakill(BlockType blockType)
	{
		return ConfigData.IsBlockInstakill(blockType);
	}

	public bool IsBlockCloud(BlockType blockType)
	{
		return blockType == BlockType.CloudPlatform || blockType == BlockType.TrapdoorMetalPlatform;
	}

	public bool IsBlockCloudOn(int x, int y) { return this.IsBlockCloud(bot.world.GetBlockType(x, y)); }
}