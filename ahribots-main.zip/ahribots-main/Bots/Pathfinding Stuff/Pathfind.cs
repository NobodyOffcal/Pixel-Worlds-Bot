using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Structs;
using ImGuiNET;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Numerics;

namespace ArhiBots.Pathfinding;
public class Pathfind
{
    public Bot bot;

    public bool isMoving = false;
    public bool fromSpawn = false;
    public bool fromSpawnSent = false;
    public bool backFromSpawn = false;
    public bool backFromSpawnSent = false;
    public int sentTicks = 0;


    public List<PNode> RenderPath;
    public List<PNode> movePath;
    public List<PNode> movePathBack;

    public MiningPathfinding miningPathfinding;
    private Pathfinding pather;
    private TileProvider provider;

    #region toTakeActions
    public bool toTake = false;
    public bool takeSent = false;
    #endregion

    public float Movespeed = .23f;
    private float MoveTimer = 0f;

    int Spot_in_path = 0;

    public readonly int MAX_IN_TICK = 15;

    public Pathfind(Bot bot)
    {
        this.bot = bot;
        this.pather = new Pathfinding(bot);
        this.provider = new KrakedAI(1, 1, bot);
        this.miningPathfinding = new MiningPathfinding(bot);
    }

    private void ResetMap()
    {
        this.provider.ResetSize(bot.world.worldSize.x, bot.world.worldSize.y);
    }

    public void Reset()
    {
        RenderPath= new List<PNode>();
        this.isMoving = false;
    }

    public List<Vector2i> GetEverythingsPositions()
    {
        List<Vector2i> positions= new List<Vector2i>();

        for (int y = bot.world.worldSize.y - 1; y >= 0; y--)
        {
            for (int x = 0; x < bot.world.worldSize.x; x++)
            {
                BlockType block = bot.world.GetBlockType(x, y);

                if (block == BlockType.MiningGemStoneTopaz ||
                    block == BlockType.MiningGemStoneRuby ||
                    block == BlockType.MiningGemStoneEmerald ||
                    block == BlockType.MiningGemStoneSapphire ||
                    block == BlockType.MiningGemStoneDiamond)
                {
                    Vector2i pos = new Vector2i(x, y);
                    positions.Add(pos);
                }

            }
        }

        foreach (var collectable in bot.world.collectables)
        {
            Vector2i pos = new Vector2i((int)collectable.PosX, (int)collectable.PosY);
            positions.Add(pos);
        }

        return positions;
    }

    public Vector2i getMineExit()
    {
        for (int y = bot.world.worldSize.y - 1; y >= 0; y--)
        {
            for (int x = 0; x < bot.world.worldSize.x; x++)
            {
                BlockType block = bot.world.GetBlockType(x, y);

                if (block == BlockType.PortalMineExit)
                {
                    return new Vector2i(x, y);


                }

            }
        }
        return new Vector2i();
    }

    public List<PNode> path = new List<PNode>();
    public List<PNode> GetBestMiningPath()
    {
        if (bot.world.WorldName != "MINEWORLD")
        {
            bot.auto.autoMine.ResetSomethings();
            return new List<PNode>();
        }
            List<Vector2i> items = bot.world.GetDroppedItemsPositions();
        List<Vector2i> visitedItems = new List<Vector2i>();
        Vector2i currentPlayerPos = bot.Player.currentPlayerMapPoint;
        path = new List<PNode>();

        // Check if there are any unvisited items left
        if (items.Count == 0)
        {
            path.AddRange(FindMiningPath(currentPlayerPos, getMineExit()));
            Console.WriteLine("Found mine exit");
            return path;
        }

        int maxIterations = items.Count;
        int iterations = 0;
        while (visitedItems.Count < items.Count && iterations < maxIterations)
        {
            // Find nearest unvisited item to the current position
            float minDistance = float.MaxValue;
            Vector2i nearestItem = new Vector2i();
            foreach (Vector2i item in items)
            {
                if (!visitedItems.Contains(item))
                {
                    float distance = Vector2i.Distance(currentPlayerPos, item);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        nearestItem = item;
                    }
                }
            }

            // If no unvisited items found, break the loop
            if (nearestItem.Equals(new Vector2i()))
            {
                break;
            }

            List<PNode> itemPath = FindMiningPath(currentPlayerPos, nearestItem);
            currentPlayerPos = nearestItem;
            visitedItems.Add(nearestItem);
            path.AddRange(itemPath);
            iterations++;
        }

        path.AddRange(FindMiningPath(currentPlayerPos, getMineExit()));

        return path;
    }


    public List<PNode> GetMiningPath()
    {
        return FindMiningPath(bot.Player.currentPlayerMapPoint, NearestItem());
    }

    public Vector2i NearestItem()
    {
        Vector2i nearestBlock = new Vector2i();
        Vector2i nearestCollectables = new Vector2i();

        float minBlockDistance = float.MaxValue;
        float minCollectableDistance = float.MaxValue;

        for (int y = bot.world.worldSize.y - 1; y >= 0; y--)
        {
            for (int x = 0; x < bot.world.worldSize.x; x++)
            {
                BlockType block = bot.world.GetBlockType(x, y);

                if (block == BlockType.MiningGemStoneTopaz ||
                    block == BlockType.MiningGemStoneRuby ||
                    block == BlockType.MiningGemStoneEmerald ||
                    block == BlockType.MiningGemStoneSapphire ||
                    block == BlockType.MiningGemStoneDiamond)
                {
                    Vector2i pos = new Vector2i(x, y);
                    float blockDistance = Vector2i.Distance(bot.Player.currentPlayerMapPoint, pos);

                    if (blockDistance < minBlockDistance)
                    {
                        minBlockDistance = blockDistance;
                        nearestBlock = pos;
                    }
                }
                
            }
        }

        foreach (var collectable in bot.world.collectables)
        {
            Vector2i pos = new Vector2i((int)collectable.PosX, (int)collectable.PosY);
            float collectableDistance = Vector2i.Distance(bot.Player.currentPlayerMapPoint, pos);

            if (collectableDistance < minCollectableDistance)
            {
                minCollectableDistance = collectableDistance;
                nearestCollectables = pos;
            }
        }

        if (minBlockDistance < minCollectableDistance)
        {
            return nearestBlock;
        }
        else
        {
            return nearestCollectables;
        }
    }

    public List<PNode> FindMiningPath(Vector2i start, Vector2i end)
    {
        return miningPathfinding.FindPath(PNode.Create(start.x, start.y), PNode.Create(end.x, end.y));
    }

    public PathfindingResult GoToMap(int fromX, int fromY, int toX, int toY, bool log = true)
    {
        if (log) Logger.Log($"PathFinding gotomap: {toX}, {toY}");

        if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
            return PathfindingResult.Not_in_world;

        if (this.isMoving)
        {
            if (log) Logger.Log("already Teleporting lol");  
            return PathfindingResult.CANCELLED;
        }
        fromSpawn = false;
        this.ResetMap();
        Vector2i worldSpawn = bot.world.WorldStartPoint;

        List<PNode> pathTo;
        PathfindingResult pathToResult = this.pather.Run(fromX, fromY, toX, toY, this.provider, out pathTo);

        List<PNode> pathToSpawn;
        PathfindingResult pathToSpawnResult;

        if (bot.world.WorldName != "MINEWORLD")
        {
            
            pathToSpawnResult = this.pather.Run(worldSpawn.x, worldSpawn.y, toX, toY, this.provider, out pathToSpawn);


            if (pathToSpawnResult == PathfindingResult.SUCCESSFUL && (pathToResult != PathfindingResult.SUCCESSFUL || pathToSpawn.Count < pathTo.Count))
            {
                pathTo = pathToSpawn;
                pathToResult = pathToSpawnResult;
                fromSpawn = true;
            }
        }

        
        Spot_in_path = 0;

        

        if (pathToResult != PathfindingResult.SUCCESSFUL)
        {
            if (log) Logger.Log($"PathTo not found: {pathToResult.ToString()}");
            return pathToResult;
        }
        if (!fromSpawn)
            pathTo.RemoveAt(0);

        if (log) Logger.Log($"Teleporting {pathTo.Count} Tiles... (~{pathTo.Count / this.MAX_IN_TICK * 1.5f}s.)");

        RenderPath = pathTo;
        this.fromSpawn = fromSpawn;
        this.fromSpawnSent = false;
        this.movePath = pathTo;
        this.isMoving = true;
        this.sentTicks = 0;

        return pathToResult;
    }

    public bool IsTileWalkable(int x, int y) => provider.IsTileWalkable(x, y);
    public bool IsTileWalkable(Vector2i v) => provider.IsTileWalkable(v.x, v.y);

    public void MoveToTarget()
    {
        if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
        {
            return;
        }

        if (!isMoving) return;

        MoveTimer += Time.deltaTime;

        if (MoveTimer >= Movespeed && isMoving)
        {
            MoveTimer = 0;

            if (fromSpawn && !fromSpawnSent)
            {
                fromSpawnSent = true;
                bot.NetworkClient.outgoingMessages.SendResurrect(Bot.GetTimeStamp(), bot.world.WorldStartPoint);
                bot.Player.CurrentPosition = PositionConversions.ConvertMapPointToPlayersWorldPointFromFeet(bot.world.WorldStartPoint);

                movePath.RemoveAt(0);

                return;
            }

            if (movePath.Count < 1)
            {
                isMoving = false;
                fromSpawn = false;
                fromSpawnSent = false;
                backFromSpawn = false;
                backFromSpawnSent = false;
                return;
            }

            bot.Player.CurrentPosition = PositionConversions.ConvertMapPointToPlayersWorldPointFromFeet(movePath[0]);
            if (ConfigData.IsBlockInstakill(bot.world.GetBlockType(movePath[0])))
            {
                MoveTimer += Movespeed;
            }
            movePath.RemoveAt(0);

            
        }
    }
}