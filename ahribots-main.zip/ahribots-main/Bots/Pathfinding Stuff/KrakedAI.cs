using ArhiBots.Bots;
using ArhiBots.Bots.Constants;
using ArhiBots.Constants;
using ArhiBots.Misc;
using ArhiBots.Pathfinding;
using ArhiBots.Structs;
using ClickableTransparentOverlay.Win32;
using System.Collections;
using System.Collections.Generic;
namespace ArhiBots.Pathfinding;
public class KrakedAI : TileProvider
{

    public bool[,] map;
    
    public KrakedAI(int width, int height, Bot bot) : base(width, height)
    {
        this.bot = bot;
        map = new bool[width, height];
    }

    public override void ResetSize(int width, int height)
    {
        base.ResetSize(width, height);
        map = new bool[width, height];
    }

    public override bool IsTileWalkable(int x, int y)
    {
        var blockType = bot.world.GetBlockType(new Vector2i(x, y));
        var lastPos = bot.world.GetBlockType(currentPos);
        var aboveBlock = bot.world.GetBlockType(new Vector2i(x, y + 1));

        if (aboveBlock == BlockType.EntrancePortal || aboveBlock == BlockType.PortalMiningEntry)
        {
            if (currentPos.y == y + 1)
                return false;
        }

        if (!bot.world.IsMapPointInWorld(new Vector2i(x, y))) return false;

        if (this.IsBlockCloud(blockType)) return true;

        if (ConfigData.IsBlockPlatform(blockType) || blockType == BlockType.EntrancePortal)
            if (currentPos.y <= y)
                return true;

        //if (ConfigData.IsAnyDoor(blockType))
          //  if (krak.KrakMonoBehaviour.worldController.DoesPlayerHaveRightToGoDoorForCollider(new Vector2i(x, y)))
            //    return true;
        if (ConfigData.IsBlockGate(blockType) || ConfigData.IsAnyDoor(blockType))
        {
            BSONObject bson = bot.world.worldsItemBson[x][y];

            if (bson != null)
            {
                if (bson.ContainsKey("isOpen"))
                {
                    if (bson["isOpen"].boolValue)
                    {
                        return true;
                    }
                }
            }

        }

        if (blockType == BlockType.NetherKey || blockType == BlockType.JetRaceForcefieldStart ||
            blockType == BlockType.JetRaceFinishline || blockType == BlockType.JetRaceCrestGold || 
            blockType == BlockType.PortalMineExit)
            return true;

        if (ConfigData.DoesBlockHaveCollider(blockType))
            return false;

        return true;
    }

    public override bool IsBlockInstaKillOn(int x, int y)
    {
        return this.IsBlockInstakill(bot.world.GetBlockType(new Vector2i(x, y)));
    }
}
