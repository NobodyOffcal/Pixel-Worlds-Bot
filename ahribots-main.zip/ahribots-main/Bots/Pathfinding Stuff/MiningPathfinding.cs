﻿using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Structs;
using Google.OrTools.ConstraintSolver;
using Google.OrTools.Sat;
using System.ComponentModel;
using static Google.OrTools.ConstraintSolver.RoutingSearchParameters.Types;

namespace ArhiBots.Pathfinding
{
    public class MiningPathfinding
    {
        public Bot bot { get; set; }

        private Func<PNode, int> _getWeight;
        private PNode _start;
        private PNode _goal;
        private int _width;
        private int _height;

        private BlockType GetBlockType(PNode node)
        {
            var block = bot.world.GetBlockType((Vector2i)node);
            if (!bot.Player.pathfind.path.Contains(node) || block == BlockType.PortalMiningEntry)
            {
                return block;
            }
            return BlockType.None;
        }

        public MiningPathfinding(Bot bot)
        {
            this.bot = bot;
            _getWeight = node => {
                var blockType = GetBlockType(node);

                switch (blockType)
                {
                    case BlockType.Bedrock:
                    case BlockType.PortalMineExit:
                    case BlockType.PortalMiningEntry:
                        return 1000;
                    case BlockType.None:
                        return 1;
                    case BlockType.MiningSoil1:
                    case BlockType.MiningSoil2:
                    case BlockType.MiningSoil3:
                    case BlockType.MiningSoil4:
                    case BlockType.MiningSoil5:
                    case BlockType.MiningGemStoneTopaz:
                    case BlockType.MiningGemStoneEmerald:
                    case BlockType.MiningGemStoneSapphire:
                        return 2;


                    case BlockType.MiningRockSoft1:
                    case BlockType.MiningRockMedium1:
                    case BlockType.MiningRockHard1:
                    case BlockType.MiningRockHard2:
                    case BlockType.MiningRockHard3:
                    case BlockType.MiningWoodBlock1:
                    case BlockType.MiningGemStoneRuby:
                        return 3;

                    case BlockType.MiningBedrock1:
                    case BlockType.MiningBedrock2:
                    case BlockType.MiningBedrock3:
                    case BlockType.MiningGemStoneDiamond:
                        return 4;

                        

                    

                }
                return 1;
            };

        }

        public int Heuristic(PNode a, PNode b)
        {
            return Math.Abs(a.x - b.x) + Math.Abs(a.y - b.y);
        }

        public List<PNode> FindPath(PNode start, PNode goal)
        {
            _start = start;
            _goal = goal;
            _width = bot.world.worldSize.x;
            _height = bot.world.worldSize.y;
            var closedSet = new HashSet<PNode>();
            var openSet = new HashSet<PNode> { _start };
            var cameFrom = new Dictionary<PNode, PNode>();
            var gScore = new Dictionary<PNode, int> { { _start, 0 } };
            var fScore = new Dictionary<PNode, int> { { _start, Heuristic(_start, _goal) } };

            while (openSet.Count > 0)
            {
                var current = _start;
                var currentFScore = int.MaxValue;
                foreach (var node in openSet)
                {
                    if (!fScore.ContainsKey(node))
                    {
                        fScore[node] = int.MaxValue;
                    }

                    if (fScore[node] < currentFScore)
                    {
                        currentFScore = fScore[node];
                        current = node;
                    }
                }

                if (current.Equals(_goal))
                {
                    return ReconstructPath(cameFrom, current);
                }

                openSet.Remove(current);
                closedSet.Add(current);

                var neighbors = GetNeighbors(current);
                foreach (var neighbor in neighbors)
                {
                    if (closedSet.Contains(neighbor))
                    {
                        continue;
                    }

                    var tentativeGScore = gScore[current] + _getWeight(neighbor);
                    if (!openSet.Contains(neighbor))
                    {
                        openSet.Add(neighbor);
                    }
                    else if (tentativeGScore >= gScore[neighbor])
                    {
                        continue;
                    }

                    cameFrom[neighbor] = current;
                    gScore[neighbor] = tentativeGScore;
                    fScore[neighbor] = gScore[neighbor] + Heuristic(neighbor, _goal);
                }
            }

            return null;
        }

        private List<PNode> ReconstructPath(Dictionary<PNode, PNode> cameFrom, PNode current)
        {
            List<PNode> path = new List<PNode>();
            path.Add(current);

            while (cameFrom.ContainsKey(current))
            {
                current = cameFrom[current];
                path.Add(current);
            }

            path.Reverse();
            return path;
        }

        private List<PNode> GetNeighbors(PNode node)
        {
            List<PNode> neighbors = new List<PNode>();

            for (int x = -1; x <= 1; x++)
            {
                for (int y = -1; y <= 1; y++)
                {
                    if (x == 0 && y == 0)
                    {
                        continue;
                    }

                    if (Math.Abs(x) == 1 && Math.Abs(y) == 1)
                    {
                        continue;
                    }

                    int checkX = node.x + x;
                    int checkY = node.y + y;

                    if (checkX >= 0 && checkX < _width && checkY >= 0 && checkY < _height)
                    {
                        neighbors.Add(PNode.Create(checkX, checkY));
                    }
                }
            }

            return neighbors;
        }


     





    }
}

