﻿using ArhiBots.Constants;
using ArhiBots.Networking;
using ArhiBots.Pathfinding;
using ArhiBots.Structs;
using ClickableTransparentOverlay.Win32;
using ImGuiNET;
using SixLabors.ImageSharp.ColorSpaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using ArhiBots.Misc;

namespace ArhiBots.Bots
{
    public class Player : Behaviour
    {
        public Bot bot { get; private set; }

        public Player(Bot bot)
        {
            this.bot = bot;
            
        }

        public World world { get { return bot.world; } }

        public bool isLocalPlayer;
        public PlayerData myPlayerData = new();
        public Pathfind pathfind;
        public bool justWarped;
        public bool spawned = false;

        public Vector2 CurrentPosition;
        public Vector2i lastMapPoint = new Vector2i(-1, -1);
        public Vector2i lastPos;
        private Vector2 lastPositionSendToServer;
        public AnimationNames Anim;
        private AnimationNames lastAnimation;
        public Direction direction;
        private Direction lastDirection;
        public Vector2i currentPlayerMapPoint;

        public int currentMineLevel = 0;

        public string previousWorldName = "";

        public Vector2i LastSentHitSpot = new();


        private List<int> recentCollectableAttempts = new();
        float timerForCollect = 0;

        int currentPings = 0;
        static int PingsForSleep = 300;


        // Start is called before the first frame update
        public override void Start()
        {
            Anim = AnimationNames.Idle;
            direction = Direction.Left;
            pathfind = new(bot);
            if (bot != null) isLocalPlayer = true;
        }

        // Update is called once per frame
        public override void Update()
        {
            if (!this.isLocalPlayer || bot.NetworkClient == null || bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom && !spawned)
            {
                return;
            }
            
            UpdatePositions();

            ResetCollectableTime();
            CheckIfWeCanCollectThenCollect();
            CheckToConvert();
            GemOverload();

            bot.auto.PlayerUpdate();
            pathfind.MoveToTarget();
            
            SendMovementOrPingToServerIfNeeded();
            Spam();
            
            if (currentDelayOfHit <= hitDelay)
                currentDelayOfHit += Time.deltaTime;
            
        }

        static string ChatInput = "";
        static float ChatSpamDelay = 4f;
        static bool spam = false;
        float spamTimer = 0f;
        public void Spam()
        {
            if (!spam) return;
            spamTimer += Time.deltaTime;
            if (spamTimer >= ChatSpamDelay)
            {
                spamTimer = 0f;
                if (bot.NetworkClient.playerConnectionStatus == PlayerConnectionStatus.InRoom)
                {
                    bot.OutgoingMessages.SendMessage(ChatInput);
                }
            }
        }

        enum whatDoWeDo
        {
            Break,
            Place
        }
        public void LeaveWorld()
        {
            bot.OutgoingMessages.AddOneMessageToList(new BSONObject()
            {
                ["ID"] = "LW"
            });
        }

        whatDoWeDo whatWedoing = whatDoWeDo.Break;
        InventoryKey selectedBlock = new InventoryKey(BlockType.None, InventoryItemType.Block);
        float hitDelay = .3f;
        float currentDelayOfHit = 0.00f;

        string worldWarpName = "";
        public void CheckIfWeCanCollectThenCollect()
        {
            if (!this.bot.ForceCollect) return;

            foreach (CollectableData collectable in bot.world.collectables)
            {
                Vector2i collectablePoint = new((int)MathF.Round(collectable.PosX), (int)MathF.Round(collectable.PosY));

                if (bot.RangedCollect || world.WorldName.ToUpper() == "MINEWORLD" || bot.auto.autoFarm.auto)
                {
                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            Vector2i mapPointOfPlayer = new Vector2i(currentPlayerMapPoint.x + i, currentPlayerMapPoint.y + j);

                            if (mapPointOfPlayer == collectablePoint)
                            {
                                
                                if (pathfind.IsTileWalkable(collectablePoint) && !recentCollectableAttempts.Contains(collectable.CollectableId))
                                {
                                    recentCollectableAttempts.Add(collectable.CollectableId);
                                    CollectItem(collectable);
                                }
                                
                                /*if (!recentCollectableAttempts.Contains(collectable.CollectableId))
                                {
                                    recentCollectableAttempts.Add(collectable.CollectableId);
                                    CollectItem(collectable);
                                }*/
                            }
                        }
                    }
                }
                else
                {
                    if (collectablePoint == currentPlayerMapPoint && !recentCollectableAttempts.Contains(collectable.CollectableId))
                    { 
                        recentCollectableAttempts.Add(collectable.CollectableId);
                        CollectItem(collectable);
                    }
                }
                
            }
        }

        void ResetCollectableTime()
        {
            timerForCollect += Time.deltaTime;
            if (timerForCollect >= 0.5f)
            {
                timerForCollect = 0;
                recentCollectableAttempts.Clear();
            }
        }

        public void WarpFromWorldToWorld(string wn)
        {

            wn = wn.ToUpper();
            bot.NetworkPlayers.otherPlayers.Clear();
            if (world!=null)
            {
                if (world.WorldName == "MINEWORLD" && wn == "MINEWORLD")
                {
                    previousWorldName = wn;
                    bot.NetworkClient.UpdateConnectionStatus(PlayerConnectionStatus.InMenus);
                    bot.OutgoingMessages.ClearRecentMapPoints();
                    bot.worldOnLoad = bot.StartingWorld;
                    bot.NetworkClient.joinWorldOnConnect = bot.StartingWorld;
                    bot.NetworkClient.WorldLoader.CheckIfWeCanGoFromWorldToWorld(bot.StartingWorld, "", null);
                    return;
                }

                previousWorldName = bot.world.WorldName;
            }
            
            
            bot.NetworkClient.UpdateConnectionStatus(PlayerConnectionStatus.InMenus);
            bot.OutgoingMessages.ClearRecentMapPoints();
            bot.worldOnLoad = wn;
            bot.NetworkClient.joinWorldOnConnect = wn;
            bot.NetworkClient.WorldLoader.CheckIfWeCanGoFromWorldToWorld(wn, "", null);
        }

        public void JoinMineWorld(int level)
        {
            currentMineLevel = level;
            level--;
            BSONArray bsonArr = new()
            {
                level
            };

            BSONObject pkt = new BSONObject() { ["ID"] = "wlA", ["WCSD"] = bsonArr };

            bot.OutgoingMessages.AddOneMessageToList(pkt);

            WarpFromWorldToWorld("MINEWORLD");
        }

        public void JoinHighestPossibleMine()
        {
            var inv = myPlayerData.GetInventoryAsOrderedByInventoryItemType();

            int mineLevel = 1;

            foreach(var item in inv)
            {
                int currentItemMineLevel = 1;
                if (item.blockType == BlockType.ConsumableMineKeyLevel5)
                {
                    if (Globals.MineLevel5)
                    {
                        currentItemMineLevel = 5;
                    }
                    
                }

                if (item.blockType == BlockType.ConsumableMineKeyLevel4)
                {
                    if (Globals.MineLevel4)
                    {
                        currentItemMineLevel = 4;
                    }
                }

                if (item.blockType == BlockType.ConsumableMineKeyLevel3)
                {
                    if (Globals.MineLevel3)
                    {
                        currentItemMineLevel = 3;
                    }
                }

                if (item.blockType == BlockType.ConsumableMineKeyLevel2)
                {
                    if (Globals.MineLevel2)
                    {
                        currentItemMineLevel = 2;
                    }
                }

                if (currentItemMineLevel > mineLevel)
                {
                    mineLevel = currentItemMineLevel;
                }

            }

            JoinMineWorld(mineLevel);
        }

        public int GetTotalGems()
        {
            int gems = 0;
            if (myPlayerData.inventory == null) return 0;
            foreach (var item in myPlayerData.GetInventoryAsOrderedByInventoryItemType())
            {
                gems += ConfigData.GetGemAmount(item.blockType) *myPlayerData.GetCount(item);
            }
            return gems;
        }

        public AnimationNames GetCurrentAnimation()
        {
            return Anim;
        }

        public void BuyInventorySpace(int amount)
        {

            UseResult useResult = myPlayerData.UseGemsIfPossible(ConfigData.GetInventoryUpgradePrice(amount));
            if (useResult == UseResult.Success)
            {
                bot.NetworkClient.outgoingMessages.SendBuyInventorySlots();
            }
        }

        private void UpdatePositions()
        {
            currentPlayerMapPoint = PositionConversions.ConvertPlayersWorldPointToMapPointFromFeet(CurrentPosition.X, CurrentPosition.Y);
        }

        public void FindPath(Vector2i to)
        {
            Logger.Log("Findng path to: " + to.ToString());
            pathfind.GoToMap(currentPlayerMapPoint.x, currentPlayerMapPoint.y, to.x, to.y);
        }


        public bool IsItemEquiped(BlockType blockType)
        {
            AnimationHotSpots[] animationHotSpots = GenericStorage.GetAnimationHotSpots(blockType);
            for (int i = 0; i < animationHotSpots.Length; i++)
            {
                if (this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]) != PlayerData.GetAnimationHotSpotDefaultBlockType(animationHotSpots[i], this.myPlayerData.gender))
                {
                    BlockType playerHotSpot = this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]);
                    if (playerHotSpot == blockType)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public bool ChangeWearable(BlockType blockType)
        {
            //ChangeWearable2(blockType);
            InventoryItemType itemType = ConfigData.GetBlockTypeInventoryItemType(blockType);
            if (IsItemEquiped(blockType))
            {
                bot.NetworkClient.outgoingMessages.SendWearableOrWeaponUndress(blockType);
                ChangeWearableToDefault(blockType);
                return false;
            }

            if (itemType == InventoryItemType.WearableItem || itemType == InventoryItemType.Weapon)
            {
                bot.NetworkClient.outgoingMessages.SendWearableOrWeaponChange(blockType);

                AnimationHotSpots[] animationHotSpots = GenericStorage.GetAnimationHotSpots(blockType);
                List<BlockType> list = new List<BlockType>();
                for (int i = 0; i < animationHotSpots.Length; i++)
                {
                    if (this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]) != PlayerData.GetAnimationHotSpotDefaultBlockType(animationHotSpots[i], this.myPlayerData.gender))
                    {
                        BlockType playerHotSpot = this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]);
                        this.ChangeWearableToDefault(this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]));
                        if (!list.Contains(playerHotSpot))
                        {
                            list.Add(playerHotSpot);
                        }
                    }
                    this.myPlayerData.SetPlayerHotSpot((int)animationHotSpots[i], blockType);
                }
                return true;
            }


            return false;

        }

        public List<BlockType> ChangeWearable2(BlockType blockType)
        {
            AnimationHotSpots[] animationHotSpots = GenericStorage.GetAnimationHotSpots(blockType);
            List<BlockType> list = new List<BlockType>();
            for (int i = 0; i < animationHotSpots.Length; i++)
            {
                if (this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]) != PlayerData.GetAnimationHotSpotDefaultBlockType(animationHotSpots[i], this.myPlayerData.gender))
                {
                    BlockType playerHotSpot = this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]);
                    this.ChangeWearableToDefault(this.myPlayerData.GetPlayerHotSpot((int)animationHotSpots[i]));
                    if (!list.Contains(playerHotSpot))
                    {
                        list.Add(playerHotSpot);
                    }
                }
                this.myPlayerData.SetPlayerHotSpot((int)animationHotSpots[i], blockType);
            }
            this.bot.NetworkClient.outgoingMessages.SendWearableOrWeaponUndress(blockType);
            return list;
        }

        public void ChangeWearableToDefault(BlockType originalBlockType)
        {
            AnimationHotSpots[] animationHotSpots = GenericStorage.GetAnimationHotSpots(originalBlockType);
            for (int i = 0; i < animationHotSpots.Length; i++)
            {
                BlockType animationHotSpotDefaultBlockType = PlayerData.GetAnimationHotSpotDefaultBlockType(animationHotSpots[i], this.myPlayerData.gender);
                this.myPlayerData.SetPlayerHotSpot((int)animationHotSpots[i], animationHotSpotDefaultBlockType);
            }
        }

        public void ActualCollectedItem(CollectableData collectableData)
        {
            
            this.bot.WorldController.world.RemoveCollectableIfPossible(collectableData.CollectableId);
            //this.bot.WorldController.RemoveCollectable(collectableData.CollectableId, true);
            PickUpResult pickUpResult = this.myPlayerData.CanPlayerPick(collectableData, false);
            if (pickUpResult == PickUpResult.All)
            {
                this.myPlayerData.AddFromCollectable(collectableData);
            }
            else if (pickUpResult == PickUpResult.Partial)
            {
                short num = this.myPlayerData.HowMuchCanPlayerPick(collectableData.GetInventoryKey());
                this.myPlayerData.AddItemToInventory(collectableData.blockType, collectableData.InventoryType, num);
                if (bot.WorldController.isNetworkClientDisabled)
                {
                    short amount = (short)(collectableData.Amount - num);
                    CollectableData collectableData2 = bot.WorldController.world.AddCollectable(collectableData.blockType, amount, collectableData.InventoryType, collectableData.PosX, collectableData.PosX);
                }
            }
        }

        float timerForConvert = 0f;
        void CheckToConvert()
        {
            if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
            {
                return;
            }
            timerForConvert += Time.deltaTime;

            if (timerForConvert >= .2f) {
                var inv = myPlayerData.GetInventoryAsOrderedByInventoryItemType();
                timerForConvert = 0;
                foreach (var item in inv )
                {
                    switch(item.blockType)
                    {
                        case BlockType.MiningNuggetBronze:
                        case BlockType.MiningNuggetSilver:
                        case BlockType.MiningNuggetGold:
                        case BlockType.MiningNuggetPlatinum:
                        case BlockType.MiningNuggetDark:
                            if (myPlayerData.GetCount(item) >= 100)
                            {
                                ConvertItem(item);
                                return;
                            }
                            break;

                        default:
                            break;
                    }
                }
            }
        }

        public void ConvertItem(InventoryKey item)
        {
            bot.OutgoingMessages.ConvertItem(item);
        }

        public int DropItems(InventoryKey inventoryKey, short amount)
        {
            int count = (int)this.myPlayerData.GetCount(inventoryKey);
            int result = count;
            if (count >= (int)amount && amount > 0)
            {
                this.myPlayerData.RemoveItemsFromInventory(inventoryKey, amount);
                this.bot.WorldController.DropStuffFromInventory(this.GetNextPlayerPositionBasedOnLookDirection(0), inventoryKey, amount);
                result = count - (int)amount;
            }
            return result;
        }


        float GemOverloadTimer = 0.00f;
        void GemOverload()
        {
            if (bot.auto.autoMine.Automine)
            {
                GemOverloadTimer += Time.deltaTime;

                if (GemOverloadTimer > 0.5f)
                {
                    GemOverloadTimer = 0f;
                    var inv = myPlayerData.GetInventoryAsOrderedByInventoryItemType();

                    foreach(var item in inv)
                    {
                        if (ConfigData.IsMiningGem(item.blockType))
                        {
                            if (myPlayerData.GetCount(item) >= 900)
                            {
                                bot.OutgoingMessages.RecycleMiningGem(item, 100);
                                
                            }
                        }
                        if (item.blockType == BlockType.ConsumableMiningToken)
                        {

                            //myPlayerData.RemoveItemsFromInventory(item, 1);
                        }
                    }
                }
            }
        }


        public Vector2i GetNextPlayerPositionBasedOnLookDirection(int moreDistance = 0)
        {
            Vector2i playerMapPoint = this.GetPlayerMapPoint();
            if (this.lastDirection == Direction.Right)
            {
                playerMapPoint.x++;
                playerMapPoint.x += moreDistance;
                if (playerMapPoint.x > this.bot.WorldController.world.worldSize.y)
                {
                    playerMapPoint.x = this.bot.WorldController.world.worldSize.x;
                }
            }
            else
            {
                playerMapPoint.x--;
                playerMapPoint.x -= moreDistance;
                if (playerMapPoint.x < 0)
                {
                    playerMapPoint.x = 0;
                }
            }
            return playerMapPoint;
        }

        public Vector2i GetPlayerMapPoint()
        {
            Vector2 position = CurrentPosition;
            return PositionConversions.ConvertPlayersWorldPointToMapPoint(position.X, position.Y);
        }

        public void CollectItem(CollectableData collectable)
        {
            this.bot.NetworkClient.outgoingMessages.SendCollectCollectable(collectable.CollectableId);
        }

        public void AnimationManager()
        {
            if (CurrentPosition.X != lastPositionSendToServer.X)
            {
                currentPings = 0;
                Anim = AnimationNames.Move;
            }

            if (CurrentPosition == lastPositionSendToServer)
            {
                Anim = AnimationNames.Idle;
                currentPings++;

                if (currentPings >= PingsForSleep)
                {
                    Anim = AnimationNames.Sleep;
                }
            }

            if (world.GetBlockType(currentPlayerMapPoint) == BlockType.Water)
            {
                Anim = AnimationNames.Swim;
            }
        }

        public void SendMovementOrPingToServerIfNeeded()
        {
            if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
            {
                return;
            }

            AnimationManager();

            if (lastMapPoint != currentPlayerMapPoint)
            {

                lastMapPoint = currentPlayerMapPoint;
            }
            bot.NetworkClient.outgoingMessages.AddMapPointIfNotLastAlready(currentPlayerMapPoint);


            bool flag = false;
            //bool teleport = false;
            if (this.Anim != this.lastAnimation)
            {
                flag = true;
            }
            else if (this.direction != this.lastDirection)
            {
                flag = true;
            }
            else if (lastPositionSendToServer != CurrentPosition)
            {

                flag = true;
            }
            else if (this.justWarped)
            {
                this.justWarped = false;
                flag = true;
                //teleport = true;
            }
            if (flag)
            {

                this.lastPositionSendToServer = CurrentPosition;
                this.lastDirection = direction;
                this.lastAnimation = Anim;
                this.bot.NetworkClient.outgoingMessages.SendPlayerPosition(GetMyPosAsBSON());


            }
            else
            {

                bot.NetworkClient.outgoingMessages.SendMovementPing();
            }
        }

        public BSONObject GetMyPosAsBSON()
        {
            return new()
            {
                ["ID"] = "mP",
                ["t"] = Bot.GetTimeStamp(),
                ["x"] = (double)lastPositionSendToServer.X,
                ["y"] = (double)lastPositionSendToServer.Y,
                ["a"] = (int)lastAnimation,
                ["d"] = (int)lastDirection,
            };
        }

        public Vector2i GetNextUNSAFEPlayerPositionBasedOnLookDirection(int moreDistance = 0)
        {
            Vector2i playerMapPoint = this.GetPlayerMapPoint();
            if (this.lastDirection == Direction.Right)
            {
                playerMapPoint.x++;
                playerMapPoint.x += moreDistance;
            }
            else
            {
                playerMapPoint.x--;
                playerMapPoint.x -= moreDistance;
            }
            return playerMapPoint;
        }

    }
}
