﻿using ArhiBots.Constants;
using ArhiBots.Structs;
using ClickableTransparentOverlay.Win32;
using SixLabors.ImageSharp.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImGuiNET;
using System.Numerics;
using ArhiBots.Misc;

namespace ArhiBots.Bots
{
    public class PlayerData
    {

        public Bot bot;
        public string RealUsername = "";
        public string Username = "";
        public string playerId = "";
        public string Email = "" ;
        public DateTime accountCreated;
        public bool isBanned;
        private IComparer<InventoryKey> inventoryKeyComparer = new MyInventoryKeyOrderingClass();
        public Dictionary<int, short> inventory;
        public Dictionary<int, short> inventorySeenItems;
        public Gender gender;
        public DateTime vipEndTime = DateTime.MinValue;

        public CameraZoomLevel CameraZoomLevel;
        public AdminStatus AdminStatus;



        public int gems;
        public int bc;
        public int inventorySlots;

        public bool playerDataSetup = false;

        public BlockType[] hotSpotsBlockTypes = new BlockType[]
        {
        BlockType.None,
        BlockType.BasicFace,
        BlockType.BasicEyebrows,
        BlockType.BasicEyeballs,
        BlockType.None,
        BlockType.BasicMouth,
        BlockType.BasicTorso,
        BlockType.BasicTopArm,
        BlockType.BasicBottomArm,
        BlockType.BasicLegs,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.Underwear,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.None,
        BlockType.BasicEyelashes,
        BlockType.Underwear,
        BlockType.None,
        BlockType.None
        };

        public static BlockType[] defaultMaleHotSpotsBlockTypes = { BlockType.None, BlockType.BasicFace, BlockType.BasicEyebrows, BlockType.BasicEyeballs, BlockType.None, BlockType.BasicMouth, BlockType.BasicTorso, BlockType.BasicTopArm, BlockType.BasicBottomArm, BlockType.BasicLegs, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.Underwear, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.BasicEyelashes, BlockType.Underwear, BlockType.None, BlockType.None, BlockType.None };
        public static BlockType[] defaultFemaleHotSpotsBlockTypes = { BlockType.None, BlockType.BasicFace, BlockType.BasicEyebrows, BlockType.BasicEyeballs, BlockType.None, BlockType.BasicMouth, BlockType.BasicTorso, BlockType.BasicTopArm, BlockType.BasicBottomArm, BlockType.BasicLegs, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.Underwear, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.None, BlockType.BasicEyelashes, BlockType.Underwear, BlockType.None, BlockType.None, BlockType.None };

        public void InitFromBson(BSONObject currentMessage, Bot bot)
        {
            this.bot = bot;
            BSONObject playerData = SimpleBSON.Load(currentMessage["pD"].binaryValue);
            playerId = currentMessage["U"].stringValue;
            Username = currentMessage["UN"].stringValue;
            RealUsername = currentMessage["rUN"].stringValue;
            bot.Username = RealUsername;
            bot.UpdatePrefix();
            Email = currentMessage["Email"].stringValue;
            

            gender = (Gender)playerData["gender"].int32Value;
            inventorySlots = playerData["slots"].int32Value;
            CameraZoomLevel = (CameraZoomLevel)playerData["cameraZoomLevel"].int32Value;
            gems = playerData["gems"].int32Value;
            this.AdminStatus = (AdminStatus)playerData["playerAdminStatusKey"].int32Value;
            bc = playerData["bcs"].int32Value;

            SetHotSpotsViaIntList(playerData["spots"].int32ListValue);

            accountCreated = new DateTime(playerData["accountAge"].int64Value);

            this.InitInventoryFromBinary(playerData["inv"].binaryValue);
            if (playerData.ContainsKey("InventorySeenKey"))
            {
                this.InitInventorySeenFromBinary(playerData["InventorySeenKey"].binaryValue);
            }
            else
            {
                this.InitInventorySeenItemsFromBinary(playerData["inv"].binaryValue);
            }






            playerDataSetup = true;
        }

        public BlockType GetPlayerHotSpot(int hotSpotIndex)
        {
            return this.hotSpotsBlockTypes[hotSpotIndex];
        }

        public bool IsInventoryFull()
        {
            return inventory.Count > inventorySlots;
        }

        public UseResult UseGemsIfPossible(int useAmount)
        {
            if (useAmount < 0)
            {
                return UseResult.InvalidAmount;
            }
            if (useAmount > this.gems)
            {
                return UseResult.NotEnough;
            }
            this.gems -= useAmount;
            return UseResult.Success;
        }

        public bool IsThereSpaceForItem(InventoryKey item)
        {
            var inv = GetInventoryAsOrderedByInventoryItemType();
            foreach (var cur in inv)
            {
                if (cur == item)
                {
                    return (GetCount(cur) < ConfigData.maxItemsPerSlot) || IsInventoryFull();
                }
            }
            return IsInventoryFull();
        }

        private void InitInventoryFromBinary(byte[] binary)
        {
            int num = 6;
            inventory = new Dictionary<int, short>();
            if (binary != null && binary.Length >= num)
            {
                for (int i = 0; i < binary.Length; i += num)
                {
                    inventory[BitConverter.ToInt32(binary, i)] = BitConverter.ToInt16(binary, i + 4);
                }
            }
        }

        private void InitInventorySeenFromBinary(byte[] binary)
        {
            int num = 6;
            this.inventorySeenItems = new Dictionary<int, short>();
            if (binary == null || binary.Length < num)
            {
                return;
            }
            for (int i = 0; i < binary.Length; i += num)
            {
                this.inventorySeenItems[BitConverter.ToInt32(binary, i)] = BitConverter.ToInt16(binary, i + 4);
            }
        }

        public static BlockType GetAnimationHotSpotDefaultBlockType(AnimationHotSpots hotSpot, Gender gender)
        {
            if (gender == Gender.Male)
            {
                return PlayerData.defaultMaleHotSpotsBlockTypes[(int)hotSpot];
            }
            return PlayerData.defaultFemaleHotSpotsBlockTypes[(int)hotSpot];
        }

        public void SetHotSpotsViaIntList(List<int> intList)
        {
            for (int i = 0; i < this.hotSpotsBlockTypes.Length; i++)
            {
                this.hotSpotsBlockTypes[i] = (BlockType)intList[i];
            }
        }

        public Dictionary<InventoryKey, short> GetCounts()
        {
            Dictionary<InventoryKey, short> dictionary = new Dictionary<InventoryKey, short>();
            foreach (KeyValuePair<int, short> keyValuePair in this.inventory)
            {
                dictionary[InventoryKey.IntToInventoryKey(keyValuePair.Key)] = keyValuePair.Value;
            }
            return dictionary;
        }

        public InventoryKey[] GetInventoryAsOrderedByInventoryItemType()
        {
            List<InventoryKey> list = new List<InventoryKey>();
            foreach (KeyValuePair<int, short> keyValuePair in this.inventory)
            {
                InventoryKey item = InventoryKey.IntToInventoryKey(keyValuePair.Key);
                list.Add(item);
            }
            list.Sort(this.inventoryKeyComparer);
            return list.ToArray();
        }

        public short GetCount(InventoryKey inventoryKey)
        {
            int key = InventoryKey.InventoryKeyToInt(inventoryKey);
            if (this.inventory.ContainsKey(key))
            {
                return this.inventory[key];
            }
            return 0;
        }

        private void InitInventorySeenItemsFromBinary(byte[] binary)
        {
            int num = 6;
            this.inventorySeenItems = new Dictionary<int, short>();
            if (binary == null || binary.Length < num)
            {
                return;
            }
            for (int i = 0; i < binary.Length; i += num)
            {
                this.inventorySeenItems[BitConverter.ToInt32(binary, i)] = 1;
            }
        }

        public void RemoveItemsFromInventory(InventoryKey inventoryKey, short amount)
        {
            this.ActualItemRemove(inventoryKey.blockType, inventoryKey.itemType, amount);
        }

        public void SetPlayerHotSpot(int hotSpotIndex, BlockType blockType)
        {
            this.hotSpotsBlockTypes[hotSpotIndex] = blockType;
        }

        public bool IsItemAvailable(InventoryKey inventoryKey)
        {
            return this.IsItemAvailable(inventoryKey.blockType, inventoryKey.itemType);
        }

        public bool IsItemAvailable(BlockType blockType, InventoryItemType inventoryItemType)
        {
            return this.inventory.ContainsKey(InventoryKey.BlockTypeAndInventoryItemTypeToInt(blockType, inventoryItemType));
        }

        public bool CanDropCollectable(CollectableData cd)
        {
            InventoryKey inventoryKey = new InventoryKey(cd.blockType, cd.InventoryType);
            return 0 < cd.Amount && cd.Amount <= this.GetCount(inventoryKey);
        }

        public bool CanTransfer(InventoryKey inventoryKey, short amount)
        {
            return 0 < amount && amount <= this.GetCount(inventoryKey);
        }

        public void AddGems(int addAmount)
        {
            this.gems += addAmount;
        }

        public void AddBytes(int byteAmount)
        {
            this.bc += byteAmount;
        }

        public void RemoveItemFromInventory(BlockType blockType, InventoryItemType inventoryItemType)
        {
            this.ActualItemRemove(blockType, inventoryItemType, 1);
        }

        public void AddFromCollectable(CollectableData collectableData)
        {
            if (collectableData.IsGem)
            {
                this.AddGems((int)collectableData.Amount * ConfigData.GetGemValue(collectableData.GemType));
                //this.AddStatistics(PlayerData.StatisticsKey.Gems_Collected, (int)collectableData.amount * ConfigData.GetGemValue(collectableData.gemType));
            }
            else
            {
                this.AddItemToInventory(collectableData.blockType, collectableData.InventoryType, collectableData.Amount);
            }
        }

        public short HowMuchCanPlayerPick(InventoryKey ik)
        {
            short result = 0;
            if (!ConfigData.CanPlayerHaveInInventory(ik.blockType))
            {
                return result;
            }
            if (ik.blockType == BlockType.None)
            {
                return result;
            }
            if (this.IsItemAvailable(ik))
            {
                short count = this.GetCount(ik);
                if (count >= ConfigData.maxItemsPerSlot)
                {
                    result = 0;
                }
                else
                {
                    result = (short)(ConfigData.maxItemsPerSlot - count);
                }
            }
            else if (this.inventory.Count < (int)this.inventorySlots)
            {
                result = ConfigData.maxItemsPerSlot;
            }
            else
            {
                result = 0;
            }
            return result;
        }

        public void AddItemToInventory(BlockType blockType, InventoryItemType inventoryItemType, short addAmount)
        {
            if (addAmount < 1)
            {
                return;
            }
            int num = InventoryKey.BlockTypeAndInventoryItemTypeToInt(blockType, inventoryItemType);
            if (this.inventory.ContainsKey(num))
            {
                Dictionary<int, short> dictionary;
                int key;
                (dictionary = this.inventory)[key = num] = (short)(dictionary[key] + addAmount);
                //this.CallInventoryItemAmountChanged(new InventoryKey(blockType, inventoryItemType), this.inventory[num], (int)addAmount);
            }
            else
            {
                this.CheckifNewItemInInventory(blockType, inventoryItemType);
                this.inventory[num] = addAmount;
                //this.CallInventoryItemAddedOrRemoved(new InventoryKey(blockType, inventoryItemType));
            }
        }

        public void CheckifNewItemInInventory(BlockType blockType, InventoryItemType itemType)
        {
            int key = InventoryKey.BlockTypeAndInventoryItemTypeToInt(blockType, itemType);
            if (this.inventorySeenItems != null && !this.inventorySeenItems.ContainsKey(key))
            {
                this.inventorySeenItems.Add(key, 0);
            }
            else if (this.inventorySeenItems == null)
            {
                this.inventorySeenItems = new Dictionary<int, short>();
                this.inventorySeenItems.Add(key, 0);
            }
        }

        public Dictionary<int, short> SeenItemsList()
        {
            return this.inventorySeenItems;
        }

        private void ActualItemRemove(BlockType blockType, InventoryItemType inventoryItemType, short amount)
        {
            if (amount < 1)
            {
                return;
            }
            int key = InventoryKey.BlockTypeAndInventoryItemTypeToInt(blockType, inventoryItemType);
            if (this.inventory.ContainsKey(key))
            {
                short num = (short)(this.inventory[key] - amount);
                if (num > 0)
                {
                    this.inventory[key] = num;
                }
                else
                {
                    this.inventory.Remove(key);
                }
            }
        }

        public bool IsPlayerCurrentlyVIP()
        {
            return (((DateTime.UtcNow.Ticks - 621355968000000000) / 10000) * 10000) + 621355968000000000 <= this.vipEndTime.Ticks;
        }

        // REMOVE COMMENTS!
        public PickUpResult CanPlayerPick(CollectableData cd, bool isAdminPick = false)
        {
            /*if (!isAdminPick && !ConfigData.CanPlayerPickCollectableFromMapPoint(this.bot.WorldController.world, PositionConversions.ConvertCollectablePosToMapPoint(cd.PosX, cd.PosY), this.IsPlayerCurrentlyVIP(), this))
            {
                return PickUpResult.NotAllowed;
            }
            if (cd.IsGem)
            {
                return PickUpResult.All;
            }*/
            return this.CanPlayerPick(new InventoryKey(cd.blockType, cd.InventoryType), cd.Amount, isAdminPick);
        }

        public PickUpResult CanPlayerPick(InventoryKey ik, short pickAmount, bool isAdminPick = false)
        {
            if (!isAdminPick && !ConfigData.CanPlayerHaveInInventory(ik.blockType))
            {
                return PickUpResult.NotAllowed;
            }
            if (pickAmount < 1 || ik.blockType == BlockType.None)
            {
                return PickUpResult.NoSpace;
            }
            if (this.IsItemAvailable(ik))
            {
                int count = (int)this.GetCount(ik);
                if (count >= (int)ConfigData.maxItemsPerSlot)
                {
                    return PickUpResult.StackFull;
                }
                if (count + (int)pickAmount <= (int)ConfigData.maxItemsPerSlot)
                {
                    return PickUpResult.All;
                }
                return PickUpResult.Partial;
            }
            else
            {
                if (this.inventory.Count >= (int)this.inventorySlots)
                {
                    return PickUpResult.NoSpace;
                }
                if (pickAmount > ConfigData.maxItemsPerSlot)
                {
                    return PickUpResult.Partial;
                }
                return PickUpResult.All;
            }
        }

        public void RenderInventory()
        {
            if (!bot.IsSelected) return;
            if (RealUsername == "")
            {
                ImGui.Text("Player Data hasnt been loaded yet please wait a few seconds and if that doesnt work restart bot!");
                return;
            }

            InventoryKey[] inventory = GetInventoryAsOrderedByInventoryItemType();
            
            foreach (InventoryKey item in inventory)
            {
                string itemName = item.blockType.ToString() + " | "+ item.itemType.ToString() + $" ({GetCount(item)})";

                if (ImGui.CollapsingHeader(itemName))
                {
                    if (bot.NetworkClient.playerConnectionStatus == PlayerConnectionStatus.InRoom)
                    {
                        ImGui.PushStyleColor(ImGuiCol.Button, 1727698498);
                        if (ImGui.Button("Drop"))
                        {
                            Vector2i nextUNSAFEPlayerPositionBasedOnLookDirection = bot.Player.GetNextUNSAFEPlayerPositionBasedOnLookDirection(0);
                            if (!bot.WorldController.world.IsValidItemDropPoint(nextUNSAFEPlayerPositionBasedOnLookDirection))
                            {
                                return;
                            }
                            bot.Player.DropItems(item, GetCount(item));
                        }
                        ImGui.SameLine();
                        ImGui.Button("Trash");
                        
                        if (item.itemType == InventoryItemType.Weapon || item.itemType == InventoryItemType.WearableItem)
                        {
                            ImGui.SameLine();
                            if (ImGui.Button(bot.Player.IsItemEquiped(item.blockType) ? "unequip" : "equip"))
                            {
                                bot.Player.ChangeWearable(item.blockType);
                            }
                        }
                        
                    }
                    else
                    {
                        ImGui.Text("Player is not current in a world!");
                    }
                    
                }
            }
        }

    }

    public class MyInventoryKeyOrderingClass : IComparer<InventoryKey>
    {
        public int Compare(InventoryKey x, InventoryKey y)
        {
            int num = -x.itemType.CompareTo(y.itemType);
            if (num != 0)
            {
                return num;
            }
            if (x.itemType != InventoryItemType.Block)
            {
                return x.blockType.ToString().CompareTo(y.blockType.ToString());
            }
            int num2 = ConfigData.DoesBlockHaveCollider(x.blockType).CompareTo(ConfigData.DoesBlockHaveCollider(y.blockType));
            if (num2 == 0)
            {
                return x.blockType.ToString().CompareTo(y.blockType.ToString());
            }
            return num2;
        }
    }
}
