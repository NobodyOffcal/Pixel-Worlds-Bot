﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Structs
{
    public struct Acc
    {
        [JsonProperty("CognitoID")]
        public string CognitoID { get; set; }
        [JsonProperty("Token")]
        public string Token { get; set; }
        [JsonProperty("World")]
        public string World { get; set; }

        public Acc(string cd, string tk, string world)
        {
            this.CognitoID = cd;
            this.Token = tk;
            this.World = world;
        }
    }
}
