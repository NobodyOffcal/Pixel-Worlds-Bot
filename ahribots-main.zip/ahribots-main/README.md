# ahribots
Leaked AhriBots Auto Mine for Pixel Worlds Game
# Usage
Install .NET SDK 6.0.403 and build the project on Visual Studio.
# Info
The code isn't updated after Halloween Update (#20728605)
