﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Misc
{
    public class Globals
    {
        public static bool HideGUI = false;

        public static bool Log = false;
        public static bool ItemBsonInTooltips = false;


        public static bool MineLevel5 = false;
        public static bool MineLevel4 = true;
        public static bool MineLevel3 = true;
        public static bool MineLevel2 = true;
        public static bool MineLevel1 = true;

        public static bool WebhookSetup = false;
        public static bool UseWebhook = false;
        public static string webhook = "";
    }

    public class Settings
    {
        [JsonProperty("Log")]
        public bool Log { get; set; }
        [JsonProperty("ItemBsonInTooltips")]
        public bool ItemBsonInTooltips { get; set; }
        [JsonProperty("MineLevel5")]
        public bool MineLevel5 { get; set; }
        [JsonProperty("MineLevel4")]
        public bool MineLevel4 { get; set; }
        [JsonProperty("MineLevel3")]
        public bool MineLevel3 { get; set; }
        [JsonProperty("MineLevel2")]
        public bool MineLevel2 { get; set; }
        [JsonProperty("MineLevel1")]
        public bool MineLevel1 { get; set; }

        [JsonProperty("webhook")]
        public string webhook { get; set; }
        [JsonProperty("UseWebhook")]
        public bool UseWebhook { get; set; }
        [JsonProperty("WebhookSetup")]
        public bool WebhookSetup { get; set; }
        [JsonProperty("path")]
        public string path { get; set; }
    }
}
