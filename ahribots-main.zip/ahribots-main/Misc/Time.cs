﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots
{
    public class Time
    {
        static Stopwatch realtimeSinceStartupTIMER = new Stopwatch();
        public static float deltaTime = 0f;
        public static void SetupTime()
        {

            realtimeSinceStartupTIMER.Start();
        }

        public static float realtimeSinceStartup { get { 
            return (float)realtimeSinceStartupTIMER.Elapsed.TotalSeconds;
            } }
    }
}
