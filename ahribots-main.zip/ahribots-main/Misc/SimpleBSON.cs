﻿using ArhiBots.Structs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ArhiBots.Misc
{
    public class BSONValue
    {
        public enum ValueType
        {
            Double,
            String,
            Array,
            Binary,
            Boolean,
            UTCDateTime,
            None,
            Int32,
            Int64,
            Object
        }

        private ValueType mValueType;

        private double _double;

        private string _string;

        private byte[] _binary;

        private bool _bool;

        private DateTime _dateTime;

        private int _int32;

        private long _int64;

        public ValueType valueType => mValueType;

        public double doubleValue => mValueType switch
        {
            ValueType.Int32 => _int32,
            ValueType.Int64 => _int64,
            ValueType.Double => _double,
            ValueType.None => double.NaN,
            _ => throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to double", mValueType)),
        };

        public int int32Value => mValueType switch
        {
            ValueType.Int32 => _int32,
            ValueType.Int64 => (int)_int64,
            ValueType.Double => (int)_double,
            _ => throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to Int32", mValueType)),
        };

        public long int64Value => mValueType switch
        {
            ValueType.Int32 => _int32,
            ValueType.Int64 => _int64,
            ValueType.Double => (long)_double,
            _ => throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to Int64", mValueType)),
        };

        public byte[] binaryValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.Binary)
                {
                    return _binary;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to binary", mValueType));
            }
        }

        public DateTime dateTimeValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.UTCDateTime)
                {
                    return _dateTime;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to DateTime", mValueType));
            }
        }

        public string stringValue => mValueType switch
        {
            ValueType.Int32 => Convert.ToString(_int32),
            ValueType.Int64 => Convert.ToString(_int64),
            ValueType.Double => Convert.ToString(_double),
            ValueType.String => (_string == null) ? null : _string.TrimEnd(default(char)),
            ValueType.Boolean => (!_bool) ? "false" : "true",
            ValueType.Binary => Encoding.UTF8.GetString(_binary).TrimEnd(default(char)),
            _ => throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to string", mValueType)),
        };

        public bool boolValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.Boolean)
                {
                    return _bool;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to bool", mValueType));
            }
        }

        public List<int> int32ListValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.Array)
                {
                    List<int> list = new List<int>();
                    BSONArray bSONArray = (BSONArray)this;
                    for (int i = 0; i < bSONArray.Count; i++)
                    {
                        list.Add(bSONArray[i].int32Value);
                    }
                    return list;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to int32 array", mValueType));
            }
        }

        public List<long> int64ListValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.Array)
                {
                    List<long> list = new List<long>();
                    BSONArray bSONArray = (BSONArray)this;
                    for (int i = 0; i < bSONArray.Count; i++)
                    {
                        list.Add(bSONArray[i].int64Value);
                    }
                    return list;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to int64 array", mValueType));
            }
        }

        public List<string> stringListValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.Array)
                {
                    List<string> list = new List<string>();
                    BSONArray bSONArray = (BSONArray)this;
                    for (int i = 0; i < bSONArray.Count; i++)
                    {
                        list.Add(bSONArray[i].stringValue);
                    }
                    return list;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to string array", mValueType));
            }
        }

        public List<Vector2i> vector2iListValue
        {
            get
            {
                ValueType valueType = mValueType;
                if (valueType == ValueType.Binary)
                {
                    List<Vector2i> list = new List<Vector2i>();
                    byte[] array = new byte[8];
                    for (int i = 0; i < _binary.Length; i += 8)
                    {
                        Buffer.BlockCopy(_binary, i, array, 0, 8);
                        list.Add(new Vector2i(array));
                    }
                    return list;
                }
                throw new Exception(string.Format("Original type is {0}. Cannot convert from {0} to Vector2i list", mValueType));
            }
        }

        public bool isNone => mValueType == ValueType.None;

        public virtual BSONValue this[string key]
        {
            get
            {
                return null;
            }
            set
            {
            }
        }

        public virtual BSONValue this[int index]
        {
            get
            {
                return null;
            }
            set
            {
            }
        }

        protected BSONValue(ValueType valueType)
        {
            mValueType = valueType;
        }

        public BSONValue()
        {
            mValueType = ValueType.None;
        }

        public BSONValue(double v)
        {
            mValueType = ValueType.Double;
            _double = v;
        }

        public BSONValue(string v)
        {
            mValueType = ValueType.String;
            _string = v;
        }

        public BSONValue(byte[] v)
        {
            mValueType = ValueType.Binary;
            _binary = v;
        }

        public BSONValue(bool v)
        {
            mValueType = ValueType.Boolean;
            _bool = v;
        }

        public BSONValue(DateTime dt)
        {
            mValueType = ValueType.UTCDateTime;
            _dateTime = dt;
        }

        public BSONValue(int v)
        {
            mValueType = ValueType.Int32;
            _int32 = v;
        }

        public BSONValue(long v)
        {
            mValueType = ValueType.Int64;
            _int64 = v;
        }

        public virtual void Clear()
        {
        }

        public virtual void Add(string key, BSONValue value)
        {
        }

        public virtual void Add(BSONValue value)
        {
        }

        public virtual bool ContainsValue(BSONValue v)
        {
            return false;
        }

        public virtual bool ContainsKey(string key)
        {
            return false;
        }

        public static implicit operator BSONValue(double v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(int v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(long v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(byte[] v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(DateTime v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(string v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(bool v)
        {
            return new BSONValue(v);
        }

        public static implicit operator BSONValue(List<int> v)
        {
            BSONArray bSONArray = new BSONArray();
            for (int i = 0; i < v.Count; i++)
            {
                bSONArray.Add(new BSONValue(v[i]));
            }
            return bSONArray;
        }

        public static implicit operator BSONValue(List<long> v)
        {
            BSONArray bSONArray = new BSONArray();
            for (int i = 0; i < v.Count; i++)
            {
                bSONArray.Add(new BSONValue(v[i]));
            }
            return bSONArray;
        }

        public static implicit operator BSONValue(List<string> v)
        {
            BSONArray bSONArray = new BSONArray();
            for (int i = 0; i < v.Count; i++)
            {
                bSONArray.Add(new BSONValue(v[i]));
            }
            return bSONArray;
        }

        public static implicit operator BSONValue(List<Vector2i> v)
        {
            byte[] array = new byte[v.Count * 8];
            for (int i = 0; i < v.Count; i++)
            {
                Buffer.BlockCopy(v[i].GetAsBinaryArray(), 0, array, i * 8, 8);
            }
            return new BSONValue(array);
        }

        public static implicit operator double(BSONValue v)
        {
            return v.doubleValue;
        }

        public static implicit operator int(BSONValue v)
        {
            return v.int32Value;
        }

        public static implicit operator long(BSONValue v)
        {
            return v.int64Value;
        }

        public static implicit operator byte[](BSONValue v)
        {
            return v.binaryValue;
        }

        public static implicit operator DateTime(BSONValue v)
        {
            return v.dateTimeValue;
        }

        public static implicit operator string(BSONValue v)
        {
            return v.stringValue;
        }

        public static implicit operator bool(BSONValue v)
        {
            return v.boolValue;
        }

        public static implicit operator List<int>(BSONValue v)
        {
            return v.int32ListValue;
        }

        public static implicit operator List<long>(BSONValue v)
        {
            return v.int64ListValue;
        }

        public static implicit operator List<string>(BSONValue v)
        {
            return v.stringListValue;
        }

        public static implicit operator List<Vector2i>(BSONValue v)
        {
            return v.vector2iListValue;
        }

        public static bool operator ==(BSONValue a, object b)
        {
            return object.ReferenceEquals(a, b);
        }

        public static bool operator !=(BSONValue a, object b)
        {
            return !(a == b);
        }
    }



    public class BSONObject : BSONValue, IEnumerable
    {
        private Dictionary<string, BSONValue> mMap = new Dictionary<string, BSONValue>();

        public ICollection<string> Keys => mMap.Keys;

        public ICollection<BSONValue> Values => mMap.Values;

        public int Count => mMap.Count;

        public override BSONValue this[string key]
        {
            get
            {
                return mMap[key];
            }
            set
            {
                mMap[key] = value;
            }
        }

        public BSONObject()
            : base(ValueType.Object)
        {
        }

        public override void Clear()
        {
            mMap.Clear();
        }

        public override void Add(string key, BSONValue value)
        {
            mMap.Add(key, value);
        }

        public override bool ContainsValue(BSONValue v)
        {
            return mMap.ContainsValue(v);
        }

        public override bool ContainsKey(string key)
        {
            return mMap.ContainsKey(key);
        }

        public bool Remove(string key)
        {
            return mMap.Remove(key);
        }

        public bool TryGetValue(string key, out BSONValue value)
        {
            return mMap.TryGetValue(key, out value);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return mMap.GetEnumerator();
        }
    }


    public class BSONArray : BSONValue, IEnumerable
    {
        private List<BSONValue> mList = new List<BSONValue>();

        public override BSONValue this[int index]
        {
            get
            {
                return mList[index];
            }
            set
            {
                mList[index] = value;
            }
        }

        public int Count => mList.Count;

        public BSONArray()
            : base(ValueType.Array)
        {
        }

        public override void Add(BSONValue v)
        {
            mList.Add(v);
        }

        public int IndexOf(BSONValue item)
        {
            return mList.IndexOf(item);
        }

        public void Insert(int index, BSONValue item)
        {
            mList.Insert(index, item);
        }

        public bool Remove(BSONValue v)
        {
            return mList.Remove(v);
        }

        public void RemoveAt(int index)
        {
            mList.RemoveAt(index);
        }

        public override void Clear()
        {
            mList.Clear();
        }

        public new virtual bool ContainsValue(BSONValue v)
        {
            return mList.Contains(v);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return mList.GetEnumerator();
        }
    }

    public class SimpleBSON
    {
        private MemoryStream mMemoryStream;

        private BinaryReader mBinaryReader;

        private BinaryWriter mBinaryWriter;

        private SimpleBSON(byte[] buf = null)
        {
            if (buf != null)
            {
                mMemoryStream = new MemoryStream(buf);
                mBinaryReader = new BinaryReader(mMemoryStream);
            }
            else
            {
                mMemoryStream = new MemoryStream();
                mBinaryWriter = new BinaryWriter(mMemoryStream);
            }
        }

        public static BSONObject Load(byte[] buf)
        {
            SimpleBSON simpleBSON = new SimpleBSON(buf);
            return simpleBSON.decodeDocument();
        }

        public static byte[] Dump(BSONObject obj)
        {
            SimpleBSON simpleBSON = new SimpleBSON();
            MemoryStream memoryStream = new MemoryStream();
            simpleBSON.encodeDocument(memoryStream, obj);
            byte[] array = new byte[memoryStream.Position];
            memoryStream.Seek(0L, SeekOrigin.Begin);
            memoryStream.Read(array, 0, array.Length);
            return array;
        }

        private BSONValue decodeElement(out string name)
        {
            byte b = mBinaryReader.ReadByte();
            switch (b)
            {
                case 1:
                    name = decodeCString();
                    return new BSONValue(mBinaryReader.ReadDouble());
                case 2:
                    name = decodeCString();
                    return new BSONValue(decodeString());
                case 3:
                    name = decodeCString();
                    return decodeDocument();
                case 4:
                    name = decodeCString();
                    return decodeArray();
                case 5:
                    {
                        name = decodeCString();
                        int count = mBinaryReader.ReadInt32();
                        byte b2 = mBinaryReader.ReadByte();
                        return new BSONValue(mBinaryReader.ReadBytes(count));
                    }
                case 8:
                    name = decodeCString();
                    return new BSONValue(mBinaryReader.ReadBoolean());
                case 9:
                    {
                        name = decodeCString();
                        long time = mBinaryReader.ReadInt64();
                        try
                        {
                            DateTime d = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc) + new TimeSpan(time * 10000);
                        }
                        catch
                        {
                            return new BSONValue(DateTime.UtcNow);
                        }
                        
                        return new BSONValue(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc) + new TimeSpan(time * 10000));
                    }
                case 10:
                    name = decodeCString();
                    return new BSONValue();
                case 16:
                    name = decodeCString();
                    return new BSONValue(mBinaryReader.ReadInt32());
                case 18:
                    name = decodeCString();
                    return new BSONValue(mBinaryReader.ReadInt64());
                default:
                    throw new Exception($"Don't know elementType={b}");
            }
        }

        private BSONObject decodeDocument()
        {
            int num = mBinaryReader.ReadInt32() - 4;
            BSONObject bSONObject = new BSONObject();
            int num2 = (int)mBinaryReader.BaseStream.Position;
            while (mBinaryReader.BaseStream.Position < num2 + num - 1)
            {
                string name;
                BSONValue value = decodeElement(out name);
                bSONObject.Add(name, value);
            }
            mBinaryReader.ReadByte();
            return bSONObject;
        }

        private BSONArray decodeArray()
        {
            BSONObject bSONObject = decodeDocument();
            int i = 0;
            BSONArray bSONArray = new BSONArray();
            for (; bSONObject.ContainsKey(Convert.ToString(i)); i++)
            {
                bSONArray.Add(bSONObject[Convert.ToString(i)]);
            }
            return bSONArray;
        }

        private string decodeString()
        {
            int count = mBinaryReader.ReadInt32();
            byte[] bytes = mBinaryReader.ReadBytes(count);
            return Encoding.UTF8.GetString(bytes);
        }

        private string decodeCString()
        {
            MemoryStream memoryStream = new MemoryStream();
            while (true)
            {
                byte b = mBinaryReader.ReadByte();
                if (b == 0)
                {
                    break;
                }
                memoryStream.WriteByte(b);
            }
            return Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, (int)memoryStream.Position);
        }

        private void encodeElement(MemoryStream ms, string name, BSONValue v)
        {
            switch (v.valueType)
            {
                case BSONValue.ValueType.Double:
                    ms.WriteByte(1);
                    encodeCString(ms, name);
                    encodeDouble(ms, v.doubleValue);
                    break;
                case BSONValue.ValueType.String:
                    ms.WriteByte(2);
                    encodeCString(ms, name);
                    encodeString(ms, v.stringValue);
                    break;
                case BSONValue.ValueType.Object:
                    ms.WriteByte(3);
                    encodeCString(ms, name);
                    encodeDocument(ms, v as BSONObject);
                    break;
                case BSONValue.ValueType.Array:
                    ms.WriteByte(4);
                    encodeCString(ms, name);
                    encodeArray(ms, v as BSONArray);
                    break;
                case BSONValue.ValueType.Binary:
                    ms.WriteByte(5);
                    encodeCString(ms, name);
                    encodeBinary(ms, v.binaryValue);
                    break;
                case BSONValue.ValueType.Boolean:
                    ms.WriteByte(8);
                    encodeCString(ms, name);
                    encodeBool(ms, v.boolValue);
                    break;
                case BSONValue.ValueType.UTCDateTime:
                    ms.WriteByte(9);
                    encodeCString(ms, name);
                    encodeUTCDateTime(ms, v.dateTimeValue);
                    break;
                case BSONValue.ValueType.None:
                    ms.WriteByte(10);
                    encodeCString(ms, name);
                    break;
                case BSONValue.ValueType.Int32:
                    ms.WriteByte(16);
                    encodeCString(ms, name);
                    encodeInt32(ms, v.int32Value);
                    break;
                case BSONValue.ValueType.Int64:
                    ms.WriteByte(18);
                    encodeCString(ms, name);
                    encodeInt64(ms, v.int64Value);
                    break;
            }
        }

        private void encodeDocument(MemoryStream ms, BSONObject obj)
        {
            MemoryStream memoryStream = new MemoryStream();
            foreach (string key in obj.Keys)
            {
                encodeElement(memoryStream, key, obj[key]);
            }
            BinaryWriter binaryWriter = new BinaryWriter(ms);
            binaryWriter.Write((int)(memoryStream.Position + 4 + 1));
            binaryWriter.Write(memoryStream.GetBuffer(), 0, (int)memoryStream.Position);
            binaryWriter.Write((byte)0);
        }

        private void encodeArray(MemoryStream ms, BSONArray lst)
        {
            BSONObject bSONObject = new BSONObject();
            for (int i = 0; i < lst.Count; i++)
            {
                bSONObject.Add(Convert.ToString(i), lst[i]);
            }
            encodeDocument(ms, bSONObject);
        }

        private void encodeBinary(MemoryStream ms, byte[] buf)
        {
            byte[] bytes = BitConverter.GetBytes(buf.Length);
            ms.Write(bytes, 0, bytes.Length);
            ms.WriteByte(0);
            ms.Write(buf, 0, buf.Length);
        }

        private void encodeCString(MemoryStream ms, string v)
        {
            byte[] bytes = new UTF8Encoding().GetBytes(v);
            ms.Write(bytes, 0, bytes.Length);
            ms.WriteByte(0);
        }

        private void encodeString(MemoryStream ms, string v)
        {
            byte[] bytes = new UTF8Encoding().GetBytes(v);
            byte[] bytes2 = BitConverter.GetBytes(bytes.Length + 1);
            ms.Write(bytes2, 0, bytes2.Length);
            ms.Write(bytes, 0, bytes.Length);
            ms.WriteByte(0);
        }

        private void encodeDouble(MemoryStream ms, double v)
        {
            byte[] bytes = BitConverter.GetBytes(v);
            ms.Write(bytes, 0, bytes.Length);
        }

        private void encodeBool(MemoryStream ms, bool v)
        {
            byte[] bytes = BitConverter.GetBytes(v);
            ms.Write(bytes, 0, bytes.Length);
        }

        private void encodeInt32(MemoryStream ms, int v)
        {
            byte[] bytes = BitConverter.GetBytes(v);
            ms.Write(bytes, 0, bytes.Length);
        }

        private void encodeInt64(MemoryStream ms, long v)
        {
            byte[] bytes = BitConverter.GetBytes(v);
            ms.Write(bytes, 0, bytes.Length);
        }

        private void encodeUTCDateTime(MemoryStream ms, DateTime dt)
        {
            byte[] bytes = BitConverter.GetBytes((long)(((dt.Kind != DateTimeKind.Local) ? (dt - new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc)) : (dt - new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).ToLocalTime())).TotalSeconds * 1000.0));
            ms.Write(bytes, 0, bytes.Length);
        }
    }
}

