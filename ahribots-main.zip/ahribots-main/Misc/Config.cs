﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Misc
{
    using System.IO;
    using ArhiBots.GUI;
    using Discord;
    using Newtonsoft.Json;

    public static class Config
    {
        private const string ConfigFileName = "settings.json";

        public static void LoadSettings()
        {
            if (File.Exists(ConfigFileName))
            {
                try
                {
                    var json = File.ReadAllText(ConfigFileName);
                    var settings = JsonConvert.DeserializeObject<Settings>(json);

                    Globals.Log = settings.Log;
                    Globals.ItemBsonInTooltips = settings.ItemBsonInTooltips;
                    Globals.MineLevel5 = settings.MineLevel5;
                    Globals.MineLevel4 = settings.MineLevel4;
                    Globals.MineLevel3 = settings.MineLevel3;
                    Globals.MineLevel2 = settings.MineLevel2;
                    Globals.MineLevel1 = settings.MineLevel1;
                    Globals.UseWebhook = settings.UseWebhook;
                    Globals.webhook = settings.webhook == null ? "" : settings.webhook;
                    Globals.WebhookSetup = settings.WebhookSetup;
                    SampleOverlay.path = settings.path == null ? "accounts.json" : settings.path;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to load settings: {ex.Message}");
                }
            }
        }

        public static void SaveSettings()
        {
            try
            {
                var settings = new Settings
                {
                    Log = Globals.Log,
                    ItemBsonInTooltips = Globals.ItemBsonInTooltips,
                    MineLevel5 = Globals.MineLevel5,
                    MineLevel4 = Globals.MineLevel4,
                    MineLevel3 = Globals.MineLevel3,
                    MineLevel2 = Globals.MineLevel2,
                    MineLevel1 = Globals.MineLevel1,
                    webhook = Globals.webhook,
                    UseWebhook = Globals.UseWebhook,
                    WebhookSetup = Globals.WebhookSetup,
                    path = SampleOverlay.path,
                };

                var json = JsonConvert.SerializeObject(settings);
                File.WriteAllText(ConfigFileName, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to save settings: {ex.Message}");
            }
        }
    }

}
