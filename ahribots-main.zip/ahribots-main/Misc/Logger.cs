﻿namespace ArhiBots.Misc
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;


    public class Logger
    {
        public static string[] BlockClientToLog = { "mP", "p", "mp", "AI" };
        public static string[] BlockServerToLog = { "mP", "p", "AI" };
        public static void Log(object message, bool withTime = true)
        {
            if (!Globals.Log) return;
            SetConsoleColor(LogType.Message);
            if (withTime)
                Console.WriteLine($"[{DateTime.Now.ToString("HH':'mm':'ss")}] {message}");
            else
                Console.WriteLine(message);
            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void Log(LogType logtype, object message)
        {
            if (!Globals.Log) return;
            SetConsoleColor(logtype);
            Console.WriteLine($"[{DateTime.Now.ToString("HH':'mm':'ss")}] {message}");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void SetConsoleColor(LogType logtype)
        {
            switch (logtype)
            {
                case LogType.Message:
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case LogType.Info:
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case LogType.Error:
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case LogType.Debug:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
            }
        }

        public static void ReadBSON(BSONObject SinglePacket, string Parent = "")
        {

            foreach (string Key in SinglePacket.Keys)
            {
                try
                {
                    BSONValue Packet = SinglePacket[Key];
                    switch (Packet.valueType)
                    {
                        case BSONValue.ValueType.String:
                            Log($"{Parent} = {Key} | {Packet.valueType} = {Packet.stringValue}");
                            break;
                        case BSONValue.ValueType.Boolean:
                            Log($"{Parent} = {Key} | {Packet.valueType} = {Packet.boolValue}");
                            break;
                        case BSONValue.ValueType.Int32:
                            Log($"{Parent} = {Key} | {Packet.valueType} = {Packet.int32Value}");
                            break;
                        case BSONValue.ValueType.Int64:
                            Log($"{Parent} = {Key} | {Packet.valueType} = {Packet.int64Value}");
                            break;
                        case BSONValue.ValueType.Binary: // BSONObject
                            Log($"{Parent} = {Key} | {Packet.valueType}");
                            ReadBSON(SimpleBSON.Load(Packet.binaryValue), Key);
                            break;
                        case BSONValue.ValueType.Double:
                            Log($"{Parent} = {Key} | {Packet.valueType} = {Packet.doubleValue}");
                            break;
                        case BSONValue.ValueType.UTCDateTime:
                            Log($"{Parent} = {Key} | {Packet.valueType} = {Packet.dateTimeValue}");
                            break;
                        case BSONValue.ValueType.Object:
                            Log($"{Parent} = {Key} | {Packet.valueType}");
                            ReadBSON(SinglePacket[Key] as BSONObject, Key);
                            break;
                        case BSONValue.ValueType.Array:
                            string value = "";
                            foreach (var item in Packet.stringListValue) value += $" {item}; ";
                            Log($"{Parent} = {Key} = {value}");
                            break;
                        default:
                            Log($"{Parent} = {Key} = {Packet.valueType}");
                            break;
                    }
                }
                catch
                {
                }
            }
        }

        public static string GetBsonAsString(BSONObject SinglePacket, string Parent = "")
        {
            string text = "";
            foreach (string Key in SinglePacket.Keys)
            {
                try
                {
                    BSONValue Packet = SinglePacket[Key];
                    switch (Packet.valueType)
                    {
                        case BSONValue.ValueType.String:
                            text += $"{Parent} = {Key} | {Packet.valueType} = {Packet.stringValue}";
                            break;
                        case BSONValue.ValueType.Boolean:
                            text += $"{Parent} = {Key} | {Packet.valueType} = {Packet.boolValue}";
                            break;
                        case BSONValue.ValueType.Int32:
                            text += $"{Parent} = {Key} | {Packet.valueType} = {Packet.int32Value}";
                            break;
                        case BSONValue.ValueType.Int64:
                            text += $"{Parent} = {Key} | {Packet.valueType} = {Packet.int64Value}";
                            break;
                        case BSONValue.ValueType.Binary: // BSONObject
                            text += $"{Parent} = {Key} | {Packet.valueType}";
                            GetBsonAsString(SimpleBSON.Load(Packet.binaryValue), Key);
                            break;
                        case BSONValue.ValueType.Double:
                            text += $"{Parent} = {Key} | {Packet.valueType} = {Packet.doubleValue}";
                            break;
                        case BSONValue.ValueType.UTCDateTime:
                            text += $"{Parent} = {Key} | {Packet.valueType} = {Packet.dateTimeValue}";
                            break;
                        case BSONValue.ValueType.Array:
                            string value = "";
                            foreach (var item in Packet.stringListValue) value += $" {item}; ";
                            text += $"{Parent} = {Key} = {value}";
                            break;
                        default:
                            text += $"{Parent} = {Key} = {Packet.valueType}";
                            break;
                    }
                    text += "\n";
                }
                catch
                {
                }

            }
            return text;
        }

        public enum LogType
        {
            Message,
            Error,
            Debug,
            Info
        }
    }
}
