﻿using ArhiBots.Misc;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.GUI.Command_Handler
{
    [AttributeUsage(AttributeTargets.Method)]
    public class Command : Attribute
    {


        public string name { get; private set; }
        public string description { get; private set; }

        public Command(string name, string description)
        {
            this.name = name.ToLower();
            this.description = description;
        }


    }

    public class CommandHandler
    {
        public static CommandHandler Instance;
        private bool started = false;
        public bool exited = false;
        private Dictionary<string, Action<string[]>> commands;

        public void SetupCommands()
        {
            if(started) { return; }

            Instance = this;
            commands = new Dictionary<string, Action<string[]>>();

            var types = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .ToList();

            foreach (var type in types)
            {
                foreach (MethodInfo method in type.GetMethods())
                {
                    Command? commandAttr = (Command?)Attribute.GetCustomAttribute(method, typeof(Command));
                    if (commandAttr != null)
                    {
                        commands[commandAttr.name] = (Action<string[]>)Delegate.CreateDelegate(typeof(Action<string[]>), Activator.CreateInstance(type), method);
                    }
                }
            }

            started = true;
        }


        public void StartConsoleMode()
        {
            Task.Run(() =>
            {
                while (!exited)
                {
                    Console.Write("Enter a command: ");
                    Handle(Console.ReadLine());
                }
            });
        }

        public void Handle(string? ctx)
        {

            if (string.IsNullOrEmpty(ctx)) return;

            string[] args = ctx.Split(' ');

            string cmd = args[0];
            cmd = cmd.ToLower();
            if (commands.ContainsKey(cmd))
            {
                commands[cmd](args);
            }
            else
            {
                Console.WriteLine($"Command '{cmd}' not found.");
            }
        }

        [Command("help", "lists all the commands")]
        public void help(string[] args)
        {
            Console.WriteLine("\nAvailable commands:");

            foreach (var kvp in Instance.commands)
            {
                var commandAttr = kvp.Value.Method.GetCustomAttributes(typeof(Command), false)
                    .FirstOrDefault() as Command;
                if (commandAttr != null)
                {
                    Console.WriteLine($"- {commandAttr.name}: {commandAttr.description}");
                }
            }

            Console.WriteLine();
        }


        [Command("db", "Starts a discord bot")]
        public void DiscordBot(string[] args)
        {
            BotManager.discordBot.Start();
        }

        [Command("exit", "stops the command handler (pretty useless for now)")]
        public void Exit(string[] args)
        {
            exited = true;
        }

        [Command("clr", "clear the console")]
        public void Clear(string[] args)
        {
            Console.Clear();
        }

        [Command("gui", "shows the gui")]
        public void Gui(string[] args)
        {
            if (System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                Program.StartGui();
            }
            else
            {
                WriteError("Your current os does not support the gui :(");
            }
        }
        [Command("log", "turns logger on/off (dont recommend turning it on if ur using console)")]
        public void Logger(string[] args)
        {
            Globals.Log = !Globals.Log;
            Console.WriteLine("Logger: " + Globals.Log);
            Config.SaveSettings();
        }

        public static void WriteError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void WriteInfo(object message)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(message);
            Console.ForegroundColor = ConsoleColor.White;
        }

        
    }
}
