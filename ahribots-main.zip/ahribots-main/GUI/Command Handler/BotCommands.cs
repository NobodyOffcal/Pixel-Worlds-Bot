﻿using Amazon.Runtime;
using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Discord_bot;
using ArhiBots.Misc;
using DSharpPlus.VoiceNext.EventArgs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace ArhiBots.GUI.Command_Handler
{
    sealed class BotCommands
    {
        [Command("import", "import bots from a file location")]
        public void Import(string[] args)
        {
            if (args.Length < 2)
            {
                return;
            }

            string path = args[1];

            if (!File.Exists(path))
            {
                CommandHandler.WriteError($"\"{path}\" is an invalid file path...");
                return;
            }

            GUI.SampleOverlay.path = path;
            Task.Run(() => SampleOverlay.LogInAll());

            CommandHandler.WriteInfo("Importing accounts... use \"ls\" to see all the bots");
        }


        [Command("ls", "lists the bots you've imported")]
        public void list(string[] args)
        {
            if (BotManager.bots.Count == 0)
            {
                CommandHandler.WriteError("No bots are currently imported.");
                return;
            }

            Console.WriteLine("\nBots imported:");
            foreach (var bot in BotManager.bots)
            {
                Console.WriteLine(" - " + bot.Prefix + (bot.status == PlayerConnectionStatus.InRoom ? " ("+bot.world.WorldName+")" : ""));
            }
            Console.WriteLine();
        }

        [Command("automine", "Starts bots automine")]
        public void AutoMine(string[] args)
        {
            if (args.Length != 2)
            {
                CommandHandler.WriteError("Please use the prefix of the bot all do -all to start all the bots.");
                return;
            }

            string type = args[1].ToLower();
            if (type == "help")
            {
                CommandHandler.WriteInfo(
                    "-all (starts all bots)\n" +
                    "(int) (Will start the index)\n" +
                    "help (gives some epic help)");

            }
            else if (type == "-all")
            {
                SampleOverlay.AutoMineAll();
                CommandHandler.WriteInfo("All bots are begining to auto mine.");
                return;
            }
            else
            {
                bool parsed = int.TryParse(args[1].ToLower(), out int value);
                

                if (parsed && value >= 0 && value < BotManager.bots.Count) 
                {
                    var bt = BotManager.bots[value];


                    bt.auto.autoMine.Automine = true;

                    if (bt.world == null)
                    {
                        bt.auto.autoMine.joinedMineStart = true;
                        
                    }
                    else if (bt.world.WorldName != "MINEWORLD")
                    {
                        bt.auto.autoMine.joinedMineStart = true;
                    }

                    bt.auto.autoMine.joinedMineStart = false;
                    Task.Run(() => bt.auto.autoMine.AutoMineStart());

                    CommandHandler.WriteInfo($"({bt.Prefix}) has started automining");
                    return;
                }
                else if (parsed)
                {
                    CommandHandler.WriteError("It look's as if you entered an invalid integer");
                    return;
                }
                else
                {
                    string botsName = args[1].ToUpper();

                    foreach(var bt in BotManager.bots)
                    {
                        if (botsName == bt.Player?.myPlayerData?.RealUsername.ToUpper())
                        {

                            bt.auto.autoMine.Automine = true;

                            if (bt.world == null)
                            {
                                bt.auto.autoMine.joinedMineStart = true;

                            }
                            else if (bt.world.WorldName != "MINEWORLD")
                            {
                                bt.auto.autoMine.joinedMineStart = true;
                            }

                            bt.auto.autoMine.joinedMineStart = false;
                            Task.Run(() => bt.auto.autoMine.AutoMineStart());

                            CommandHandler.WriteInfo("Starting automine on the bot named " + botsName);
                            return;
                        }

                    }

                    CommandHandler.WriteError("No bot was started please try again in a few seconds as the bot might still be connecting. Or you spelt something wrong.");
                }


            }


        }

        [Command("stopautomine", "Stops automine on bots")]
        public void StopAutoMine(string[] args)
        {
            if (args.Length != 2)
            {
                CommandHandler.WriteError("Please use the prefix of the bot all do -all to stop all the bots.");
                return;
            }

            string type = args[1].ToLower();
            if (type == "help")
            {
                CommandHandler.WriteInfo(
                    "-all (stops all bots)\n" +
                    "(int) (Will stop the at that index)\n" +
                    "help (gives some epic help)");

            }
            else if (type == "-all")
            {
                SampleOverlay.AutoMineAll();
                CommandHandler.WriteInfo("All bots are stopping auto mining.");
                return;
            }
            else
            {
                bool parsed = int.TryParse(args[1].ToLower(), out int value);


                if (parsed && value >= 0 && value < BotManager.bots.Count)
                {
                    var bt = BotManager.bots[value];

                    bt.auto.autoMine.StopAutoMine();

                    CommandHandler.WriteInfo($"({bt.Prefix}) has stopped auto mining");
                    return;
                }
                else if (parsed)
                {
                    CommandHandler.WriteError("It looks as if you entered an invalid integer");
                    return;
                }
                else
                {
                    string botsName = args[1].ToUpper();

                    foreach (var bt in BotManager.bots)
                    {
                        if (botsName == bt.Player?.myPlayerData?.RealUsername.ToUpper())
                        {
                            bt.auto.autoMine.StopAutoMine();

                            CommandHandler.WriteInfo("Stopping automine on the bot named " + botsName);
                            return;
                        }

                    }

                    CommandHandler.WriteError("No bot was started please try again in a few seconds as the bot might still be connecting. Or you spelt something wrong.");
                }


            }

        }
        [Command("info", "Gives you some basic information")]
        public void Info(string[] args)
        {
            CommandHandler.WriteInfo("Arhi bots 2023\nProgramming done by krak\nArtwork done by arhi998\nEmotional support done by Jed");
        }

        [Command("bots", "Gives some information about the current connected bots")]
        public void bots(string[] args)
        {
            Console.WriteLine("\nArhi bots info:\n");
            Console.WriteLine($"Current connected bots ({BotManager.bots.Count})");
            foreach (var bot in BotManager.bots)
            {
                Console.WriteLine($" - {bot.Prefix} ");
                Console.WriteLine($"\tPing: {bot.NetworkClient.ping}");
                Console.WriteLine($"\tStatus - {bot.status}");
                if (bot.auto.autoMine.Automine)
                {
                    Console.WriteLine($"\tMining gems: {bot.mgemCount}");
                    Console.WriteLine($"\tCurrent mine level: {bot.Player.currentMineLevel}");
                    Console.WriteLine($"\tBlocks left: {bot.auto.autoMine.autoMinePath.Count}");
                    Console.WriteLine($"\tCompletion time: {bot.auto.autoMine.estimatedCompletionTime} secs");
                }
            }
        }

        [Command("uptime", "get the uptime of the bots")]
        public void Uptime(string[] args)
        {
            CommandHandler.WriteInfo("Uptime: " + Program.UPTIME.Elapsed.TotalSeconds + " seconds");
        }

        [Command("gems", "Get the total gems of the bots.")]
        public void Gems(string[] args)
        {
            int totalGems = 0;
            foreach (var bot in BotManager.bots)
            {
                totalGems += bot.mgemCount;
                Console.WriteLine($"{bot.Prefix, -16} gems: {bot.mgemCount}");
            }
            Console.WriteLine("Total gems: " + totalGems);
        }

        [Command("add", "add bot via username and password")]
        public void add(string[] args)
        {
            if (args.Length != 4)
            {
                CommandHandler.WriteError("Usage: add (username) (password) (world)");
                return;
            }
            var loginInfo = AWSRequests.LoginWithUsernameAndPassword(args[1], args[2]);
            if (loginInfo != null)
            {
                Bot.Create(loginInfo.identityId, loginInfo.logintoken, args[3]);
            }
        }

        [Command("autodrop", "Pretty self explanitory lol")]
        public void autodrop(string[] args)
        {
            if (args.Length != 2)
            {
                CommandHandler.WriteError("Usage: autodrop (bot)");
                return;
            }

            if (args[1] == "-all")
            {
                CommandHandler.WriteInfo("auto dropping on all bots");
                foreach(var bot in BotManager.bots)
                {
                    bot.auto.autoDrop.StartDropping();
                }
            }
            else
            {
                Bot bot = BotManager.GetBotViaString(args[1]);
                if (bot != null)
                {
                    CommandHandler.WriteInfo($"Auto dropping on {bot.Prefix}");
                    bot.auto.autoDrop.StartDropping();
                }
                else
                {
                    CommandHandler.WriteError("Error finding bot are you sure you entered a valid username/index?");
                }
            }




        }


        [Command("restart", "restarts bot via index/name")]
        public void restart(string[] args)
        {
            if (args.Length != 2)
            {
                CommandHandler.WriteError("usage: restart (bot: index/username)");
                return;
            }

            Bot bot = BotManager.GetBotViaString(args[1]);
            if (bot != null)
            {
                CommandHandler.WriteInfo(bot.Prefix + " has been restarted");
                Bot.Create(bot.ident.CognitoID, bot.ident.Token, (bot.status == PlayerConnectionStatus.InRoom && bot.world.WorldName.ToUpper() != "MINEWORLD") ? bot.world.WorldName : "SWAGBAG69");
                bot.Dispose();
                BotManager.bots.Remove(bot);
            }
            else
            {
                CommandHandler.WriteError($"Couldnt find a bot for input:\"{args[1]}\"");
            }
        }

        [Command("casino", "start the casino bot")]
        public void Casino(string[] args)
        {
            CasinoDiscordBot.StartCasinoBot();
        }

        [Command("minelevel", "Choose which mine level to mine.")]
        public void MineLevel(string[] args)
        {
            if (args.Length == 1)
            {
                Console.WriteLine("Mine level 5: " + Globals.MineLevel5);
                Console.WriteLine("Mine level 4: " + Globals.MineLevel4);
                Console.WriteLine("Mine level 3: " + Globals.MineLevel3);
                Console.WriteLine("Mine level 2: " + Globals.MineLevel2);
                Console.WriteLine("Mine level 1: " + Globals.MineLevel1);
                return;
            }

            if (args.Length != 2)
            {
                return;
            }

            if (int.TryParse(args[1], out int level))
            {
                if (level < 0 || level > 5)
                {
                    CommandHandler.WriteError("Please enter an integer between 1 and 5");
                    return;
                }
                bool[] mineLevels = new bool[5] { Globals.MineLevel1, Globals.MineLevel2, Globals.MineLevel3, Globals.MineLevel4, Globals.MineLevel5 };
                mineLevels[level - 1] = !mineLevels[level - 1];
                Globals.MineLevel1 = mineLevels[0];
                Globals.MineLevel2 = mineLevels[1];
                Globals.MineLevel3 = mineLevels[2];
                Globals.MineLevel4 = mineLevels[3];
                Globals.MineLevel5 = mineLevels[4];
                Config.SaveSettings();

            }
            else
            {
                CommandHandler.WriteError("Invalid integer");
                return;
            }
        }
    }
}