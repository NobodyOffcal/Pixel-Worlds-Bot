﻿using ArhiBots.Bots;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.GUI
{
    public sealed class ConsoleGui
    {
        

        public static void DrawBots()
        {

           

        }


    }

   
}
