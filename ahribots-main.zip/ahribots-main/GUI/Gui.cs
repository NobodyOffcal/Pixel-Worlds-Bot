﻿namespace ArhiBots.GUI
{
    using ClickableTransparentOverlay;
    using System.Threading.Tasks;
    using ImGuiNET;
    using System.Numerics;
    using ArhiBots;
    using ArhiBots.Bots;
    using ArhiBots.Structs;
    using Newtonsoft.Json;
    using ArhiBots.Bots.Auto;
    using ArhiBots.Constants;
    using ArhiBots.Pathfinding;
    using ArhiBots.Misc;
    using System.Data;
    using ArhiBots.GUI.Command_Handler;

    public class SampleOverlay : Overlay
    {
        private bool keepWindow = true;

        private Vector2 swipeableAreaSize = new(400, 200);
        private int selectedBotIndex = -1;
        public static bool GUIRUNNING = false;
        Random rand = new Random();
        int index = -1;
        public string cognitoID = "";
        public string token = "";
        public static string path = "accounts.json";
        public void AddRandomAccount()
        {


            List<Acc> accounts = JsonConvert.DeserializeObject<List<Acc>>(File.ReadAllText(path));
            if (accounts == null)
                return;

            Acc acc = accounts[rand.Next(0, accounts.Count)];
            Bot.Create(acc.CognitoID, acc.Token, wn);
        }

        public static void LogInAll()
        {
            List<Acc> accounts = JsonConvert.DeserializeObject<List<Acc>>(File.ReadAllText(path));
            if (accounts == null)
                return;

            foreach (Acc acc in accounts)
            {
                Bot.Create(acc.CognitoID, acc.Token, (acc.World == null) ? wn : acc.World);
            }
        }
        protected override Task PostInitialized()
        {
            Logger.Log(Logger.LogType.Debug, "ImGui Setup");
            VSync = false;
            return Task.CompletedTask;
        }
        public static string wn = "swagbag69";

        protected override void Render()
        {
            NewUI();
            //OldUI();



        }

        public void End()
        {
            if (!keepWindow)
            {
                Close();
                WebhookLogs.SendStopped();
                Environment.Exit(0);
            }
        }

        public void End(bool endUI)
        {
            if (endUI)
            {
                GUIRUNNING = false;
                Close();
            }
        }

        bool SelectAll = false;

        Bot bot
        {
            get
            {
                if (selectedBotIndex == -1)
                {
                    return new();
                }

                return BotManager.bots[selectedBotIndex];
            }
        }

        public static void AutoMineAll()
        {
            foreach (var bt in BotManager.bots)
            {
                bt.auto.autoMine.Automine = true;

                if (bt.world == null)
                {
                    bt.auto.autoMine.joinedMineStart = true;
                    continue;
                }
                if (bt.world.WorldName != "MINEWORLD")
                {
                    bt.auto.autoMine.joinedMineStart = true;
                    continue;
                }

                bt.auto.autoMine.joinedMineStart = false;
                Task.Run(() => bt.auto.autoMine.AutoMineStart());
            }
        }

        #region add bot ui variables
        bool addNewBot = false;
        string coid = "", tk = "";
        string username = "", password = "";
        bool LoginWithCoid = false;
        #endregion
        float miniMapZoomLevel = 1.25f;
        string enteredWorldName = "";
        string sayText = "";
        private float zoomLevel = 1.25f;
        private bool showMiniMap = false;


        private static bool _errorWindow = false;
        private static string _errorMessage = "";

        void NewUI()
        {
            #region IMGUI STYLE
            Vector4 purpleCol = new(0.451f, 0, 0.42f, 1f);
            ImGui.StyleColorsClassic();
            //ImGui.PushStyleColor(ImGuiCol, new Vector4(1, 0, 1, 1));

            #endregion
            
            if(_errorWindow)
            {
                ImGui.Begin("Error message", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoDocking);
                {

                    ImGui.SetWindowSize(new(300, 210));

                    ImGui.TextWrapped(_errorMessage);

                    if (ImGui.Button("Ok", new(80, 50)))
                    {
                        _errorWindow = false;
                    }

                    ImGui.End();
                }
            }

            if (addNewBot)
            {
                ImGui.Begin("Add bot", ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoDocking | ImGuiWindowFlags.NoTitleBar);
                {
                    ImGui.SetWindowSize(new(300, 210));
                    
                    if (!LoginWithCoid)
                    {
                        ImGui.Text("Cognito ID");
                        ImGui.PushItemWidth(285);
                        ImGui.InputText("##COGID_ADDBOT", ref coid, 200);
                        ImGui.Text("Token");
                        ImGui.InputText("##TokenID_ADDBOT", ref tk, 200);
                        ImGui.PopItemWidth();
                    }
                    else
                    {
                        ImGui.Text("Username");
                        ImGui.PushItemWidth(285);
                        ImGui.InputText("##user_ADDBOT", ref username, 200);
                        ImGui.Text("Password");
                        ImGui.InputText("##pass_ADDBOT", ref password, 200);
                        ImGui.PopItemWidth();
                    }
                    ImGui.NewLine();

                    ImGui.Checkbox("Login with username and password", ref LoginWithCoid);

                    if (ImGui.Button("Add", new Vector2(137.5f, 35)))
                    {

                        
                        if (!LoginWithCoid)
                        {
                            Bot.Create(coid, tk, wn);
                            coid = ""; tk = "";
                            addNewBot = false;
                        }
                        else
                        {
                            var loginInfo = AWSRequests.LoginWithUsernameAndPassword(username, password);
                            if (loginInfo != null)
                            {
                                Bot.Create(loginInfo.identityId, loginInfo.logintoken, wn);   
                            }
                            username = ""; password = "";
                            addNewBot = false;
                        }

                    }
                    ImGui.SameLine();
                    if (ImGui.Button("Cancel", new Vector2(137.5f, 35)))
                    {
                        addNewBot = false;

                    }


                    ImGui.Text("World name");
                    ImGui.SameLine();
                    ImGui.InputText("##WorldNameLol", ref wn, 18, ImGuiInputTextFlags.CharsNoBlank);

                }
                ImGui.End();
            }



            ImGui.Begin("Arhi bots made by krak", ref keepWindow, ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoBringToFrontOnFocus);
            ImGui.SetWindowSize(new(800, 450));


            ImGui.BeginChild("##SELECT_BOTS_Area", new Vector2(200, 415), true, ImGuiWindowFlags.NoScrollbar);
            {
                if (ImGui.Checkbox("Select all", ref SelectAll))
                {
                    if (SelectAll)
                        selectedBotIndex = -1;

                }

                ImGui.BeginChild("##actually_selectem", new Vector2(185, 308), true, ImGuiWindowFlags.NoScrollbar);
                {
                    for (int i = 0; i < BotManager.bots.Count; i++)
                    {
                        string botName = BotManager.bots[i].Prefix;
                        bool isBotSelected = i == selectedBotIndex;

                        if (ImGui.Selectable(botName, isBotSelected, ImGuiSelectableFlags.None, new(400, 15)))
                        {
                            if (selectedBotIndex == i)
                                selectedBotIndex = -1;
                            else if (selectedBotIndex != i)
                                selectedBotIndex = i;

                            SelectAll = false;
                        }

                        if (isBotSelected)
                            BotManager.bots[i].IsSelected = true;
                        else
                            BotManager.bots[i].IsSelected = false;
                    }
                }
                ImGui.EndChild();
                if (ImGui.Button("Add bot", new Vector2(185, 30)))
                {
                    coid = "us-east-1:19b3215f-add8-438d-b2e2-48c3d504c4cc";
                    tk = "TrvTzG9RbM2u9smEv09Nvk9A7NgurhW/JU2q8NY3XXE=";
                    username = ""; password = "";
                    addNewBot = true;
                }
                if (ImGui.Button("Remove bot", new Vector2(185, 30)))
                {
                    BotManager.RemoveBot(selectedBotIndex);
                    if (BotManager.bots.Count <= selectedBotIndex) selectedBotIndex--;
                }
            }
            ImGui.EndChild();

            ImGui.SameLine();

            ImGui.BeginChild("##BOT_PANEL_CONTROL", new Vector2(575, 415), true, ImGuiWindowFlags.NoScrollbar);
            {
                ImGui.BeginTabBar("##BOT_OPTIONS");
                {

                    if (ImGui.BeginTabItem($"Bot Info"))
                    {

                        if (bot.NoBotSelected)
                        {
                            ImGui.Text("No bot is selected");
                            goto ENDOfTAB;
                        }

                        if (!bot.Player.myPlayerData.playerDataSetup)
                        {

                            ImGui.Text("Player data is still loading");

                            if (ImGui.Button("Reconnect bot"))
                            {

                                Bot.Create(bot.ident.CognitoID, bot.ident.Token, wn);
                                BotManager.RemoveBot(BotManager.bots.IndexOf(bot));
                            }
                            goto ENDOfTAB;
                        }


                        ImGui.BeginChild("##BOTINFOCHILD1", new(275f, 186.5f * 2), true, ImGuiWindowFlags.NoScrollbar);
                        {
                            ImGui.Text("Info");
                            ImGui.Separator();
                            ImGui.Text($"Name: {bot.Prefix}");
                            ImGui.Text($"Ping: {bot.NetworkClient.ping}");
                            ImGui.Text($"World: {(bot.status != PlayerConnectionStatus.InRoom ? "(menus)" : bot.world.WorldName)}");
                            ImGui.Text($"Status: {bot.status}");
                            ImGui.Text($"Gems: {bot.Player.myPlayerData.gems}");
                            ImGui.Text($"Pos: {bot.Player.CurrentPosition.X}, {bot.Player.CurrentPosition.Y}");
                            ImGui.Text($"MapPoint: {bot.Player.currentPlayerMapPoint.x}, {bot.Player.currentPlayerMapPoint.y}");

                            ImGui.Text($"Inventory ({bot.Player.myPlayerData.inventory.Count}/{bot.Player.myPlayerData.inventorySlots})");
                            ImGui.SameLine();
                            if (ImGui.Button("Open inv"))
                            {

                            }
                            if (ImGui.Button("Reconnect bot"))
                            {

                                Bot.Create(bot.ident.CognitoID, bot.ident.Token, wn);
                                BotManager.RemoveBot(BotManager.bots.IndexOf(bot));
                                return;
                            }

                        }
                        ImGui.EndChild();
                        ImGui.SameLine();
                        ImGui.BeginChild("##BOTINFOCHILD2", new(275f, 186.5f * 2), true, ImGuiWindowFlags.NoScrollbar);
                        {
                            ImGui.Text("Basic controls");
                            ImGui.Separator();
                            ImGui.Checkbox("Collect items", ref bot.ForceCollect);
                            ImGui.Checkbox("+1 range collect", ref bot.RangedCollect);
                            ImGui.Text("warp to world");
                            ImGui.InputText("##WNINPUT_@@#", ref enteredWorldName, 16, ImGuiInputTextFlags.CharsNoBlank);
                            ImGui.SameLine();
                            if (ImGui.Button("Warp"))
                            {
                                bot.Player.WarpFromWorldToWorld(enteredWorldName.EndsWith("\\n") ? enteredWorldName.Replace("\\n", "\n") : enteredWorldName);
                            }

                            ImGui.Text("send a message");
                            ImGui.InputText("##SayINPUT_@@#", ref sayText, 400);
                            ImGui.SameLine();
                            if (ImGui.Button("Say"))
                            {
                                if (bot.status == PlayerConnectionStatus.InRoom)
                                    bot.OutgoingMessages.SendMessage(sayText);
                            }

                            ImGui.Text("Bot movementspeed");
                            ImGui.SliderFloat("##msofbot", ref bot.Player.pathfind.Movespeed, 0f, 1f);

                            ImGui.Text("");
                            ImGui.SameLine(62.5f);
                            ImGui.Text("Simply move bots");

                            ImGui.Text("");
                            ImGui.SameLine(62.5f);
                            ImGui.BeginChild("#FamiliarBotControls__12", new(157.5f, 157.5f), true, ImGuiWindowFlags.NoScrollbar);
                            {
                                ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, Vector2.Zero);
                                ImGui.Text("");
                                ImGui.SameLine(55);
                                ImGui.Button("Up", new Vector2(47.5f, 47.5f));
                                ImGui.Button("Left", new Vector2(47.5f, 47.5f));
                                ImGui.SameLine();
                                ImGui.Button("Enter", new Vector2(47.5f, 47.5f));
                                ImGui.SameLine();
                                ImGui.Button("Right", new Vector2(47.5f, 47.5f));

                                ImGui.Text("");
                                ImGui.SameLine(55);
                                ImGui.Button("Down", new Vector2(47.5f, 47.5f));
                                ImGui.PopStyleVar();
                            }
                            ImGui.EndChild();
                        }
                        ImGui.EndChild();

                    ENDOfTAB:
                        ImGui.EndTabItem();
                    }

                    if (ImGui.BeginTabItem($"World"))
                    {
                        if (bot.NoBotSelected)
                        {
                            ImGui.Text("No bot is selected");
                            goto ENDOfTAB;
                        }

                        if (bot.status != PlayerConnectionStatus.InRoom || bot.world == null)
                        {
                            ImGui.Text("Bot is not in a world yet");
                            goto ENDOfTAB;
                        }


                        ImGui.BeginTabBar("##WORLDTAB_!@NAs", ImGuiTabBarFlags.None);
                        {


                            if (ImGui.BeginTabItem("Mini-map"))
                            {
                                ImGui.BeginChild("##MINIMAP@@", new Vector2(560, 355), false, ImGuiWindowFlags.HorizontalScrollbar);
                                {
                                   

                                    if (!bot.IsSelected) goto ENDCHILDFRAME;

                                    if (!showMiniMap)
                                    {
                                        ImGui.Text("the minimap causes severe memory issues right now!\nAre you sure you want to use it?");
                                        showMiniMap = ImGui.Button("YES", new Vector2(80, 50));
                                        goto ENDCHILDFRAME;
                                    }

                                    if (bot.NetworkClient.playerConnectionStatus != PlayerConnectionStatus.InRoom)
                                    {
                                        ImGui.Text("Join a world first lol");
                                        goto ENDCHILDFRAME;
                                    }
                                    ImGui.Text("World name: " + bot.world.WorldName);
                                    ImGui.Text("Use W to zoom in and S to zoom out!");
                                    ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, Vector2.Zero);
                                    ImGui.BeginChildFrame(ImGui.GetID("MiniMap"), new Vector2(0, 0), ImGuiWindowFlags.HorizontalScrollbar);


                                    if (ImGui.IsKeyPressed(ImGui.GetKeyIndex(ImGuiKey.W)))
                                    {
                                        zoomLevel += 0.25f;
                                    }
                                    if (ImGui.IsKeyPressed(ImGui.GetKeyIndex(ImGuiKey.S)))
                                    {
                                        zoomLevel -= 0.25f;
                                        if (zoomLevel <= .5f)
                                        {
                                            zoomLevel = .5f;
                                        }
                                    }

                                    for (int y = bot.world.worldSize.y - 1; y >= 0; y--)
                                    {
                                        for (int x = 0; x < bot.world.worldSize.x; x++)
                                        {

                                            bool localPlayer = false;
                                            Vector2i currentMP = new Vector2i(x, y);
                                            BlockType block = bot.world.GetBlockType(x, y);

                                            bool pushedAlready = false;


                                            if (bot.Player.pathfind.RenderPath != null)
                                            {
                                                if (bot.Player.pathfind.RenderPath.Contains(PNode.Create(x, y)))
                                                {
                                                    ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(1f, 0, 0, 1));
                                                    pushedAlready = true;
                                                }
                                            }

                                            if (bot.auto.autoMine.autoMinePath != null)
                                            {
                                                if (bot.auto.autoMine.autoMinePath.Contains(PNode.Create(x, y)) && !pushedAlready)
                                                {
                                                    ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(1f, 0, 0, 1));
                                                    pushedAlready = true;
                                                }
                                            }

                                            if (!pushedAlready && currentMP == bot.Player.currentPlayerMapPoint)
                                            {
                                                localPlayer = true;
                                                ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0, 1, .2f, 1));
                                                pushedAlready = true;
                                            }

                                            if (!pushedAlready)
                                            {
                                                float[] data = ConfigData.GetItemColor((int)block);
                                                if (ConfigData.IsGemStone(block))
                                                {
                                                    ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0, 1, 1, 1));
                                                }
                                                else
                                                {
                                                    if (!ConfigData.DoesBlockHaveCollider(block))
                                                    {

                                                        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.3137f, 0.3137f, 0.3137f, 1));
                                                        //ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.4f, 0.1607843137254902f, 0.5686274509803922f, 1));
                                                    }
                                                    else
                                                    {

                                                        ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(data[0], data[1], data[2], data[3]));
                                                    }
                                                }
                                            }
                                            if (ImGui.Button($"##{x}-{y}", new Vector2(5 * zoomLevel, 5 * zoomLevel)))
                                            {
                                              bot.Player.FindPath(new Vector2i(x, y));
                                            }

                                            if (ImGui.IsItemHovered())
                                            {
                                                string ToolTipText = $"Position: ({x}, {y})\nBlockType: {block}";
                                                if (localPlayer) ToolTipText += $"\nLocal Player";
                                                if (Globals.ItemBsonInTooltips)
                                                    if (bot.world.worldsItemBson[x][y] != null)
                                                    {
                                                        ToolTipText += "\n" + Logger.GetBsonAsString(bot.world.worldsItemBson[x][y]);
                                                    }
                                                ImGui.SetTooltip(ToolTipText);
                                            }
                                            ImGui.SameLine();
                                        }
                                        ImGui.NewLine();
                                    }
                                    
                                    //ImGui.PushStyleColor(ImGuiCol.Button, 1727698498);
                                    //ImGui.PopStyleVar();
                                    ImGui.Text("Movement speed (Lower speeds might cause more disconnects)");
                                    ImGui.SliderFloat("##MoveSPeed", ref bot.Player.pathfind.Movespeed, 0f, 1f);
                                    
                                    ImGui.EndChildFrame();
                                    ENDCHILDFRAME:
                                    ImGui.EndChild();
                                }
                                ImGui.EndTabItem();
                            }

                            if (ImGui.BeginTabItem("collectables"))
                            {
                                ImGui.BeginChild("##COllectables_214d", new Vector2(560, 355), false, ImGuiWindowFlags.NoScrollbar);
                                {
                                    int i = 1;
                                    foreach (CollectableData col in bot.world.collectables)
                                    {

                                        ImGui.BeginChild($"##{bot.Prefix}##bcc{col.Amount}{col.PosX}{col.PosY}", new Vector2(181f, 355 / 3), true, ImGuiWindowFlags.None);
                                        {
                                            ImGui.Text($"BT: {col.blockType}");
                                            ImGui.Text($"IT: {col.InventoryType}");
                                            ImGui.Text($"Amount {col.Amount}");
                                            ImGui.Text($"Is gem? {col.IsGem}");
                                            ImGui.Text($"Gem Type: {col.GemType} ({ConfigData.GetGemValue(col.GemType)})");
                                            ImGui.Text($"Position: {col.PosX}, {col.PosY}");

                                        }
                                        ImGui.EndChild();
                                        ImGui.SameLine();
                                        if (i % 3 == 0)
                                        {
                                            ImGui.NewLine();
                                        }
                                        ++i;
                                    }
                                }
                                ImGui.EndChild();
                                ImGui.EndTabItem();
                            }
                        }
                        ImGui.EndTabBar();



                    ENDOfTAB:
                        ImGui.EndTabItem();
                    }

                    if (ImGui.BeginTabItem("Misc"))
                    {
                        ImGui.BeginTabBar("##autooptions");
                        {

                            if (ImGui.BeginTabItem("Auto"))
                            {
                                if (bot.NoBotSelected)
                                {
                                    ImGui.Text("No bot is selected");
                                    goto ENDOfTAB;
                                }

                                if (bot.status != PlayerConnectionStatus.InRoom || bot.world == null)
                                {
                                    ImGui.Text("Bot is not in a world yet");
                                    goto ENDOfTAB;
                                }
                                ImGui.Text("Selected Block");
                                if (ImGui.BeginCombo("##SelectedBlock", bot.auto.autoFarm.block.ToString()))
                                {
                                    foreach (InventoryKey key in bot.Player.myPlayerData.GetInventoryAsOrderedByInventoryItemType())
                                    {
                                        if (key.itemType == InventoryItemType.Block)
                                        {
                                            if (ImGui.Selectable(key.blockType.ToString(), bot.auto.autoFarm.block == key.blockType))
                                            {
                                                bot.auto.autoFarm.block = key.blockType;
                                            }
                                        }

                                    }
                                    ImGui.EndCombo();
                                }
                                if (ImGui.Button(bot.auto.autoFarm.auto ? "Stop" : "Start"))
                                {
                                    bot.auto.autoFarm.auto = !bot.auto.autoFarm.auto;
                                }



                                // auto spam 

                                ImGui.NewLine();
                                ImGui.Text("auto spam");
                                if (ImGui.Button((bot.auto.autoSpam.Spam ? "Stop" : "start"), new(75, 50)))
                                    bot.auto.autoSpam.StartStop();

                                ImGui.Text("Spawned: " + bot.auto.autoSpam.spawned);
                                ImGui.Text("Spam???: " + bot.auto.autoSpam.Spam);
                                ImGui.Text("interpolation: " + bot.auto.autoSpam.interpolation);



                                if(ImGui.Button("Swap with mannequin", new(100, 75)))
                                {

                                    //bot.world.SwapClothesWithMannequin(bot.Player.currentPlayerMapPoint);
                                    bot.auto.autoMannequin.Start();
                                }

                                ENDOfTAB:
                                ImGui.EndTabItem();
                            }


                            if (ImGui.BeginTabItem("Inventory"))
                            {
                                if (bot.NoBotSelected)
                                {
                                    ImGui.Text("No bot is selected");
                                    goto ENDOfTAB;
                                }

                                if (bot.Player.myPlayerData == null)
                                {
                                    ImGui.Text("Player data hasnt loaded yet");
                                    goto ENDOfTAB;
                                }

                                if (bot.Player.myPlayerData.inventory == null)
                                {
                                    ImGui.Text("Player data hasnt loaded yet");
                                    goto ENDOfTAB;
                                }
                                if (ImGui.Button("Auto Drop", new(80, 50)))
                                {
                                    bot.auto.autoDrop.StartDropping();
                                }
                                ImGui.SameLine();
                                if (ImGui.Button("Auto drop all", new(100, 50)))
                                {
                                    foreach (var bt in BotManager.bots)
                                    {
                                        bt.auto.autoDrop.StartDropping();
                                    }
                                }
                                ImGui.SameLine();
                                if (ImGui.Button("Spin mining wheel", new(100, 50)))
                                {
                                    bot.OutgoingMessages.SpinMiningWheel();
                                }

                                var inv = bot.Player.myPlayerData.GetInventoryAsOrderedByInventoryItemType();
                                foreach (InventoryKey key in inv)
                                {
                                    ImGui.BeginChild(key + "1", new Vector2(560, 35), true, ImGuiWindowFlags.NoScrollWithMouse | ImGuiWindowFlags.NoScrollbar);
                                    {
                                        ImGui.BeginChild($"##{key}+21{key.blockType}", new(340, 35));
                                        {
                                            ImGui.Text(bot.Player.myPlayerData.GetCount(key) + "x " + ConfigData.InventoryKeyText(key));
                                        }
                                        ImGui.EndChild();
                                        ImGui.SameLine();
                                        ImGui.BeginChild($"##{key}+21{key.itemType}", new(200, 35));
                                        {
                                            if (bot.status == PlayerConnectionStatus.InRoom)
                                            {
                                                if (key.itemType == InventoryItemType.Weapon || key.itemType == InventoryItemType.WearableItem)
                                                {
                                                    bool equiped = bot.Player.IsItemEquiped(key.blockType);
                                                    if (ImGui.Button(equiped ? "Unequip" : "Equip", new(63, 22)))
                                                    {
                                                        bot.Player.ChangeWearable(key.blockType);
                                                    }
                                                }
                                                else
                                                {
                                                    ImGui.InvisibleButton($"", new(63, 22));
                                                }
                                                ImGui.SameLine();
                                                if (ImGui.Button("Drop", new(60, 22)))
                                                {

                                                    if (!ConfigData.DoesBlockHaveCollider(bot.world.GetBlockType(bot.Player.GetNextUNSAFEPlayerPositionBasedOnLookDirection())))
                                                    {
                                                        bot.Player.DropItems(key, bot.Player.myPlayerData.GetCount(key));
                                                    }
                                                    else
                                                    {
                                                        if (bot.Player.direction == Direction.Left)
                                                        {
                                                            bot.Player.direction = Direction.Right;
                                                        }
                                                        else if (bot.Player.direction == Direction.Right)
                                                        {
                                                            bot.Player.direction = Direction.Left;
                                                        }
                                                    }

                                                }
                                                ImGui.SameLine();
                                                ImGui.Button("Trash", new(60, 22));
                                            }
                                        }
                                        ImGui.EndChild();
                                    }
                                    ImGui.EndChild();
                                }


                            ENDOfTAB:
                                ImGui.EndTabItem();
                            }
                        }
                        ImGui.EndTabBar();
                        ImGui.EndTabItem();
                    }
                    if (ImGui.BeginTabItem($"Botting"))
                    {
                        ImGui.BeginChild("##AUTOSTABSSS@@@", new Vector2(560, 375), false, ImGuiWindowFlags.NoScrollbar);
                        {
                            if (ImGui.Button("Automine all", new(100, 35)))
                            {
                                AutoMineAll();
                            }
                            ImGui.Separator();
                            int i = 1;
                            foreach (var bt in BotManager.bots)
                            {
                                ImGui.BeginChild($"##{bt.Prefix}{i}##bottabhs", new Vector2(181f, 185f), true, ImGuiWindowFlags.None);
                                {
                                    ImGui.Text(bt.Prefix);
                                    ImGui.Separator();
                                    ImGui.Text("Status: " + bt.status);
                                    ImGui.Text("Ping: " + bt.NetworkClient.ping);
                                    ImGui.Text("World: " + (bt.world == null ? "(MENUS)" : bt.world.WorldName));

                                    if (bt.auto.autoMine.Automine)
                                    {
                                        if (ImGui.Button("Stop auto mine", new Vector2(166, 0)))
                                        {
                                            bt.auto.autoMine.joinedMineStart = false;
                                            bt.auto.autoMine.Automine = false;
                                            bt.auto.autoMine.miningState = MiningState.None;
                                            bt.auto.autoMine.autoMinePath.Clear();
                                        }
                                    }
                                    else
                                    {
                                        if (ImGui.Button("Start auto mine", new Vector2(166, 0)))
                                        {

                                            bt.auto.autoMine.Automine = true;

                                            if (bt.world == null)
                                            {
                                                bt.auto.autoMine.joinedMineStart = true;
                                                continue;
                                            }

                                            if (bt.world.WorldName != "MINEWORLD")
                                            {
                                                bt.auto.autoMine.joinedMineStart = true;
                                                continue;
                                            }

                                            bt.auto.autoMine.joinedMineStart = false;
                                            Task.Run(() => bt.auto.autoMine.AutoMineStart());
                                        }
                                    }


                                    if (bt.auto.autoMine.Automine)
                                    {
                                        ImGui.Text("Automining info: ");
                                        ImGui.Text("Current level: " + bt.Player.currentMineLevel);
                                        ImGui.Text("Blocks left: " + bt.auto.autoMine.autoMinePath.Count);
                                        ImGui.Text("Secs till done: " + MathF.Round(bt.auto.autoMine.estimatedCompletionTime, 2));
                                    }

                                }
                                ImGui.EndChild();
                                ImGui.SameLine();
                                if (i % 3 == 0)
                                {
                                    ImGui.NewLine();
                                }

                                i++;
                            }
                            ImGui.EndTabItem();
                        }

                        ImGui.EndChild();
                        ImGui.EndTabItem();

                    }

                    if (ImGui.BeginTabItem($"Settings"))
                    {
                        if (ImGui.CollapsingHeader("accounts", ImGuiTreeNodeFlags.Bullet))
                        {
                            ImGui.Text("FilePath");
                            ImGui.SameLine();
                            ImGui.PushItemWidth(500);
                            if (ImGui.InputText("##FilePath", ref path, 1000)) Config.SaveSettings();
                            ImGui.PopItemWidth();


                            if (ImGui.Button("Import", new Vector2(100, 40)))
                            {
                                Task.Run(() => LogInAll());
                            }
                            ImGui.SameLine();
                            if (ImGui.Button("Export", new Vector2(100, 40)))
                            {
                                List<Acc> accs = new List<Acc>();

                                foreach (var bt in BotManager.bots)
                                {
                                    Acc acc = new Acc(bt.ident.CognitoID, bt.ident.Token, bt.worldOnLoad);
                                    accs.Add(acc);
                                }

                                string json = JsonConvert.SerializeObject(accs);
                                File.WriteAllText(path, json);
                            }
                        }

                        if (ImGui.Checkbox("Log", ref Globals.Log)) Config.SaveSettings();
                        if (ImGui.Checkbox("Item bson tooltip (OOF)", ref Globals.ItemBsonInTooltips)) Config.SaveSettings();
                        ImGui.Checkbox("Vsync", ref VSync);


                        if (ImGui.CollapsingHeader("mining levels", ImGuiTreeNodeFlags.Bullet))
                        {
                            if (ImGui.Checkbox("Mine level 5", ref Globals.MineLevel5)) Config.SaveSettings();
                            if (ImGui.Checkbox("Mine level 4", ref Globals.MineLevel4)) Config.SaveSettings();
                            if (ImGui.Checkbox("Mine level 3", ref Globals.MineLevel3)) Config.SaveSettings();
                            if (ImGui.Checkbox("Mine level 2", ref Globals.MineLevel2)) Config.SaveSettings();
                        }

                        if (ImGui.CollapsingHeader("webhook", ImGuiTreeNodeFlags.Bullet))
                        {
                            ImGui.Text("Webhook");
                            ImGui.SameLine();
                            ImGui.PushItemWidth(500);
                            if (ImGui.InputText("##Webhook", ref Globals.webhook, 300)) Config.SaveSettings();
                            ImGui.PopItemWidth();

                            if (ImGui.Button("Start webhook", new(100, 35)))
                            {
                                WebhookLogs.SendBotsStatus();
                            }

                            if (WebhookLogs.WebhookMessageSent)
                            {
                                ImGui.SameLine();
                                if (ImGui.Button("Stop webhook", new(100, 35)))
                                {
                                    WebhookLogs.SendStopped();
                                    WebhookLogs.WebhookMessageSent = false;
                                }
                            }
                        }
                        ImGui.EndTabItem();
                    }
                }
                ImGui.EndTabBar();
            }
            ImGui.EndChild();

            End();
            ImGui.End();

        }


        public static void ShowErrorWindow(string _message)
        {
            if (!GUIRUNNING)
            {
                CommandHandler.WriteError(_message);
                return;
            }
            _errorMessage = _message;
            _errorWindow = true;
        }
    }
}

