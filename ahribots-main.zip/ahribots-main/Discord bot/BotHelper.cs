﻿using ArhiBots.Bots;
using ArhiBots.Discord_bot.Bot_helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot
{
    public class BotHelper
    {
        public Bot Bot { get; set; }
        public Casino Casino { get; set; }

        public BotHelper(Bot bot) { 
            this.Bot = bot;


            Casino = new(this);
        }
        
        public void Update()
        {
            Casino.Update();
        }
        

    }

    
}
