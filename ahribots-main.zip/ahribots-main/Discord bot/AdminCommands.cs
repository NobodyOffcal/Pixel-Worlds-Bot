﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DSharpPlus;
using DSharpPlus.EventArgs;
using DSharpPlus.CommandsNext;
using DSharpPlus.Net;
using DSharpPlus.Interactivity;
using DSharpPlus.Entities;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;
using DSharpPlus.Interactivity.Extensions;
using ArhiBots.Discord_bot.Commands;
using ArhiBots.Bots;
using DSharpPlus.SlashCommands;
using ArhiBots.Discord_bot.Commands.Casino;

namespace ArhiBots.Discord_bot
{
    public class AdminCommandsBot
    {
        public static DiscordClient Client { get; private set; }
        public InteractivityExtension Interactivity { get; private set; }
        public CommandsNextExtension Commands { get; private set; }

        public static void StartDiscordBot()
        {
            AdminCommandsBot bot = new();
            bot.RunAsync().GetAwaiter().GetResult();
        }

        private async Task RunAsync()
        {

            var json = string.Empty;

            using (var fs = File.OpenRead("../Casino/admin.json"))
            using (var sr = new StreamReader(fs, new UTF8Encoding(false)))
                json = await sr.ReadToEndAsync().ConfigureAwait(false);


            var configJson = JsonConvert.DeserializeObject<ConfigJson>(json);

            var config =

            Client = new DiscordClient(new DiscordConfiguration
            {
                Token = configJson.Token,
                TokenType = TokenType.Bot,
                MinimumLogLevel = LogLevel.Debug,
                Intents = DiscordIntents.AllUnprivileged | DiscordIntents.MessageContents
            });

            Client.Ready += OnClientReady;

            Client.UseInteractivity(new InteractivityConfiguration
            {
                Timeout = TimeSpan.FromMinutes(2)
            });

            var commandsConfig = new CommandsNextConfiguration
            {
                StringPrefixes = new string[] { configJson.Prefix },
                EnableMentionPrefix = true,
                EnableDms = false,
                DmHelp = false,
                IgnoreExtraArguments = false,
            };


            //Commands = Client.UseCommandsNext(commandsConfig);
            var slash = Client.UseSlashCommands();
            slash.RegisterCommands<AdminCommands>();


            var activity = new DiscordActivity()
            {
                ActivityType = ActivityType.Playing,
                Name = "Keeping Pixel Worlds Casino safe & secure!",
                StreamUrl = "https://media.discordapp.net/attachments/1101210686555684895/1101210719963320330/Untitled514_20230312182321.png?width=662&height=662",
            };

            await Client.ConnectAsync(activity);


            await Task.Delay(-1);
        }

        private Task OnClientReady(DiscordClient client, ReadyEventArgs e)
        {
            Console.WriteLine("Admin bot online");



            return Task.CompletedTask;
        }
    }
}
