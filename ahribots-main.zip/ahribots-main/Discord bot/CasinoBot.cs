﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DSharpPlus;
using DSharpPlus.EventArgs;
using DSharpPlus.CommandsNext;
using DSharpPlus.Net;
using DSharpPlus.Interactivity;
using DSharpPlus.Entities;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;
using DSharpPlus.Interactivity.Extensions;
using ArhiBots.Discord_bot.Commands;
using ArhiBots.Bots;
using DSharpPlus.SlashCommands;
using Amazon.Lambda.Model;
using ArhiBots.GUI;
using ArhiBots.Discord_bot.Bot_helpers;
using System.Security.Cryptography;
using ArhiBots.Discord_bot.Commands.Casino;
using static ArhiBots.Discord_bot.Commands.Casino.Leaderboard;
using Google.Protobuf.Collections;

namespace ArhiBots.Discord_bot
{
    public class CasinoDiscordBot
    {

        private static readonly int StartingBytes = 1000;
        private static readonly string FilePath = "../Casino/Players.json";
        public static DiscordClient Client { get; private set; }
        public InteractivityExtension Interactivity { get; private set; }
        public CommandsNextExtension Commands { get; private set; }

        public static ulong[] admin = new ulong[] { 760084009404727297, 959197199860903956 };
        public static List<ulong> UsersUsingInGame = new List<ulong>();
        public static List<ulong> depositing = new List<ulong>();
        public static readonly int mimimumbet = 500;
        public static readonly int maximumBet = 10000000;
        public static readonly float tax = 0.05f;
        public static int HouseOdds = 55;

        public static void StartCasinoBot()
        {
            Task.Run(() => AdminCommandsBot.StartDiscordBot());
            if (!Directory.Exists("../Casino"))
                Directory.CreateDirectory("../Casino");

            if (!File.Exists("../Casino/Players.json"))
            {
                File.Create("../Casino/Players.json");
            }

            GUI.SampleOverlay.path = "../Casino/csn.json";
            Task.Run(() => SampleOverlay.LogInAll());

            CasinoDiscordBot bot = new();
            bot.RunAsync().GetAwaiter().GetResult();
        }



        private async Task RunAsync()
        {

            var json = string.Empty;

            using (var fs = File.OpenRead("../Casino/config.json"))
            using (var sr = new StreamReader(fs, new UTF8Encoding(false)))
                json = await sr.ReadToEndAsync().ConfigureAwait(false);


            var configJson = JsonConvert.DeserializeObject<ConfigJson>(json);

            var config =

            Client = new DiscordClient(new DiscordConfiguration
            {
                Token = configJson.Token,
                TokenType = TokenType.Bot,
                MinimumLogLevel = LogLevel.Error | LogLevel.Information,
                Intents = DiscordIntents.AllUnprivileged | DiscordIntents.MessageContents
            });

            Client.Ready += OnClientReady;

            Client.UseInteractivity(new InteractivityConfiguration
            {
                Timeout = TimeSpan.FromMinutes(2)
            });

            var commandsConfig = new CommandsNextConfiguration
            {
                StringPrefixes = new string[] { configJson.Prefix },
                EnableMentionPrefix = true,
                EnableDms = false,
                DmHelp = false,
                IgnoreExtraArguments = false,
            };


            //Commands = Client.UseCommandsNext(commandsConfig);
            var slash = Client.UseSlashCommands();
            slash.RegisterCommands<Balance>();
           // slash.RegisterCommands<AdminCommands>();

            slash.RegisterCommands<Chest>();

            slash.RegisterCommands<Coinflip>();

            slash.RegisterCommands<DecayDate>();

            slash.RegisterCommands<Deposit>();

            slash.RegisterCommands<Feedback>();

            slash.RegisterCommands<Give>();

            slash.RegisterCommands<Leaderboard>();

            slash.RegisterCommands<Players>();

            slash.RegisterCommands<RockPaperSciccors>();

            slash.RegisterCommands<Roulette>();

            slash.RegisterCommands<StatsCmd>();

            slash.RegisterCommands<Tower>();

            slash.RegisterCommands<Withdraw>();


            Console.WriteLine("Commands loaded...");

            var activity = new DiscordActivity()
            {
                ActivityType = ActivityType.Playing,
                Name = "Pixel Worlds Casino!",
                StreamUrl = "https://media.discordapp.net/attachments/1101210686555684895/1101210719963320330/Untitled514_20230312182321.png?width=662&height=662",
            };


            


            await Client.ConnectAsync(activity) ;


            


            await Task.Delay(-1);
        }

        private Task OnClientReady(DiscordClient client, ReadyEventArgs e)
        {
            Console.WriteLine("Bot online");

            return Task.CompletedTask;
        }



        public static List<User> Users = LoadDatabase();

        public static int GetBalance(ulong discordId)
        {
            var user = Users.Find(u => u.DiscordId == discordId);
            if (user == null)
            {
                user = new User() { Bytes = StartingBytes, DiscordId = discordId, Stats = Stats.Empty };
                Users.Add(user);
                SaveDatabase();
            }
            return user.Bytes;
        }

        public static void AddBytes(ulong discordId, int amount)
        {
            var user = Users.Find(u => u.DiscordId == discordId);
            if (user == null)
            {
                user = new User { DiscordId = discordId, Bytes = StartingBytes, Stats = Stats.Empty };
                Users.Add(user);
            }
            user.Bytes += amount;
            SaveDatabase();
        }

        public static Stats GetStats(ulong discordId)
        {
            var user = Users.Find(u => u.DiscordId == discordId);
            if (user == null)
            {
                user = new User { DiscordId = discordId, Bytes = StartingBytes, Stats = Stats.Empty };
                Users.Add(user);
                SaveDatabase();
            }
            return user.Stats;
        }
        public static void UpdateStatsForWinOrLose(DiscordUser duser, int amount, bool wins)
        {
            var user = Users.Find(u => u.DiscordId == duser.Id);
            if (user == null)
            {
                user = new User { DiscordId = duser.Id, Bytes = StartingBytes, Stats = Stats.Empty };
                Users.Add(user);
            }

            Stats stats = user.Stats;
            stats.username = duser.Username + "#" + duser.Discriminator;

            if (wins )
            {
                if (amount > stats.highest_win)
                {
                    stats.highest_win = amount;
                }
                stats.wins++;
            }
            else
            {
                if (amount > stats.highest_lost)
                {
                    stats.highest_lost = amount;
                }
                stats.bytesLost += amount;
                stats.loses++;
            }
            user.Stats = stats;
            SaveDatabase();
        }

        public static void UpdateStats(DiscordUser duser, int amount, bool deposit = false, bool withdraw = false)
        {
            var user = Users.Find(u => u.DiscordId == duser.Id);
            if (user == null)
            {
                user = new User { DiscordId = duser.Id, Bytes = StartingBytes, Stats = Stats.Empty };
                Users.Add(user);
            }

            Stats stats = user.Stats;
            stats.username = duser.Username + "#" + duser.Discriminator;

            if (deposit)
            {
                
                if (amount > 0)
                {
                    if (amount > stats.most_deposited)
                    {
                        stats.most_deposited = amount;
                    }

                    stats.deposited += amount;
                }

                user.Stats = stats;
                SaveDatabase();
                return;
            }

            if (withdraw)
            {
                if (amount > 0)
                {
                    if (amount > stats.most_withdrawn)
                    {
                        stats.most_withdrawn = amount;
                    }

                    stats.withdrawn += amount;
                }

                user.Stats = stats;
                SaveDatabase();
                return;
            }

            if (amount > stats.highest_bet)
            {
                stats.highest_bet = amount;
            }
            stats.bytesGambled += amount;

            user.Stats = stats;
            SaveDatabase();
        }

        private static List<User> LoadDatabase()
        {
            try
            {
                var json = File.ReadAllText(FilePath);
                return JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading database: {ex.Message}");
                return new List<User>();
            }
        }

        private static void SaveDatabase()
        {
            try
            {
                var json = JsonConvert.SerializeObject(Users);
                File.WriteAllText(FilePath, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving database: {ex.Message}");
            }
        }
        public static void Reval()
        {
            SaveDatabase();
            Users = LoadDatabase();
        }

        public static bool CanPayOut(int bytes)
        {
            foreach (var bot in BotManager.bots)
            {
                try
                {
                    if ((bot.Player.myPlayerData.bc * 0.5f) > bytes)
                    {
                        Console.WriteLine("We can pay " + bot.Player.myPlayerData.bc + " : " + bytes);
                        return true;
                    }
                }
                catch { }
            }
            return false;
        }

        public static int GenerateRandomSeed()
        {
            byte[] seedBytes = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(seedBytes);
            }
            long seed = BitConverter.ToInt64(seedBytes, 0) ^ BitConverter.ToInt64(seedBytes, 8);
            int seedInt = (int)(seed % ((long)int.MaxValue - (long)int.MinValue + 1)) + int.MinValue;
            Console.WriteLine("Generated random seed: " + seed);
            return seedInt;
        }

        public static DiscordEmbedBuilder GetDefaultEmbed(InteractionContext ctx)
        {
            return new DiscordEmbedBuilder()
            {
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };
        }
    }

    public class User
    {
        public ulong DiscordId { get; set; }
        public int Bytes { get; set; }
        public Stats Stats { get; set; }

        public int GetStatValue(StatsEnum stat)
        {
            switch (stat)
            {
                case StatsEnum.Balances:

                    return Bytes;
                case StatsEnum.HighestBet:
                    return Stats.highest_bet;
                case StatsEnum.HighestWin:
                    return Stats.highest_win;
                case StatsEnum.HighestLoss:
                    return Stats.highest_lost;
                case StatsEnum.BytesGambled:
                    return Stats.bytesGambled;
                case StatsEnum.BytesLost:
                    return Stats.bytesLost;
                case StatsEnum.MostWithdrawn:
                    return Stats.most_withdrawn;
                case StatsEnum.Withdrawn:
                    return Stats.withdrawn;
                case StatsEnum.MostDeposited:
                    return Stats.most_deposited;
                case StatsEnum.Deposited:
                    return Stats.deposited;
                case StatsEnum.Wins:
                    return  Stats.wins;
                case StatsEnum.Losses:
                    return Stats.loses;
                default:
                    throw new ArgumentOutOfRangeException(nameof(stat), stat, null);
            }
        }
    }

    

    public struct Stats
    {
        public string username { get; set; }
        public int highest_bet { get; set; }
        public int highest_win { get; set; }
        public int highest_lost { get; set; }
        public int bytesGambled { get; set; }
        public int bytesLost { get; set;}
        public int most_withdrawn { get; set;}
        public int withdrawn { get; set;}
        public int most_deposited { get; set;}
        public int deposited { get; set;}
        public int wins { get; set;}
        public int loses { get; set;}


        public static Stats Empty = new Stats()
        {
            username = "",
            highest_bet = 0,
            highest_win = 0,
            highest_lost = 0,
            bytesGambled = 0,
            bytesLost = 0,
            most_withdrawn = 0,
            withdrawn = 0,
            deposited = 0,
            most_deposited = 0,
            wins = 0,
            loses = 0,
        };

        

    }


}
