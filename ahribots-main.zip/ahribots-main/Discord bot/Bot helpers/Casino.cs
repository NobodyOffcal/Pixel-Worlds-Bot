﻿using Amazon.Lambda.Model;
using ArhiBots.Bots;
using ArhiBots.Constants;
using ArhiBots.Misc;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Bot_helpers
{
    public class Casino
    {
        public BotHelper botHelper;
        public CurrentTask task = CurrentTask.None;
        public string playerName;
        
        static int minimum = 10;

        public InteractionContext ctx;
        public ulong discordID = 1;
        public int bytes = 0;

        public void BeginDeposit(string playerName, InteractionContext msg, string wn)
        {
            this.ctx = msg;
            discordID = ctx.User.Id;
            bytes = 0;
            task = CurrentTask.Depositing;
            this.playerName = playerName.ToUpper();
            interpolation = 0.0f;
            botHelper.Bot.Player.WarpFromWorldToWorld(wn);
            Console.WriteLine("Depositing");
        }

        public void BeginWithdraw(string name, InteractionContext ctx, string wn, int bytes)
        {
            this.ctx = ctx;
            discordID = ctx.User.Id;
            this.bytes = bytes;
            task = CurrentTask.Withdrawing;
            this.playerName = name.ToUpper();
            interpolation = 0.0f;
            botHelper.Bot.Player.WarpFromWorldToWorld(wn);
        }

        public void BeginPlayersCheck(string worldName, InteractionContext ctx)
        {
            this.ctx = ctx;
            discordID = ctx.User.Id;
            task = CurrentTask.Players;
            interpolation = 0.0f;
            this.bytes = 2000;
            botHelper.Bot.OutgoingMessages.MenuWorldInfo(worldName.ToUpper());
        }

        public void WorldJoinResponse(WorldJoinResult result)
        {
            if (result == WorldJoinResult.Ok)
            {
                return;
            }
            var dwb = new DiscordWebhookBuilder();
            var embed = new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Red,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = "Failed to join world",
                Description = $"Join response: {result}",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };
            dwb.AddEmbed(embed.Build());
            ctx.Interaction.EditOriginalResponseAsync(dwb);
            CasinoDiscordBot.AddBytes(ctx.User.Id, this.bytes);
            Reset();
            
            
        }

        public void CheckDecayDate(string wn, InteractionContext ctx)
        {
            this.ctx = ctx;
            task = CurrentTask.DecayDate;
            discordID = ctx.User.Id;
            this.bytes = 5000;
            botHelper.Bot.Player.WarpFromWorldToWorld(wn);
        }

        public void Reset()
        {
            if (CasinoDiscordBot.depositing.Contains(ctx.User.Id))
            {
                CasinoDiscordBot.depositing.Remove(ctx.User.Id);
            }
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                CasinoDiscordBot.UsersUsingInGame.Remove(ctx.User.Id);  
            }
            discordID = 1;
            bytes = 0;
            task = CurrentTask.None;
            this.playerName = null;
            this.ctx = null;
        }

        public Casino(BotHelper botHelper) { 
            this.botHelper = botHelper;
        }

        public void TradePacketReceived(BSONObject bson)
        {
            if (task == CurrentTask.Depositing)
            {
                DepositingTrade(bson);
            }
            else if (task == CurrentTask.Withdrawing)
            {
                WithdrawingTrade(bson);
            }
        }

        public void NewPlayer(string name)
        {
            if (task == CurrentTask.None || playerName == null || task == CurrentTask.DecayDate || task == CurrentTask.Players)
            {
                return;
            }

            if (name.ToUpper() == playerName.ToUpper())
            {
                string message = task == CurrentTask.Depositing ? "Trade me and add the amount of bytes you would like to deposit then accept first!" : "Trade me first and accept when you see the bytes appear!";
                botHelper.Bot.OutgoingMessages.SendMessage(message);
                interpolation -= 60f;
            }
        }

        public void JoinedRoom() 
        {
            if (task == CurrentTask.None) return;

            if (ctx == null) return;

            var embed = new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Blue,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = (task == CurrentTask.Depositing) ? "Deposit" : "Withdraw",
                Description = $"Join world **{botHelper.Bot.world.WorldName.ToUpper()}** you have 1 minute before bot leaves! Make sure to trade **{botHelper.Bot.Player.myPlayerData.Username}**!",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };

            if (task == CurrentTask.DecayDate)
            {
                embed.Title = $"{botHelper.Bot.world.WorldName} data";
                embed.Description = "";
                World world = botHelper.Bot.world;
                BSONObject worldLock = new BSONObject() { ["ID"] = "NWL" };

                for (int i = 0; i < world.worldSize.y; i++)
                {
                    for (int j = 0; j < world.worldSize.x; j++)
                    {
                        var block = world.GetBlockType(i, j);
                        if (ConfigData.IsWorldLock(block))
                        {
                            worldLock = world.worldsItemBson[i][j];
                            break;
                        }
                    }
                }
                if (!worldLock.ContainsKey("class"))
                {
                    embed.Color = DiscordColor.Red;
                    embed.AddField("NO WORLD LOCK", "There is no world lock in that world");

                }
                else
                {
                    embed.Color = DiscordColor.Purple;
                    embed.AddField("Owner", worldLock["playerWhoOwnsLockName"].stringValue);
                    embed.AddField("Decay Date", worldLock["lastActivatedTime"].dateTimeValue.AddYears(1).ToString("d MMMM yyyy 'at' HH':'mm"));
                    
                }

                
                this.botHelper.Bot.Player.LeaveWorld();
                DiscordFollowupMessageBuilder bb = new DiscordFollowupMessageBuilder()
                {
                    IsEphemeral = true,
                };

                bb.AddEmbed(embed.Build());

                var wbb = new DiscordWebhookBuilder()
                {

                };
                wbb.AddEmbed(embed.Build());
                ctx.Interaction.EditOriginalResponseAsync(wbb);
                Reset();
                return;
            }
            else if (task == CurrentTask.Players)
            {
                embed.Title = "Players in " + botHelper.Bot.world.WorldName + $" ({botHelper.Bot.NetworkPlayers.otherPlayers.Count}/51)";
                int count = 0;
                foreach (var player in botHelper.Bot.NetworkPlayers.otherPlayers)
                {
                    if (count >= 24) break;
                    embed.AddField(player.Username, $"```User id: {player.UserID}\nGems: {player.gems}```", true);
                    count++;
                }
                embed.WithDescription("");
                if (botHelper.Bot.NetworkPlayers.otherPlayers.Count > 24)
                    embed.WithDescription("This only shows 24 players for now, I'll make it show more later!");

                if (botHelper.Bot.NetworkPlayers.otherPlayers.Count <= 0)
                {
                    embed.WithDescription("**No players are in the world**");
                }

                

                this.botHelper.Bot.Player.LeaveWorld();

                var wbb = new DiscordWebhookBuilder()
                {

                };
                wbb.AddEmbed(embed.Build());
                ctx.Interaction.EditOriginalResponseAsync(wbb);
                Reset();
                return;
            }

            

            DiscordFollowupMessageBuilder b = new DiscordFollowupMessageBuilder()
            {
                IsEphemeral = true,
            };

            b.AddEmbed(embed.Build());

            var wb = new DiscordWebhookBuilder()
            {

            };
            wb.AddEmbed(embed.Build());
            ctx.Interaction.EditOriginalResponseAsync(wb);
        }

        public void MenuWorldLimitInfo(int currentT, string world)
        {
            if (currentT > 24)
            {
                DiscordWebhookBuilder wb = new DiscordWebhookBuilder() { };
                var emb = CasinoDiscordBot.GetDefaultEmbed(ctx);
                emb.WithColor(DiscordColor.Red);
                emb.Title = world + $" ({currentT}/{51})";
                emb.WithDescription("That world has over 24 people which is the limit.\n**Only showing first 24 players**");
                wb.AddEmbed(emb);
                ctx.Interaction.EditOriginalResponseAsync(wb);
            }

            botHelper.Bot.Player.WarpFromWorldToWorld(world);
        }


        void WithdrawingTrade(BSONObject bson)
        {
            if (bson.ContainsKey("TP"))
                if (!botHelper.Bot.NetworkPlayers.SamePlayerAsID(playerName, bson["TP"].stringValue)) return;
            string TradeCommand = bson["TradeCommand"].stringValue;

            switch (TradeCommand)
            {
                case "ATr":

                    SendPacket(new()
                    {
                        ["ID"] = "Trade",
                        ["TradeCommand"] = "AtR",
                        ["TP"] = bson["TP"].stringValue
                    });
                    BSONArray arr = new BSONArray
                    {
                        0,
                        0,
                        0,
                        0
                    };

                    SendPacket(new()
                    {
                        ["ID"] = "Trade",
                        ["TradeCommand"] = "UT",
                        ["MTBC"] = bytes,
                        ["MTy"] = arr,
                        ["Amt"] = arr,
                        ["iWT"] = false,
                        ["woID"] = false
                    });
                    break;

                case "TSU":
                    bool partnerReady1 = bson["partnerStatus"].int32Value == 1;

                    if (partnerReady1)
                    {
                        SendPacket(new()
                        {
                            ["ID"] = "Trade",
                            ["TradeCommand"] = "LTi"
                        });
                    }

                    break;

                case "TFi":
                    SendPacket(new()
                    {
                        ["ID"] = "Trade",
                        ["TradeCommand"] = "CommitTrade"
                    });

                   
                    break;


                case "CompletedTrade":
                    botHelper.Bot.OutgoingMessages.SendMessage($"Thanks for using the casino bot! You have withdrawn {bytes} bytes!");
                    botHelper.Bot.Player.LeaveWorld();

                    Console.WriteLine(discordID + " " + -bytes);
                    CasinoDiscordBot.AddBytes(ctx.User.Id, -bytes);
                    CasinoDiscordBot.UpdateStats(ctx.User, bytes, false, true);
                    botHelper.Bot.Player.myPlayerData.AddBytes(-bytes);
                    if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
                    {

                        CasinoDiscordBot.UsersUsingInGame.Remove(ctx.User.Id);
                    }
                    ctx.Channel.SendMessageAsync(new DiscordEmbedBuilder()
                    {
                        Color = DiscordColor.Blue,
                        Author = new()
                        {
                            IconUrl = ctx.User.AvatarUrl,
                            Name = ctx.User.Username + "#" + ctx.User.Discriminator
                        },
                        Description = $"**{ctx.User.Username}** has withdrawn **{bytes} bytes**!\nYour current balance is **{CasinoDiscordBot.GetBalance(discordID)} bytes**!",
                        Footer = new()
                        {
                            IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                            Text = "made by penjamin#0236"
                        },
                        Timestamp = DateTime.Now
                    }.Build());
                    WebhookLogs.SendWithdrawLog(ctx.User, false, bytes);

                    Reset();
                    break;  



            }
        }

        float interpolation = 0.0f;
        public void Update()
        {
            if (this.task == CurrentTask.None) return;
            if (botHelper.Bot.status != Constants.PlayerConnectionStatus.InRoom || task == CurrentTask.Players || task == CurrentTask.DecayDate)
            {
                return;
            }

            interpolation += Time.deltaTime;
            if (interpolation >= 60f)
            {
                interpolation = 0.0f;
                botHelper.Bot.Player.LeaveWorld();
                ctx.Channel.SendMessageAsync(new DiscordEmbedBuilder()
                {
                    Color = DiscordColor.Red,
                    Author = new()
                    {
                        IconUrl = ctx.User.AvatarUrl,
                        Name = ctx.User.Username + "#" + ctx.User.Discriminator
                    },
                    Description = $"**{ctx.User.Username}** didnt join the world in time...",
                    Footer = new()
                    {
                        IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                        Text = "made by penjamin#0236"
                    },
                    Timestamp = DateTime.Now
                }.Build());
                Reset();
            }
        }
       
        void DepositingTrade(BSONObject bson) 
        {
            if (bson.ContainsKey("TP"))
                if (!botHelper.Bot.NetworkPlayers.SamePlayerAsID(playerName, bson["TP"].stringValue)) return;
            string TradeCommand = bson["TradeCommand"].stringValue;

            switch (TradeCommand)
            {
                case "ATr":

                    SendPacket(new()
                    {
                        ["ID"] = "Trade",
                        ["TradeCommand"] = "AtR",
                        ["TP"] = bson["TP"].stringValue
                    });
                    break;


                case "TSU":
                    bool partnerReady1 = bson["partnerStatus"].int32Value == 1;
                    bytes = bson["partnerBc"].int32Value;
                    if (partnerReady1 && bytes < minimum)
                    {
                        botHelper.Bot.OutgoingMessages.SendMessage($"The minumum you can deposit is {minimum} bytes!");
                        break;
                    }
                    else if (partnerReady1 && bytes > minimum)
                    {
                        SendPacket(new()
                        {
                            ["ID"] = "Trade",
                            ["TradeCommand"] = "LTi"
                        });
                    }

                    break;

                case "TFi":
                    SendPacket(new()
                    {
                        ["ID"] = "Trade",
                        ["TradeCommand"] = "CommitTrade"
                    });

                    break;

                case "CompletedTrade":
                    botHelper.Bot.OutgoingMessages.SendMessage($"Thanks for using the casino bot! You deposited {bson["partnerBc"].int32Value} bytes!");
                    botHelper.Bot.Player.LeaveWorld();


                    Console.WriteLine(discordID + " " + bson["partnerBc"].int32Value);
                    CasinoDiscordBot.AddBytes(ctx.User.Id, bson["partnerBc"].int32Value);
                    CasinoDiscordBot.UpdateStats(ctx.User, bson["partnerBc"].int32Value, true, false);
                    botHelper.Bot.Player.myPlayerData.AddBytes(bson["partnerBc"].int32Value);

                    if (CasinoDiscordBot.depositing.Contains(ctx.User.Id))
                    {

                        CasinoDiscordBot.depositing.Remove(ctx.User.Id);
                    }

                    ctx.Channel.SendMessageAsync(new DiscordEmbedBuilder()
                    {
                        Color = DiscordColor.Blue,
                        Author = new()
                        {
                            IconUrl = ctx.User.AvatarUrl,
                            Name = ctx.User.Username + "#" + ctx.User.Discriminator
                        },
                        Description = $"**{ctx.User.Username}** has deposited **{bson["partnerBc"].int32Value} <:bc:1101251335023775814>**\nYour current balance is **{CasinoDiscordBot.GetBalance(discordID)} <:bc:1101251335023775814>**",
                        Footer = new()
                        {
                            IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                            Text = "made by penjamin#0236"
                        },
                        Timestamp = DateTime.Now
                    }.Build());

                    WebhookLogs.SendWithdrawLog(ctx.User, true, bson["partnerBc"].int32Value);
                    Reset();
                    break;
            }
        }

        void SendPacket(BSONObject bson)
        {
            botHelper.Bot.OutgoingMessages.AddOneMessageToList(bson);
        }

        public void ModDetected()
        {
            if (task == CurrentTask.None || task == CurrentTask.DecayDate || task == CurrentTask.Players)
            {
                return;
            }
            

            ctx.Channel.SendMessageAsync(new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Red,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = "MOD DETECTED",
                Description = "If you're the mod go away!",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            }.Build());


            Reset();
            
        }

        public enum CurrentTask
        {
            None,
            Depositing,
            Withdrawing,
            DecayDate,
            Players
        }
    }
}
