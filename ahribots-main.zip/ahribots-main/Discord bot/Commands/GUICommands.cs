﻿using DSharpPlus;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands
{
    internal class GUICommands : ApplicationCommandModule
    {
        [SlashCommand("ShowGUI", "Show the gui back on ur pc screen if it's gone")]
        public async Task ShowGUI(InteractionContext ctx)
        {
            Program.StartGui();
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
            {
                IsEphemeral = true,
                Content = "GUI should begin to show :drooling_face:",
            });
        }

        [SlashCommand("HideGUI", "Hide the gui so it doesnt cause unnecessary cpu usage")]
        public async Task HideGUI(InteractionContext ctx)
        {
            Program.StopGUI();
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
            {
                IsEphemeral = true,
                Content = "Getting rid of that goofy gui for you! :drooling_face:",
            });
        }
    }
}
