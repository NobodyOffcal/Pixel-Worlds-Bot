﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DSharpPlus;
using DSharpPlus.EventArgs;
using DSharpPlus.CommandsNext;
using DSharpPlus.Net;
using DSharpPlus.Interactivity;
using DSharpPlus.Entities;
using Newtonsoft.Json;
using DSharpPlus.SlashCommands;
using ArhiBots.Bots;
using ArhiBots.GUI;
using ArhiBots.Misc;
using ArhiBots.Structs;

namespace ArhiBots.Discord_bot.Commands
{
    public class BotCommands : ApplicationCommandModule
    {
        string iconUrl = "https://images-ext-1.discordapp.net/external/3MYDXr6RzJrAby5O7RN5PZC0PV5YaGoJhCMxgqDyYG8/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/959197199860903956/d707532028b95e8f78239daebe3dc2bd.png?width=320&height=320";
        string abImage = "https://media.discordapp.net/attachments/1074756916011618324/1081686624666132530/logo.png?width=929&height=671";
        [SlashCommand("Reset", "Restart a bot via it's index")]
        public async Task Reset(InteractionContext ctx, [Option("Index", "Index of the bot")]
            [Choice("Bot 1", 0)][Choice("Bot 2", 1)][Choice("Bot 3", 2)]
            [Choice("Bot 4", 3)][Choice("Bot 5", 4)][Choice("Bot 6", 5)] long indexx = -1)
        {
            try
            {
                int index = (int)indexx;
                if (index == -1) {
                    for (int i = 0; i < BotManager.bots.Count; i++)
                    {
                        Bot.Create(BotManager.bots[0].ident.CognitoID, BotManager.bots[0].ident.Token, BotManager.bots[0].worldOnLoad);
                        BotManager.bots.RemoveAt(0);
                    }
                }
                else
                {

                    Bot.Create(BotManager.bots[index].ident.CognitoID, BotManager.bots[index].ident.Token, "Swagbag69");
                    BotManager.RemoveBot(index);
                }
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = "Bot(s) was restarted!",
                });
            }
            catch
            {
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = "An error occured!",
                });
            }
        }

        [SlashCommand("Inventory", "get the inventory of a bot at a specific index")]
        public async Task inventory(InteractionContext ctx, [Option("index", "index of the bot")]
            [Choice("Bot 1", 0)][Choice("Bot 2", 1)][Choice("Bot 3", 2)]
            [Choice("Bot 4", 3)][Choice("Bot 5", 4)][Choice("Bot 6", 5)]long index)
        {
            if (index < 0 || index > 6)
            {
                await ctx.CreateResponseAsync("invalid index", true);
                return;
            }

            try
            {
                DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
                {
                    Footer = new()
                    {
                        IconUrl = iconUrl,
                        Text = "made by krak",
                    },
                    Thumbnail = new()
                    {
                        Url = abImage
                    },
                    Color = DiscordColor.Chartreuse,
                    Title = "Arhi bots",

                };

                string description = "";

                Bot bot = BotManager.bots[(int)index];

                var inv = bot.Player.myPlayerData.GetInventoryAsOrderedByInventoryItemType();


                foreach(var item in inv) {
                    description += $"{bot.Player.myPlayerData.GetCount(item)}x {ConfigData.InventoryKeyText(item)}\n";
                }

                embed.Description = description;

                await ctx.CreateResponseAsync(embed.Build());
            }
            catch (Exception ex)
            {
                await ctx.CreateResponseAsync(ex.Message, true);
            }
        }


        [SlashCommand("MineLevel", "Toggle wether a bot should do that minelevel")]
        public async Task MineLevel(InteractionContext ctx, [Option("level", "mine level")][Choice("Level 1", 1)]
        [Choice("Level 2", 2)]
        [Choice("Level 3", 3)]
        [Choice("Level 4", 4)]
        [Choice("Level 5", 5)]long level)
        {
            try
            {

                bool[] mineLevels = new bool[5] { Globals.MineLevel1, Globals.MineLevel2, Globals.MineLevel3, Globals.MineLevel4, Globals.MineLevel5 };
                mineLevels[level - 1] = !mineLevels[level - 1];
                Globals.MineLevel1 = mineLevels[0];
                Globals.MineLevel2 = mineLevels[1];
                Globals.MineLevel3 = mineLevels[2];
                Globals.MineLevel4 = mineLevels[3];
                Globals.MineLevel5 = mineLevels[4];
                Config.SaveSettings();
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = $"Mine Level {level}: {mineLevels[level - 1]}",
                });
            }
            catch
            {
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = "An error occured!",
                });
            }

        }

        [SlashCommand("autodrop", "self explanitory")]
        public async Task AutoDrop(InteractionContext ctx, [Option("index", "description")]
            [Choice("Bot 1", 0)][Choice("Bot 2", 1)][Choice("Bot 3", 2)]
            [Choice("Bot 4", 3)][Choice("Bot 5", 4)][Choice("Bot 6", 5)]long index = -1)
        {
            if (index == -1)
            {
                await ctx.CreateResponseAsync("All bots are beginning to drop", true);
                foreach (var bot in BotManager.bots)
                {
                    bot.auto.autoDrop.StartDropping();
                }
                return;
            }

            if (index > 6 || index < 0)
            {
                await ctx.CreateResponseAsync("Invalid index", true);
                return;
            }

            await ctx.CreateResponseAsync("Dropping on bot account " + index, true);
            BotManager.bots[(int)index].auto.autoDrop.StartDropping();
        }

        [SlashCommand("remove", "remove a bot")]
        public async Task remove(InteractionContext ctx, [Option("index", "bot you want to remove")]
            [Choice("Bot 1", 0)][Choice("Bot 2", 1)][Choice("Bot 3", 2)]
            [Choice("Bot 4", 3)][Choice("Bot 5", 4)][Choice("Bot 6", 5)]long index = -1)
        {
            if (index == -1)
            {
                foreach (var bot in BotManager.bots)
                {
                    BotManager.RemoveBot(bot);
                }
            }
            else
            {
                try
                {
                    BotManager.RemoveBot((int)index);
                }
                catch (Exception ex) { }
            }
        }

        [SlashCommand("warp", "warp to world")]
        public async Task Warp(InteractionContext ctx, 
            [Option("index", "index of bot")]
            [Choice("Bot 1", 0)][Choice("Bot 2", 1)][Choice("Bot 3", 2)]
            [Choice("Bot 4", 3)][Choice("Bot 5", 4)][Choice("Bot 6", 5)]long index = -1, 
            [Option("world", "world of bot")]string world = "swagbag69")
        {
            if (index == -1)
            {
                await ctx.CreateResponseAsync("All bots are joining " + world);
                foreach (var bot in BotManager.bots)
                {
                    bot.Player.WarpFromWorldToWorld(world);
                }
            }
            else
            {
                try
                {
                    BotManager.bots[(int)index].Player.WarpFromWorldToWorld(world);
                }
                catch { }
            }
            
        }

        [SlashCommand("Bots", "Get the bots")]
        public async Task Bots(InteractionContext ctx)
        {



            DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
            {
                Footer = new()
                {
                    IconUrl = iconUrl,
                    Text = "made by krak",
                },
                Thumbnail = new()
                {
                    Url = abImage
                },
                Color = DiscordColor.Chartreuse,
                Title = "Arhi bots",

            };

            int totalMgems = 0;

            foreach (var bot in BotManager.bots)
            {

                string info = $"Ping: {bot.NetworkClient.ping}\n" +
                    $"Status: {bot.status}\n";


                string miningInfo = "";
                if (bot.auto != null)
                {
                    if (bot.auto.autoMine.Automine)
                    {
                        miningInfo += "--- mining info ---\n";
                        miningInfo += $"Current mine level ({bot.Player.currentMineLevel})\n";
                        miningInfo += $"{bot.auto.autoMine.autoMinePath.Count} blocks left\n";
                        miningInfo += $"completion time: {MathF.Round(bot.auto.autoMine.estimatedCompletionTime, 2)}\n";
                    }
                }

                totalMgems += bot.mgemCount;
                info += miningInfo;

                embed.AddField(bot.Prefix,
                    info,
                    true);
            }

            embed.Description = $"Bots connected ({BotManager.bots.Count})\nTotal mgems: {totalMgems}";

            await ctx.CreateResponseAsync(embed.Build());
        }


        [SlashCommand("AutoMineAll", "Starts auto mining on all of the bots connected")]
        public async Task Restart(InteractionContext ctx)
        {
            foreach (var bt in BotManager.bots)
            {
                bt.auto.autoMine.Automine = true;

                if (bt.world == null)
                {
                    bt.auto.autoMine.joinedMineStart = true;
                    continue;
                }
                if (bt.world.WorldName != "MINEWORLD")
                {
                    bt.auto.autoMine.joinedMineStart = true;
                    continue;
                }

                bt.auto.autoMine.joinedMineStart = false;
                await Task.Run(() => bt.auto.autoMine.AutoMineStart());
            }
            await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
            {
                IsEphemeral = true,
                Content = "All bots are begining to auto mine :drooling_face:",

            });
        }
        [SlashCommand("ConnectionStatus", "Get the connection status of all bots")]
        public async Task ConnectionStatus(InteractionContext ctx)
        {
            string description = "```";
            for (int i = 0; i < BotManager.bots.Count; i++)
            {
                Bot bot = BotManager.bots[i];

                description += $"{i} - {bot.NetworkClient.playerConnectionStatus} - {bot.Prefix}\n";
            }
            DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
            {
                Footer = new()
                {
                    IconUrl = iconUrl,
                    Text = "made by krak",
                },
                Thumbnail = new()
                {
                    Url = abImage
                },
                Color = DiscordColor.Chartreuse,
                Title = "Arhi bots connection status",
                Description = description + "```"

            };

            await ctx.CreateResponseAsync(embed.Build());
        }

        [SlashCommand("Stop", "Stop a bot from doing its current task")]
        public async Task Stop(InteractionContext ctx, [Option("botindex", "the index of the bot")] long index = -1)
        {
            DiscordColor color = DiscordColor.Green;
            string desription = $"Bot[{((index == -1) ? "ALL" : index)}] was stopped, it's currently not preforming any tasks";

            try
            {
                if (index == -1)
                {
                    for (int i = 0; i < BotManager.bots.Count; i++)
                    {
                        BotManager.bots[i].auto.Stop();
                    }
                }
                else
                BotManager.bots[(int)index].auto.Stop();
            }
            catch (Exception ex)
            {
                color = DiscordColor.Red;
                desription = $"There was an error stopping bots: {ex.Message}";
            }

            DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
            {
                Footer = new()
                {
                    IconUrl = iconUrl,
                    Text = "made by krak",
                },
                Thumbnail = new()
                {
                    Url = abImage
                },
                Color = color,
                Description = desription,
                Title = "Arhi Bots Command"
            };

            await ctx.CreateResponseAsync(embed.Build());
        }

        [SlashCommand("AddCog", "add a bot via it's cognito id and token")]
        public async Task AddCog(InteractionContext ctx,
            [Option("Cognito", "Add the cognito id of the bot, if you can't obtain this that sucks!")] string cognitoId,
            [Option("Token", "Add the token of the bot so you can login")] string token,
            [Option("world", "This will be the default load world of the bot")] string world)
        {
            Bot.Create(cognitoId, token, world);
            DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
            {
                Footer = new()
                {
                    IconUrl = iconUrl,
                    Text = "made by krak",
                },
                Thumbnail = new()
                {
                    Url = abImage
                },
                Color = DiscordColor.Green,
                Title = "Arhi bots adding bot",
                Description = "Bot should be added make sure to check the status of the bot to make sure it connects (/connectionStatus)"
            };
            await ctx.CreateResponseAsync(embed.Build());
        }

        [SlashCommand("import", "Import accounts from a file path")]
        public async Task Import(InteractionContext ctx,
            [Option("path", "File path of the bots you would like to import")] string path)
        {
            DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
            {
                Footer = new()
                {
                    IconUrl = iconUrl,
                    Text = "made by krak",
                },
                Thumbnail = new()
                {
                    Url = abImage
                },
                Color = DiscordColor.Green,
                Title = "Arhi bots adding bot",
                Description = $"Accounts are currently being imported from path \"{path}\""
            };
            await ctx.CreateResponseAsync(embed.Build());
            SampleOverlay.path = path;
            SampleOverlay.LogInAll();
        }

        [SlashCommand("export", "export the current accounts to a file path")]
        public async Task Export(InteractionContext ctx, [Option("path", "File path")]string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                await ctx.CreateResponseAsync("**INVALID FILE PATH**", true);
                return;
            }

            try
            {
                List<Acc> accs = new List<Acc>();

                foreach (var bt in BotManager.bots)
                {
                    Acc acc = new Acc(bt.ident.CognitoID, bt.ident.Token, bt.worldOnLoad);
                    accs.Add(acc);
                }

                string json = JsonConvert.SerializeObject(accs);
                File.WriteAllText(path, json);
            }
            catch (Exception ex)
            {
                await ctx.CreateResponseAsync(ex.Message, true);
            }

        }

        [SlashCommand("uptime", "Check how long the bot has been running for")]
        public async Task Uptime(InteractionContext ctx)
        {

            string description = $"{Program.UPTIME.Elapsed.ToString()}";

            DiscordEmbedBuilder embed = new DiscordEmbedBuilder()
            {
                Footer = new DiscordEmbedBuilder.EmbedFooter()
                {
                    Text = "Made by krak",
                    IconUrl = iconUrl
                },
                Title = "Arhi bots",
               Description = description
            };
            
            await ctx.CreateResponseAsync(embed.Build());
        }

        [SlashCommand("add", "add a bot via username and password")]
        public async Task Add(InteractionContext ctx, [Option("username", "username of the account you want to add")] string username, [Option("password", "password of the bot")] string password, [Option("world", "world is defaulted to SWAGBAG69, you can change this!")]string world = "SWAGBAG69")
        {
            try
            {
                var info = AWSRequests.LoginWithUsernameAndPassword(username, password);

                if (info == null)
                {
                    await ctx.CreateResponseAsync("Incorrect password or username.", true);
                    return;
                }

                Bot.Create(info.identityId, info.logintoken, world);
                await ctx.CreateResponseAsync("Bot is getting added, use /bots to make sure ( -- errors happen :'( -- )");
            }
            catch (Exception e)
            {
                await ctx.CreateResponseAsync(e.Message, true);
            }
        }



        
    }

}