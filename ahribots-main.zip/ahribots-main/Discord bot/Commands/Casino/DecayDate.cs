﻿using ArhiBots.Bots;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class DecayDate : ApplicationCommandModule
    {
        [SlashCommand("DecayDate", "Get the decay date of any world!")]
        public async Task GetDecayDate(InteractionContext ctx, [Option("name", "Name of the world that you want to get the date of!")] string name)
        {
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("You can't check when worlds are decaying while withdrawing!");
                return;
            }
            int bal = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bal < 5000)
            {
                await ctx.CreateResponseAsync("You need **5k <:bc:1101251335023775814>** to use this command");
                return;
            }

            Bot bot = BotManager.FindAvaliableCasinoBot();
            if (bot == null)
            {
                await ctx.CreateResponseAsync(new DiscordEmbedBuilder()
                {
                    Color = DiscordColor.Red,
                    Author = new()
                    {
                        IconUrl = ctx.User.AvatarUrl,
                        Name = ctx.User.Username + "#" + ctx.User.Discriminator
                    },
                    Title = "No bot is avaliable now to check the world, try again in a few minutes!",
                    Footer = new()
                    {
                        IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                        Text = "made by penjamin#0236"
                    },
                    Timestamp = DateTime.Now
                }.Build(), true);
                return;
            }

            var embed = new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Green,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = "Loading world data this might take a few seconds!",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };
            name = name.ToUpper();
            if (name == "MINEWORLD" || name == "JETRACE" || name == "SECRETBASE" || name == "THEBLACKTOWER" || name == "DEEPNETHER" || name == "NETHERWORLD")
            {
                embed.Title = "Your not allowed to check dynamic worlds!";
                embed.Color = DiscordColor.Red;
                await ctx.CreateResponseAsync(embed.Build(), true);
                return;
            }

            CasinoDiscordBot.AddBytes(ctx.User.Id, -5000);
            bot.botHelper.Casino.CheckDecayDate(name, ctx);
            await ctx.CreateResponseAsync(embed.Build(), true);

        }
    }
}
