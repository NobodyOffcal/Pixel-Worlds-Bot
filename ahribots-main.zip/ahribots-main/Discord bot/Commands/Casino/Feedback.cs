﻿using ArhiBots.Bots;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Feedback : ApplicationCommandModule
    {
        [SlashCommand("bug", "There are bug bounties for bytes!")]
        public async Task ReportBug(InteractionContext ctx, [Option("Bug", "describe the bug")] string bug, [Option("Additional_info", "Give some additional info on the bug")] string moreinfo = "")
        {
            try
            {
                await WebhookLogs.SendBugMessage(ctx.User, bug, moreinfo);
                await ctx.CreateResponseAsync("Thanks for reporting the bug you found!", true).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.ToString());
                await ctx.CreateResponseAsync("Failed to report bug, try again later!", true).ConfigureAwait(false);
            }
        }


    }
}
