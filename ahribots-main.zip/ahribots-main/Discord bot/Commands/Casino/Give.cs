﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Give : ApplicationCommandModule
    {
        [SlashCommand("give", "Give bytes to a user")]
        public async Task give(InteractionContext ctx, [Option("User", "User you want to give your bytes to!")] DiscordUser user, [Option("bytes", "Amount of bytes you would like to give the user")] long bytes)
        {
            if (CasinoDiscordBot.admin.Contains(ctx.User.Id))
            {
                CasinoDiscordBot.AddBytes(user.Id, (int)bytes);

                await ctx.CreateResponseAsync($":+1:", true);
                await ctx.Channel.SendMessageAsync($"A developer has given {user.Mention} {bytes} <:bc:1101251335023775814>");
                return;
            }
            if (bytes < 10000)
            {
                await ctx.CreateResponseAsync("You can't give someone **less than 10000 <:bc:1101251335023775814>**", true);
                return;
            }
            else if (bytes > int.MaxValue)
            {
                await ctx.CreateResponseAsync("Are you crazy!? That's way too many bytes!", true);
                return;
            }
            int bal = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bytes > bal)
            {
                await ctx.CreateResponseAsync($"You don't have enough bytes, you only have {bal} <:bc:1101251335023775814>");
                return;
            }


            CasinoDiscordBot.AddBytes(ctx.User.Id, (int)-bytes);
            CasinoDiscordBot.AddBytes(user.Id, (int)bytes);
            await ctx.CreateResponseAsync($"{user.Mention}, {ctx.User.Mention} has given you {bytes} bytes!", false);
        }

    }
}
