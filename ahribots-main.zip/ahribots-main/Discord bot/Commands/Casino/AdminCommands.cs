﻿using ArhiBots.Bots;
using DSharpPlus;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using DSharpPlus.SlashCommands.Attributes;
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class AdminCommands : ApplicationCommandModule
    {
        [SlashCommand("bots", "Bots online")]
        [SlashRequireDirectMessage]
        public async Task Bots(InteractionContext ctx)
        {
            if (!CasinoDiscordBot.admin.Contains(ctx.User.Id))
            {

                await ctx.CreateResponseAsync("Locked cmd", true);
                return;
            }
            var embed = new DiscordEmbedBuilder();
            embed.WithTitle("bots");
            uint bc = 0;
            foreach (var bot in BotManager.bots)
            {
                bc += (uint)bot.Player.myPlayerData.bc;
                embed.AddField(bot.Prefix, $"```Status: {bot.status}\nBytes: {bot.Player.myPlayerData.bc}```", true);
            }
            embed.WithDescription($"**total bc ({bc})**");

            await ctx.CreateResponseAsync(embed.Build(), true);
        }

        [SlashCommand("SetOdds", "Change the house odds")]
        [SlashRequireDirectMessage]
        public async Task ChangeOdds(InteractionContext ctx, [Option("odds", "odds")] long test)
        {
            if (!CasinoDiscordBot.admin.Contains(ctx.User.Id))
            {

                await ctx.CreateResponseAsync("Locked cmd", true);
                return;
            }
            CasinoDiscordBot.HouseOdds = (int)test;
            await ctx.CreateResponseAsync("House odds set to " + test, true);
        }

        [SlashCommand("GetServers", "Change the house odds")]
        [SlashRequireDirectMessage]
        public async Task GetServers(InteractionContext ctx)
        {
            var guilds = CasinoDiscordBot.Client.Guilds;
            string description = "";
            foreach (var guild in guilds.Values)
            {
                // Get the number of members in the guild
                var memberCount = await guild.GetAllMembersAsync().ConfigureAwait(false);

                // Get the invite link for the guild
                var invites = await guild.GetInvitesAsync().ConfigureAwait(false);
                var inviteLink = invites.FirstOrDefault()?.Code ?? "No invite link available";

                description += $"Guild: {guild.Name} ({guild.Id}) - Members: {memberCount.Count} - Invite Link: {inviteLink}\n";
            }

            var embed = CasinoDiscordBot.GetDefaultEmbed(ctx);
            embed.Title = "Servers:";
            embed.Description = description;
            embed.WithColor(DiscordColor.Green);
            await ctx.CreateResponseAsync(embed, false);
        }

        [SlashCommand("drac", "The next chest the user opens they'll get drac")]
        [SlashRequireDirectMessage]
        public async Task Dracula(InteractionContext ctx, [Option("user", "The user you want to win drac :drool:")]string user)
        {
            if (!CasinoDiscordBot.admin.Contains(ctx.User.Id))
            {

                await ctx.CreateResponseAsync("Locked cmd", true);
                return;
            }
            try
            {

                Chest.DracWinner = ulong.Parse(user);
                Chest.WinDrac = true;
                await ctx.CreateResponseAsync($"{user} will win drac on their next spin!", true);
            }
           catch (Exception ex)
            {
                await ctx.CreateResponseAsync($"{ex.Message}", true);
            }
        }
        [SlashCommand("Backup", "Create a backup of the database (in case something happens)")]
        [SlashRequireDirectMessage]
        public async Task Backup(InteractionContext ctx)
        {
            if (!CasinoDiscordBot.admin.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("Locked cmd", true);
                return;
            }
            try
            {

                string file = "../Casino/Players.json";
                using (var fileStream = new FileStream(file, FileMode.Open))
                {
                    DiscordInteractionResponseBuilder responseBuilder = new DiscordInteractionResponseBuilder();
                    responseBuilder.AddFile(fileStream);
                    responseBuilder.AsEphemeral(false);
                    responseBuilder.WithContent($"Backup created: {DateTime.Now}");
                    await ctx.CreateResponseAsync(responseBuilder);
                }

            }
            catch (Exception e)
            {
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = e.ToString(),
                });
            }
        }


        [SlashCommand("Reset", "Restart a bot via it's index")]
        [SlashRequireDirectMessage]
        public async Task Reset(InteractionContext ctx, [Option("Index", "Index of the bot")]
            [Choice("Bot 1", 0)][Choice("Bot 2", 1)][Choice("Bot 3", 2)]
            [Choice("Bot 4", 3)][Choice("Bot 5", 4)][Choice("Bot 6", 5)] long indexx = -1)
        {
            if (!CasinoDiscordBot.admin.Contains(ctx.User.Id))
            {

                await ctx.CreateResponseAsync("Locked cmd", true);
                return;
            }
            try
            {
                int index = (int)indexx;
                if (index == -1)
                {
                    for (int i = 0; i < BotManager.bots.Count; i++)
                    {
                        Bot.Create(BotManager.bots[0].ident.CognitoID, BotManager.bots[0].ident.Token, BotManager.bots[0].worldOnLoad);
                        BotManager.bots.RemoveAt(0);
                    }
                }
                else
                {

                    Bot.Create(BotManager.bots[index].ident.CognitoID, BotManager.bots[index].ident.Token, "Swagbag69");
                    BotManager.RemoveBot(index);
                }
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = "Bot(s) was restarted!",
                });
            }
            catch
            {
                await ctx.CreateResponseAsync(InteractionResponseType.ChannelMessageWithSource, new DiscordInteractionResponseBuilder
                {
                    IsEphemeral = true,
                    Content = "An error occured!",
                });
            }
        }



    
    
    }
}
