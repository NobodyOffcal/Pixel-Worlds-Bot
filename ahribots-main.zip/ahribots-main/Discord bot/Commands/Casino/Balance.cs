﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Balance : ApplicationCommandModule
    {
        [SlashCommand("balance", "Get your balance or the balance of another user")]
        public async Task BalanceCheck(InteractionContext ctx, [Option("user", "Get the amount of bytes another user has!")] DiscordUser user = null)
        {
            if (user == null)
            {
                int ball = CasinoDiscordBot.GetBalance(ctx.User.Id);
                string descc = $"**You** have **{ball} <:bc:1101251335023775814>**";
                await ctx.CreateResponseAsync(new DiscordEmbedBuilder()
                {
                    Color = new DiscordColor(new Random().Next(0, 1000000)),
                    Author = new()
                    {
                        IconUrl = ctx.User.AvatarUrl,
                        Name = ctx.User.Username + "#" + ctx.User.Discriminator
                    },
                    Title = "Balance",
                    Description = descc,
                    Footer = new()
                    {
                        IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                        Text = "made by penjamin#0236"
                    },
                    Timestamp = DateTime.Now
                }.Build());
                return;
            }

            int bal = CasinoDiscordBot.GetBalance(user.Id);
            string desc = $"**{user.Username}** has **{bal}<:bc:1101251335023775814>**";
            var embed = new DiscordEmbedBuilder()
            {
                Color = new DiscordColor(new Random().Next(0, 1000000)),
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = "Balance",
                Description = desc,
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now

            }.Build();
            await ctx.CreateResponseAsync(embed, false);


        }

    }
}
