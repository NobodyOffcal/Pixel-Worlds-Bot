﻿using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class RockPaperSciccors : ApplicationCommandModule
    {
        /*[SlashCommand("RockPaperSciccors", "play rock paper sciccors against a user!")]
        /*[SlashCommand("RockPaperSciccors", "play rock paper sciccors against a user!")]
        public async Task RockPaperSciccors(InteractionContext ctx, [Option("User", "Person you would like to play against")]DiscordUser user, [Option("bytes", "Amount of bytes")]long bytes)
        {
            int balance = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bytes < mimimumbet)
            {
                await ctx.CreateResponseAsync("The minimum you can bet is " + mimimumbet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > balance)
            {
                await ctx.CreateResponseAsync("You only have " + balance + " <:bc:1101251335023775814>");
                return;
            }
            int otherbal = CasinoDiscordBot.GetBalance(user.Id);
            if (otherbal < bytes)
            {
                await ctx.CreateResponseAsync($"{user.Username} only has " + otherbal + " <:bc:1101251335023775814>");
                return;
            }
            await ctx.CreateResponseAsync(":+1:", true);
            var embed = new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Blue,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Description = "**" + user.Username + ", " + ctx.User.Username + " has challenged you to rock, paper sciccors for " + bytes + " <:bc:1101251335023775814> **",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };
            var messageBuilder = new DiscordWebhookBuilder();
            messageBuilder.AddComponents(
                new DiscordButtonComponent(ButtonStyle.Success, "Accept", "Accept"),
                new DiscordButtonComponent(ButtonStyle.Danger, "Decline", "Decline")
                );
            messageBuilder.AddEmbed(embed.Build());
            messageBuilder.WithContent($"( {user.Mention} ) {ctx.User.Mention} )");
            
            
            var message = await ctx.Interaction.CreateFollowupMessageAsync(new DiscordFollowupMessageBuilder() { Content = $"( {user.Mention} ) {ctx.User.Mention} )" }).ConfigureAwait(false);
            
            var newMessage = await ctx.EditFollowupAsync(message.Id, messageBuilder).ConfigureAwait(false);
            var buttonResponse = await newMessage.WaitForButtonAsync(user);


            string buttonId = buttonResponse.Result.Id;
            Console.WriteLine(buttonId);
            if (buttonId == "Decline")
            {
                await ctx.Interaction.EditFollowupMessageAsync(message.Id, new DiscordWebhookBuilder()
                {
                    Content = $"{ctx.User.Mention}, {user.Username} has declined your request!"
                });
            }

            CasinoDiscordBot.AddBytes(ctx.User.Id, (int)-bytes);
            CasinoDiscordBot.UpdateStats(ctx.User, (int)bytes);
            CasinoDiscordBot.UpdateStats(user, (int)bytes);
            CasinoDiscordBot.AddBytes(user.Id, (int)-bytes);
            await ctx.Interaction.EditFollowupMessageAsync(message.Id, new DiscordWebhookBuilder()
            {
                Content = $"Challenge was accepted {ctx.User.Mention} & {user.Mention} check your dms!"
            });
            var userDMChannel = await ctx.Member.CreateDmChannelAsync();
            var ctxUserDMChannel = await ctx.Guild.GetMemberAsync(user.Id);

            userDMChannel.SendMessageAsync()

        }*/

    }
}
