﻿using ArhiBots.Bots;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Players : ApplicationCommandModule
    {
        [SlashCommand("players", "Check the players in a specific world")]
        public async Task GetPlayers(InteractionContext ctx, [Option("world", "The world you would like to check")]string world)
        {
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("You can't check when worlds are decaying while withdrawing!");
                return;
            }
            int bal = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bal < 2000)
            {
                await ctx.CreateResponseAsync("You need **2k <:bc:1101251335023775814>** to use this command");
                return;
            }

            Bot bot = BotManager.FindAvaliableCasinoBot();
            if (bot == null)
            {
                await ctx.CreateResponseAsync(new DiscordEmbedBuilder()
                {
                    Color = DiscordColor.Red,
                    Author = new()
                    {
                        IconUrl = ctx.User.AvatarUrl,
                        Name = ctx.User.Username + "#" + ctx.User.Discriminator
                    },
                    Title = "No bot is currently avaliable to check that world!",
                    Footer = new()
                    {
                        IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                        Text = "made by penjamin#0236"
                    },
                    Timestamp = DateTime.Now
                }.Build(), true);
                return;
            }
            var embed = CasinoDiscordBot.GetDefaultEmbed(ctx);

            world = world.ToUpper();
            if (world == "MINEWORLD" || world == "JETRACE" || world == "SECRETBASE" || world == "THEBLACKTOWER" || world == "DEEPNETHER" || world == "NETHERWORLD")
            {
                embed.Title = "Your not allowed to check dynamic worlds!";
                embed.Color = DiscordColor.Red;
                await ctx.CreateResponseAsync(embed.Build(), true);
                return;
            }

            
            embed.WithColor(DiscordColor.CornflowerBlue);
            embed.Title = "Checking world...";
            embed.WithDescription("Checking world this may take up to a minute!");
            await ctx.CreateResponseAsync(embed, true);
            CasinoDiscordBot.AddBytes(ctx.User.Id, -2000);
            bot.botHelper.Casino.BeginPlayersCheck(world, ctx);
        }

    }
}
