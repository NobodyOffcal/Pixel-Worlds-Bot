﻿using DSharpPlus.Entities;
using DSharpPlus.Interactivity.Extensions;
using DSharpPlus;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Tower : ApplicationCommandModule
    {
        [SlashCommand("Tower", "A game where the higher you climb the tower the higher the multiplier!")]
        public async Task PlayTower(InteractionContext ctx, [Option("bytes", "byte coins")] long bytes)
        {
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("You can't play games while withdrawing!");
                return;
            }
            if (bytes < CasinoDiscordBot.mimimumbet)
            {
                await ctx.CreateResponseAsync("**The mimimum you can gamble on this game is 2000 bytes!**", true);
                return;
            }
            if (bytes > CasinoDiscordBot.maximumBet)
            {
                await ctx.CreateResponseAsync("The maximum you can bet is " + CasinoDiscordBot.maximumBet + " <:bc:1101251335023775814>");
                return;
            }
            int bal = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bytes > bal)
            {
                await ctx.CreateResponseAsync($"**You only have {bal} bytes!**", true);
                return;
            }


            var selectComponent = new DiscordSelectComponent("Difficulty", "Select difficulty", new List<DiscordSelectComponentOption>
            {
                new DiscordSelectComponentOption("Easy", "Easy"),
                new DiscordSelectComponentOption("Medium", "Medium"),
                new DiscordSelectComponentOption("Hard", "Hard")
            });

            var embed = new DiscordEmbedBuilder()
            {
                Color = new DiscordColor(new Random().Next(0, 1000000)),
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = "Select a difficulty!",
                Description = "Choose a different difficulty for higher risk but higher rewards!",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now

            };
            var interaction = ctx.Interaction;

            var response = new DiscordInteractionResponseBuilder();
            response.AddEmbed(embed.Build());
            response.AsEphemeral(true);

            response.AddComponents(selectComponent);

            //await ctx.CreateResponseAsync(InteractionResponseType.DeferredChannelMessageWithSource, response);

            await ctx.CreateResponseAsync(response);

            var interactivity = ctx.Client.GetInteractivity();

            var result = await interactivity.WaitForSelectAsync(ctx.GetOriginalResponseAsync().Result, selectComponent.CustomId, TimeSpan.FromSeconds(30));

            if (result.TimedOut)
            {
                DiscordWebhookBuilder wbbe = new ();
                wbbe.AddEmbed(embed.Build());
                
                await ctx.Interaction.EditOriginalResponseAsync(wbbe);
                return;
            }


            var selectedValue = result.Result.Values.First();

            int difficulty = 4;
            int height = 0;
            if (selectedValue == "Hard") difficulty = 2;
            else if (selectedValue == "Medium") difficulty = 3;

            int seed = CasinoDiscordBot.GenerateRandomSeed();
            var random = new Random(seed);

            var originalResponseEdited = new DiscordWebhookBuilder();
            embed.WithDescription("Difficulty " + selectedValue + " was chosen!");
            originalResponseEdited.AddEmbed(embed.Build());

            await interaction.EditOriginalResponseAsync(originalResponseEdited);

            CasinoDiscordBot.UpdateStats(ctx.User, (int)bytes);
            CasinoDiscordBot.AddBytes(ctx.User.Id, (int)-bytes);

            string[] emojis = { ":black_large_square:", ":bomb:", ":green_square:" };

            TowerThings[,] board = new TowerThings[difficulty, 10];
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < difficulty; j++)
                {
                    board[j, i] = TowerThings.Square;
                }
            }

            var buttonComponents = new DiscordButtonComponent[difficulty];
            for (int i = 0; i < difficulty; i++)
            {
                buttonComponents[i] = new DiscordButtonComponent(ButtonStyle.Primary, i + 1 + "", (i + 1) + "");
            }

            var buttonComponentsNext = new DiscordButtonComponent[]
            {
                new DiscordButtonComponent(ButtonStyle.Primary, "more", "more"),
                new DiscordButtonComponent(ButtonStyle.Primary, "exit", "exit")
            };


            var wb = new DiscordFollowupMessageBuilder();

            wb.WithContent("Loading tower on difficulty " + selectedValue);

            var msg = await interaction.CreateFollowupMessageAsync(wb).ConfigureAwait(false);

        GameBegin:
            var wbb = new DiscordWebhookBuilder();
            wbb.Clear();
            var gameEmbed = new DiscordEmbedBuilder()
            {
                Title = $"Tower ({selectedValue})",
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Description = "",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
            };
            gameEmbed.Color = DiscordColor.Blue;
            gameEmbed.AddField("Height: " + (height), DrawBoard(board, difficulty));
            wbb.AddComponents(buttonComponents);
            wbb.AddEmbed(gameEmbed.Build());
            var newMessage = await ctx.EditFollowupAsync(msg.Id, wbb).ConfigureAwait(false);


            // Buttons
            var buttonResult = newMessage.WaitForButtonAsync(ctx.User);
            string buttonId = buttonResult.Result.Result.Id;
            Console.WriteLine("Swag");
            bool stillPlaying = MoveTower(ref board, ref height, int.Parse(buttonId) - 1, difficulty, ref random, (int)bytes);
            wbb.WithContent(":dollar: You went at position " + buttonId + " :dollar:");
            gameEmbed.ClearFields();
            
            gameEmbed.AddField("Height: " + (height), DrawBoard(board, difficulty));
            wbb.ClearComponents();
            wbb.Clear();
            wbb.AddEmbed(gameEmbed.Build());
            await ctx.EditFollowupAsync(newMessage.Id, wbb).ConfigureAwait(false);

            if (!stillPlaying)
            {
                wbb.Clear();
                gameEmbed.ClearFields();
                gameEmbed.Title = "You hit a :bomb:";
                gameEmbed.Description = $"You reached a max height of " + (height) + " and lost everything!";
                gameEmbed.Color = DiscordColor.Orange;
                wbb.AddEmbed(gameEmbed);
                await ctx.EditFollowupAsync(newMessage.Id, wbb).ConfigureAwait(false);
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, (int)bytes, false);
                return;
            }

            wbb.ClearComponents();
            interactivity = ctx.Client.GetInteractivity();
            await ctx.EditFollowupAsync(newMessage.Id, wbb).ConfigureAwait(false);
            wbb.AddComponents(buttonComponentsNext);
            await Task.Delay(100).ConfigureAwait(false);
            var newmsg = await ctx.EditFollowupAsync(newMessage.Id, wbb).ConfigureAwait(false);
            var buttonResult2 = newmsg.WaitForButtonAsync(ctx.User);
            buttonId = buttonResult2.Result.Result.Id;

            if (buttonId == "exit")
            {
                wbb.Clear();
                wbb.ClearComponents();
                int bc = (int)Math.Round(bytes * TowerMulti(height, difficulty));
                gameEmbed.Title = ":star: You won " + bc + " <:bc:1101251335023775814> :star:";
                gameEmbed.Description = $"You reached a height of " + (height) + " and won alot!";
                gameEmbed.Color = DiscordColor.Green;
                wbb.AddEmbed(gameEmbed);
                await ctx.EditFollowupAsync(newMessage.Id, wbb).ConfigureAwait(false);
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, bc, true);
                CasinoDiscordBot.AddBytes(ctx.User.Id, bc);
                return;
            }

            await Task.Delay(100).ConfigureAwait(false);
            goto GameBegin;
        }


        enum TowerThings
        {
            Square,
            Bomb,
            Safe,
        }

        bool MoveTower(ref TowerThings[,] board, ref int height, int position, int difficulty, ref Random random, int byteCoins)
        {
            int bomb = new Random(random.Next(int.MinValue, int.MaxValue)).Next(0, difficulty);

            bool houseOdds = false;
            if ((height > 2 && difficulty == 4) || (height > 1 && difficulty == 3) || difficulty == 2)
            {
                int num = new Random().Next(101);
                houseOdds = num > CasinoDiscordBot.HouseOdds;
            }

            Console.WriteLine(bomb + " is where bomb is.");

            float winnings = byteCoins * TowerMulti(height, difficulty);

            bool canPay = CasinoDiscordBot.CanPayOut(byteCoins) && CasinoDiscordBot.CanPayOut(byteCoins * 3);
            if (!canPay)
            {
                bomb = position;
            }
            if (houseOdds)
            {
                bomb = position;
            }

            if (position == bomb)
            {
                board[position, height] = TowerThings.Bomb;
                return false;
            }
            else
            {
                board[bomb, height] = TowerThings.Bomb;
                board[position, height] = TowerThings.Safe;
            }

            height++;
            return true;
        }

        string DrawBoard(TowerThings[,] board, int difficulty)
        {
            string[] emojis = { ":black_large_square:", ":bomb:", ":green_square:" };
            string desc = "";
            for (int height = 9; height >= 0; height--)
            {
                for (int j = 0; j < difficulty; j++)
                {
                    desc += $"{emojis[(int)board[j, height]]}";
                }
                desc += $" {TowerMulti(height + 1, difficulty)}x\n";
            }
            Console.WriteLine(desc);
            return desc;

        }

        float TowerMulti(int height, int difficulty)
        {
            switch (difficulty)
            {
                case 4: // easy
                    switch (height)
                    {
                        case 1:
                            return 1.21f;
                        case 2:
                            return 1.57f;
                        case 3:
                            return 1.97f;
                        case 4:
                            return 2.34f;
                        case 5:
                            return 3.05f;
                        case 6:
                            return 4.35f;
                        case 7:
                            return 6.19f;
                        case 8:
                            return 8.29f;
                        case 9:
                            return 11.49f;
                        case 10:
                            return 16.05f;
                    }
                    break;
                case 3: // medium
                    switch (height)
                    {
                        case 1:
                            return 1.44f;
                        case 2:
                            return 1.8f;
                        case 3:
                            return 2.6f;
                        case 4:
                            return 3.8f;
                        case 5:
                            return 6.4f;
                        case 6:
                            return 10.93f;
                        case 7:
                            return 15.5f;
                        case 8:
                            return 22.65f;
                        case 9:
                            return 33.21f;
                        case 10:
                            return 55.36f;
                    }
                    break;
                case 2: // hard
                    switch (height)
                    {
                        case 1:
                            return 1.7f;
                        case 2:
                            return 3.4f;
                        case 3:
                            return 7.34f;
                        case 4:
                            return 13.36f;
                        case 5:
                            return 27.72f;
                        case 6:
                            return 58.82f;
                        case 7:
                            return 100.02f;
                        case 8:
                            return 203.32f;
                        case 9:
                            return 491.52f;
                        case 10:
                            return 983.04f;
                    }
                    break;
            }
            return 1;
        }


    }
}
