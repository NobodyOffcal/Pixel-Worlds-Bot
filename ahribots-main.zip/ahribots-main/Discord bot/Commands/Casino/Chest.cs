﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Chest : ApplicationCommandModule
    {
        public static bool WinDrac = false;
        public static ulong DracWinner = 0;

        enum ChestType
        {
            None = 0,
            SoilChest = 1,

        }

        [SlashCommand("Chest", "Open chests")]
        public async Task OpenChest(InteractionContext ctx, [Option("Chest", "The type of chest you want to open")]
        [Choice("Soil_Chest", (long)ChestType.SoilChest)]long chestT = 0)
        {
        
            ChestType chest = (ChestType)chestT;
            var embed = new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Blue,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };
            if (chest == ChestType.None)
            {
                embed.Title = "Chests info!";
                embed.AddField("<:dert:1101782238158409748> SOIL CHEST", "Price: 100 <:bc:1101251335023775814>\n\n–––———————–––——\n**Prizes:**\n> 10 <:bc:1101251335023775814> (99.9999% Chance)\n> 1  <:drac:1101252045463363606> (0.00001% Chance)\n–––———————–––——");
                await ctx.CreateResponseAsync(embed);
                return;
            }

            int bal = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (chest == ChestType.SoilChest)
            {
                if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
                {
                    await ctx.CreateResponseAsync("You can't play games while withdrawing!");
                    return;
                }
                if (bal < 100)
                {
                    await ctx.CreateResponseAsync("You don't have enough bytes to open a **Soil Chest** it costs 100 <:bc:1101251335023775814>");
                    return;
                }
                CasinoDiscordBot.AddBytes(ctx.User.Id, -90);

                if (WinDrac && ctx.User.Id == DracWinner)
                {
                    WinDrac = false;
                    DracWinner = 0;
                    embed.Color = DiscordColor.Yellow;

                    embed.Title = $"<:drac:1101252045463363606> {ctx.User.Username}#{ctx.User.Discriminator} JUST WON A DRACULA CAPE <:drac:1101252045463363606>";
                    embed.WithDescription("DM @penjamin#0236 to claim!");

                    DiscordInteractionResponseBuilder discordMessageBuilder = new DiscordInteractionResponseBuilder();
                    discordMessageBuilder.AddEmbed(embed);
                    discordMessageBuilder.WithContent($"@everyone {ctx.User.Mention} has won a <:drac:1101252045463363606>");

                    await ctx.CreateResponseAsync(discordMessageBuilder);
                    return;
                }

                embed.Title = "You won 10 <:bc:1101251335023775814>";
                embed.Description = "You spent 100 bytes to open a soil chest and got 10 bytes";
                embed.WithThumbnail("https://media.discordapp.net/attachments/1101210686555684895/1101844494321713262/dert.png?width=662&height=662");
                await ctx.CreateResponseAsync(embed.Build());
                return;
            }
        }
    }
}
