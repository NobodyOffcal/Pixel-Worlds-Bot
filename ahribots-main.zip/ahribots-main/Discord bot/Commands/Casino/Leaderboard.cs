﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using Google.Protobuf.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Leaderboard : ApplicationCommandModule
    {

        [SlashCommand("leaderboard", "Check the leaderboard for a specific statistic!")]
        public async Task LeaderBoard(InteractionContext ctx, [Option("Stat", "The specific stat your wanting to check")]
    StatsEnum choice
)
        {
            List<User> users = CasinoDiscordBot.Users;
            StatsEnum stat = (StatsEnum)choice;

            // Retrieve the top 10 users for the specified statistic
            var leaderboard = users.OrderByDescending(u => u.GetStatValue(stat)).Take(20);

            // Create a string representing the leaderboard
            StringBuilder sb = new StringBuilder();
            int rank = 1;
            int amount = 10;
            
            foreach(var user in leaderboard)
            {
                if (rank > 10) break;
                if (user.DiscordId == 760084009404727297)
                {
                    continue;
                }
                sb.AppendLine($"{rank}. **{user.Stats.username} - {user.GetStatValue(stat)}**");
                rank++;
            }
            Console.WriteLine("DONE LOOP");

            DiscordEmbedBuilder embed = CasinoDiscordBot.GetDefaultEmbed(ctx);
            embed.WithColor(new DiscordColor(new Random().Next(0, 1000000)));
            embed.WithTitle($"**{GetStatsName(stat)} Leaderboard :classical_building:**");
            embed.WithDescription(sb.ToString());

            await ctx.CreateResponseAsync(embed.Build());
        }
        static string GetStatsName(StatsEnum stat)
        {
            switch (stat)
            {
                case StatsEnum.Balances:
                    return "Highest balances";
                case StatsEnum.HighestBet:
                    return "Highest Bet";
                case StatsEnum.HighestWin:
                    return "Highest Win";
                case StatsEnum.HighestLoss:
                    return "Highest Loss";
                case StatsEnum.BytesGambled:
                    return "Bytes Gambled";
                case StatsEnum.BytesLost:
                    return "Bytes Loss";
                case StatsEnum.MostWithdrawn:
                    return "Most withdrawn";
                case StatsEnum.Withdrawn:
                    return "Total withdrawn";
                case StatsEnum.MostDeposited:
                    return "Most deposited";
                case StatsEnum.Deposited:
                    return "Deposited";
                case StatsEnum.Wins:
                    return "Wins";
                case StatsEnum.Losses:
                    return "Losses";
                default:
                    throw new ArgumentOutOfRangeException(nameof(stat), stat, null);
            }
        }

        public enum StatsEnum
        {
            Balances,
            HighestBet,
            HighestWin,
            HighestLoss,
            BytesGambled,
            BytesLost,
            MostWithdrawn,
            Withdrawn,
            MostDeposited,
            Deposited,
            Wins,
            Losses
        }

        
    }
}
