﻿using ArhiBots.Bots;
using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Withdraw : ApplicationCommandModule
    {
        [SlashCommand("withdraw", "Withdraw byte coins")]
        public async Task StartWithdraw(InteractionContext ctx, [Option("username", "Your Pixel Worlds username.")] string username, [Option("bytes", "Amount of byte coins you would like to withdraw")] long bytes)
        {
            if (CasinoDiscordBot.depositing.Contains(ctx.User.Id)) {
                await ctx.CreateResponseAsync("You can't deposit and withdraw at the same time!");
                return;
            }
            int minWith = 5000;
            int balance = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bytes > balance)
            {
                await ctx.CreateResponseAsync("You only have " + balance + " bytes!");
                return;
            }

            if (bytes < minWith)
            {
                await ctx.CreateResponseAsync("The mimimum you can withdraw is " + minWith + " bytes!", true);
                return;
            }
            if (bytes > 1000000)
            {
                await ctx.CreateResponseAsync("The maximum you can withdraw is " + 1000000 + " bytes! Dm owner if you need to withdraw more quicker.", true);
                return;
            }
            if (bytes > int.MaxValue || bytes < int.MinValue)
            {
                await ctx.CreateResponseAsync("invalid in noob", true);
                return;
            }
            Bot bot = BotManager.FindAvaliableCasinoBot((int)bytes);
            if (bot == null)
            {
                await ctx.CreateResponseAsync(new DiscordEmbedBuilder()
                {
                    Color = DiscordColor.Red,
                    Author = new()
                    {
                        IconUrl = ctx.User.AvatarUrl,
                        Name = ctx.User.Username + "#" + ctx.User.Discriminator
                    },
                    Title = "No bot is avaliable now to withdraw bytes, try again in a few minutes!",
                    Footer = new()
                    {
                        IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                        Text = "made by penjamin#0236"
                    },
                    Timestamp = DateTime.Now
                }.Build(), true);
                return;
            }

            string wn = ConfigData.GenRandomWorld();
            await Console.Out.WriteLineAsync(wn);
            await Console.Out.WriteLineAsync("Deposit started on bot " + bot.Prefix);
            await ctx.CreateResponseAsync(new DiscordEmbedBuilder()
            {
                Color = DiscordColor.Blue,
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = "Bot is loading may take up to 1 minute!",
                ImageUrl = "https://media.discordapp.net/attachments/1101210686555684895/1101210719963320330/Untitled514_20230312182321.png?width=662&height=662",
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            }.Build(), true);
            CasinoDiscordBot.UsersUsingInGame.Add(ctx.User.Id);
            bot.botHelper.Casino.BeginWithdraw(username.ToUpper(), ctx, wn, (int)bytes);
        }
    }
}
