﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class StatsCmd : ApplicationCommandModule
    {
        [SlashCommand("Stats", "Check your statistics!")]
        public async Task GetStats(InteractionContext ctx, [Option("User", "Another user")] DiscordUser user = null)
        {
            Stats stats;
            if (user == null)
            {
                stats = CasinoDiscordBot.GetStats(ctx.User.Id);

                string desc = $"Highest bet: {stats.highest_bet}\nTotal gambled: {stats.bytesGambled}\nHighest loss: {stats.highest_lost}\nTotal deposited: {stats.deposited}\n" +
                $"Win/Loss Ratio: **{Math.Round(((double)stats.wins / (double)stats.loses) * 100, 2)}%**\nNet gain: {stats.bytesGambled - stats.bytesLost}";

                var eembed = new DiscordEmbedBuilder()
                {
                    Color = new DiscordColor(new Random().Next(0, 1000000)),
                    Author = new()
                    {
                        IconUrl = ctx.User.AvatarUrl,
                        Name = ctx.User.Username + "#" + ctx.User.Discriminator
                    },
                    Title = ctx.User.Username + "'s stats:",
                    Thumbnail = new DiscordEmbedBuilder.EmbedThumbnail()
                    {

                        Url = ctx.User.AvatarUrl,
                    },
                    Footer = new()
                    {
                        IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                        Text = "made by penjamin#0236"
                    },
                    Timestamp = DateTime.Now

                };
                eembed.AddField("Highest bet", "```" + stats.highest_bet + "```", true)
                .AddField("Total gambled", "```" + stats.bytesGambled + "```", true)
                .AddField("Biggest loss", "```" + stats.highest_lost + "```", true)
                .AddField("Total deposited", "```" + stats.deposited + "```", true)
                .AddField("Total withdrawn", "```" + stats.withdrawn + "```", true)
                .AddField("Win/Loss Ratio (%)", "```" + Math.Round(((double)stats.wins / (double)stats.loses) * 100, 2) + "%" + "```", true)
                .AddField("Net gain", "```" + (stats.bytesGambled - stats.bytesLost) + "```", true)
                .AddField("Games won", "```" + (stats.wins) + "```", true)
                .AddField("Games lost", "```" + (stats.loses) + "```", true);

                await ctx.CreateResponseAsync(eembed.Build(), false);
                return;
            }

            if (user.Id == 760084009404727297)
            {
                await ctx.CreateResponseAsync("You can't check the stats of this user", true); return;
            }

            stats = CasinoDiscordBot.GetStats(user.Id);

            string descc = $"Highest bet: {stats.highest_bet}\nTotal gambled: {stats.bytesGambled}\nHighest loss: {stats.highest_lost}\nTotal deposited: {stats.deposited}\n" +
                $"Win/Loss Ratio: **{Math.Round(((double)stats.wins / (double)stats.loses) * 100, 2)}%**\nNet gain: {stats.bytesGambled - stats.bytesLost}";

            var embed = new DiscordEmbedBuilder()
            {
                Color = new DiscordColor(new Random().Next(0, 1000000)),
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Title = user.Username + "'s stats:",
                Thumbnail = new DiscordEmbedBuilder.EmbedThumbnail()
                {

                    Url = user.AvatarUrl,
                },
                //Description = descc,
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };
            embed.AddField("Highest bet", "```" + stats.highest_bet + "```", true)
                .AddField("Total gambled", "```" + stats.bytesGambled + "```", true)
                .AddField("Biggest loss", "```" + stats.highest_lost + "```", true)
                .AddField("Total deposited", "```" + stats.deposited + "```", true)
                .AddField("Total withdrawn", "```" + stats.withdrawn + "```", true)
                .AddField("Win/Loss Ratio (%)", "```" + Math.Round(((double)stats.wins / (double)stats.loses) * 100, 2) + "%" + "```", true)
                .AddField("Net gain", "```" + (stats.bytesGambled - stats.bytesLost) + "```", true)
                .AddField("Games won", "```" + (stats.wins) + "```", true)
                .AddField("Games lost", "```" + (stats.loses) + "```", true);

            await ctx.CreateResponseAsync(embed.Build(), false);
            return;
        }


    }
}
