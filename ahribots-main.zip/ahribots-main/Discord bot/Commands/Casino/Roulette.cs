﻿using DSharpPlus.Entities;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Roulette : ApplicationCommandModule
    {

        [SlashCommand("Roulette", "Spin the roulette wheel to win major bytes!")]
        public async Task PlayRoulette(InteractionContext ctx, [Option("Choice", "Choose between black, red or green.")][Choice("Black", 0)][Choice("Red", 1)][Choice("Green", 2)] long choice, [Option("Bet", "amount of bytes you would like to bet")] long bytes)
        {
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("You can't play games while withdrawing!");
                return;
            }
            int balance = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bytes < CasinoDiscordBot.mimimumbet)
            {
                await ctx.CreateResponseAsync("The minimum you can bet is " + CasinoDiscordBot.mimimumbet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > CasinoDiscordBot.maximumBet)
            {
                await ctx.CreateResponseAsync("The maximum you can bet is " + CasinoDiscordBot.maximumBet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > balance)
            {
                await ctx.CreateResponseAsync("You only have " + balance + " <:bc:1101251335023775814>");
                return;
            }

            int seed = CasinoDiscordBot.GenerateRandomSeed();
            Random random = new(seed);

            var embed = new DiscordEmbedBuilder()
            {
                Author = new()
                {
                    IconUrl = ctx.User.AvatarUrl,
                    Name = ctx.User.Username + "#" + ctx.User.Discriminator
                },
                Footer = new()
                {
                    IconUrl = "https://images-ext-2.discordapp.net/external/yYZ9fqP9k8m0FikBRoLiGzVGYh1-Pgo4HJDrVGdXfhQ/%3Fsize%3D4096/https/cdn.discordapp.com/avatars/760084009404727297/59daeb907324705003bf1100518d367a.png?width=662&height=662",
                    Text = "made by penjamin#0236"
                },
                Timestamp = DateTime.Now
            };

            var response = new DiscordInteractionResponseBuilder().AsEphemeral(false);


            int num = random.Next(37);
            bool CanPay = CasinoDiscordBot.CanPayOut((int)bytes) && CasinoDiscordBot.CanPayOut((int)bytes * 3);

            bool win = random.Next(100) > CasinoDiscordBot.HouseOdds;

            if (win && CanPay)
            {
                if (choice == 2)
                {
                    num = GetRandomNumber(true);
                }
                else
                    num = GetRandomNumber(choice == 1);
            }
            else
            {
                num = GetRandomNumber(choice == 0);
            }


            CasinoDiscordBot.AddBytes(ctx.User.Id, (int)-bytes);
            CasinoDiscordBot.UpdateStats(ctx.User, (int)bytes);
            string choiceS = "Green";
            if (choice != 2)
                choiceS = (choice == 1) ? "Red" : "Black";

            string rndChoice = "Green";
            if (num != 0)
            {
                rndChoice = (num % 2 == 0) ? "Red" : "Black";
            }

            bool userWon = false;

            if (choice == 2 && num == 0)
            {
                int winnings = (int)Math.Round(bytes * 10 - ((bytes * 10) * CasinoDiscordBot.tax));
                CasinoDiscordBot.AddBytes(ctx.User.Id, winnings);
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, winnings, true);
                embed.Color = DiscordColor.Green;
                embed.Title = "You won " + winnings + " <:bc:1101251335023775814>";
                embed.Description = $"The wheel landed on {num}({rndChoice}), you chose {choiceS}.";
                response.AddEmbed(embed.Build());
                await ctx.CreateResponseAsync(response);
                userWon = true;
            }
            else if (choice == 1 && num % 2 == 0)
            {
                int winnings = (int)Math.Round(bytes * 2 - ((bytes * 2) * CasinoDiscordBot.tax));
                CasinoDiscordBot.AddBytes(ctx.User.Id, winnings);
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, winnings, true);
                embed.Color = DiscordColor.Green;
                embed.Title = "You won " + winnings + " <:bc:1101251335023775814>";
                embed.Description = $"The wheel landed on {num}({rndChoice}), you chose {choiceS}.";
                response.AddEmbed(embed.Build());
                await ctx.CreateResponseAsync(response);
                userWon = true;
            }
            else if (choice == 0 && (num % 2 == 1 || num == 0))
            {
                int winnings = (int)Math.Round(bytes * 2 - ((bytes * 2) * CasinoDiscordBot.tax));
                CasinoDiscordBot.AddBytes(ctx.User.Id, winnings);
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, winnings, true);
                embed.Color = DiscordColor.Green;
                embed.Title = "You won " + winnings + " <:bc:1101251335023775814>";
                embed.Description = $"The wheel landed on {num}({rndChoice}), you chose {choiceS}.";
                response.AddEmbed(embed.Build());
                await ctx.CreateResponseAsync(response);
            }
            else
            {
                // this is lose
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, (int)bytes, false);
                embed.Color = DiscordColor.Orange;
                embed.Title = "You didn't win..."; 
                embed.Description = $"The wheel landed on **{num} ({rndChoice})**, you chose **{choiceS}**";
                response.AddEmbed(embed.Build());
                await ctx.CreateResponseAsync(response);
            }
        }

        public int GetRandomNumber(bool even)
        {
            Random random = new Random();
            int num;
            if (even)
            {
                num = random.Next(0, 18) * 2;
            }
            else
            {
                num = random.Next(1, 18) * 2 + 1;
            }
            return num;
        }

    }
}
