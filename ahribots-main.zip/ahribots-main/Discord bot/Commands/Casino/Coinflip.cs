﻿using ArhiBots.Constants;
using DSharpPlus.Entities;
using DSharpPlus.Interactivity.Extensions;
using DSharpPlus.SlashCommands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ArhiBots.Discord_bot.Commands.Casino
{
    public class Coinflip : ApplicationCommandModule
    {
        [SlashCommand("Coin", "Flip a coin for a chance to double your bytes!")]
        public async Task CoinFlip(InteractionContext ctx, [Option("Bet", "Amount of bytes you would like to bet")] long bytes)
        {
            int balance = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("You can't play games while withdrawing!");
                return;
            }
            if (bytes < CasinoDiscordBot.mimimumbet)
            {
                await ctx.CreateResponseAsync("The minimum you can bet is " + CasinoDiscordBot.mimimumbet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > CasinoDiscordBot.maximumBet)
            {
                await ctx.CreateResponseAsync("The maximum you can bet is " + CasinoDiscordBot.maximumBet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > balance)
            {
                await ctx.CreateResponseAsync("You only have " + balance + " <:bc:1101251335023775814>");
                return;
            }
            bool back = false;
        Start:
            
            if (back)
            {
                balance = CasinoDiscordBot.GetBalance(ctx.User.Id);
                if (bytes > balance)
                {
                    var wbbla = new DiscordWebhookBuilder() { };
                    wbbla.WithContent("You only have " + balance + " <:bc:1101251335023775814>");
                    await ctx.Interaction.EditOriginalResponseAsync(wbbla);
                    return;
                }
            }

            int seed = CasinoDiscordBot.GenerateRandomSeed();
            Random random = new(seed);

            
            int level = 0;
            
            var response = new DiscordInteractionResponseBuilder();



            response.AddComponents(
                new DiscordButtonComponent(DSharpPlus.ButtonStyle.Primary, "1", "", emoji: new DiscordComponentEmoji { Id = 1102197519565471835, Name = "heads" }),
                new DiscordButtonComponent(DSharpPlus.ButtonStyle.Primary, "2", "", emoji: new DiscordComponentEmoji { Id = 1101251335023775814, Name = "tails" })
                );
            var embed = CasinoDiscordBot.GetDefaultEmbed(ctx);

            List<Coin> coinList = new List<Coin>(3) { Coin.None, Coin.None, Coin.None };
            CasinoDiscordBot.AddBytes(ctx.User.Id, (int)-bytes);
            CasinoDiscordBot.UpdateStats(ctx.User, (int)bytes);
        Top:

            embed.WithColor(DiscordColor.Blue);
            embed.WithTitle($"Pick heads ({GetEmote(Coin.Heads)}) or tails ({GetEmote(Coin.Tails)})");
            await Console.Out.WriteLineAsync("cool 1");


            var dwb = new DiscordWebhookBuilder();

            string description = "";
            for (int i = 0; i < 3; i++)
            {
                description += $"{Multiplyer(3 - i),3}x {GetEmote(coinList[2 - i])}\n";
            }
            embed.WithDescription(description);

            
            if (!back)
            {
                back = true;
                response.AddEmbed(embed.Build());
                await ctx.CreateResponseAsync(response);
            }
            else
            {
                dwb.AddEmbed(embed.Build());
                dwb.AddComponents(
                    new DiscordButtonComponent(DSharpPlus.ButtonStyle.Primary, "1", "", emoji: new DiscordComponentEmoji { Id = 1102197519565471835, Name = "heads" }),
                    new DiscordButtonComponent(DSharpPlus.ButtonStyle.Primary, "2", "", emoji: new DiscordComponentEmoji { Id = 1101251335023775814, Name = "tails" })
                );
                await ctx.Interaction.EditOriginalResponseAsync(dwb);
            }
            var message = await ctx.GetOriginalResponseAsync();

            var componentResult = await message.WaitForButtonAsync(ctx.User);

            Coin randomChoice = random.Next(0, 101) > 50 ? Coin.Heads : Coin.Tails;

            bool win = random.Next(100) > (CasinoDiscordBot.HouseOdds - ((bytes < 4000 && level <= 1) ? 10 : 0) + ((bytes > 333333 || level == 3) ? 10 : 0));

            Coin choice = (Coin)int.Parse(componentResult.Result.Id);

            bool canWin = CasinoDiscordBot.CanPayOut((int)bytes) && CasinoDiscordBot.CanPayOut((int)bytes * 5);

            await Console.Out.WriteLineAsync(canWin + " : can user win");
            await Console.Out.WriteLineAsync(randomChoice.ToString());
            if (canWin && win)
            {
                randomChoice = choice == Coin.Heads ? Coin.Heads : Coin.Tails;
            }
            else
            {
                randomChoice = choice == Coin.Heads ? Coin.Tails : Coin.Heads;
            }
            dwb.Clear();
            dwb.ClearComponents();
            coinList[level] = choice;

            if (choice != randomChoice)
            {

                description = "";
                for (int i = 0; i < 3; i++)
                {
                    description += $"{Multiplyer(3 - i),3}x {GetEmote(coinList[3 - i - 1])}\n";
                }
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, (int)bytes, false);
                embed.WithColor(DiscordColor.Orange);
                embed.Title = $"The coin landed on {GetEmote(randomChoice)}";
                embed.WithDescription($"**You didn't win!**\nYou chose: {GetEmote(choice)}\nCoin flips: {level + 1}");
                dwb.AddEmbed(embed.Build());
                dwb.AddComponents(
                    new DiscordButtonComponent(DSharpPlus.ButtonStyle.Primary, "again", "Again")
                    );
                var msg = await ctx.Interaction.EditOriginalResponseAsync(dwb);
                var rsp = await msg.WaitForButtonAsync(ctx.User, TimeSpan.FromSeconds(12));

                if (!rsp.TimedOut)
                {
                    string id3 = rsp.Result.Id;

                    if (id3 == "again")
                        goto Start;

                    return;
                }

                dwb.ClearComponents();
                await ctx.Interaction.EditOriginalResponseAsync(dwb);

                return;
            }

            
            
            level++;

            if (level != 3)
            {
                dwb.AddComponents(
                new DiscordButtonComponent(DSharpPlus.ButtonStyle.Success, "continue", "continue!"),
                new DiscordButtonComponent(DSharpPlus.ButtonStyle.Danger, "exit", "exit")
                );

                var emb = CasinoDiscordBot.GetDefaultEmbed(ctx);
                emb.WithColor(DiscordColor.Green);
                emb.WithTitle(":star: You chose correct :star:");
                description = "";
                for (int i = 0; i < 3; i++)
                {
                    description += $"{Multiplyer(3 - i),3}x {GetEmote(coinList[3 - i - 1])}\n";
                }
                emb.WithDescription(description);
                dwb.AddEmbed(emb);

                var newMessage = await ctx.Interaction.EditOriginalResponseAsync(dwb);
                var result = await newMessage.WaitForButtonAsync(ctx.User);
                string id2 = result.Result.Id;

                if (id2 == "continue" && level < 3)
                    goto Top;
            }
            

            int winnings = (int)Math.Round(bytes * Multiplyer(level));
            CasinoDiscordBot.AddBytes(ctx.User.Id, winnings);
            CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, winnings, true);
            var embedA = CasinoDiscordBot.GetDefaultEmbed(ctx);
            embedA.WithColor(DiscordColor.Green);
            embedA.Title =  $":star: YOU WON {winnings} <:bc:1101251335023775814> :star: ";
            description = "";
            for (int i = 0; i < 3; i++)
            {
                description += $"{Multiplyer(3 - i),3}x {GetEmote(coinList[3 - i - 1])}\n";
            }
            embedA.WithDescription(description);

            var aaa = new DiscordWebhookBuilder();

            aaa.AddEmbed(embedA);
            aaa.AddComponents(
                    new DiscordButtonComponent(DSharpPlus.ButtonStyle.Primary, "again", "Again")
                    );


            var msgg = await ctx.Interaction.EditOriginalResponseAsync(aaa);

           
            var rspp = await msgg.WaitForButtonAsync(ctx.User, TimeSpan.FromSeconds(10));

            if (!rspp.TimedOut)
            {
                string id3 = rspp.Result.Id;

                if (id3 == "again")
                    goto Start;

                return;
            }

            dwb.ClearComponents();
            await ctx.Interaction.EditOriginalResponseAsync(dwb);
        }


        [SlashCommand("coinflip", "The original coin flip command!")]
        public async Task doCoinFlip(InteractionContext ctx, [Option("choice", "Pick heads or tails")][Choice("Heads", 1)][Choice("Tails", 2)]long choice, [Option("bytes", "Amount of bytes you would like to bet")]long bytes)
        {
            
            Coin coin = (Coin)choice;
            if (CasinoDiscordBot.UsersUsingInGame.Contains(ctx.User.Id))
            {
                await ctx.CreateResponseAsync("You can't play games while withdrawing!");
                return;
            }
            int balance = CasinoDiscordBot.GetBalance(ctx.User.Id);
            if (bytes < CasinoDiscordBot.mimimumbet)
            {
                await ctx.CreateResponseAsync("The minimum you can bet is " + CasinoDiscordBot.mimimumbet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > CasinoDiscordBot.maximumBet)
            {
                await ctx.CreateResponseAsync("The maximum you can bet is " + CasinoDiscordBot.maximumBet + " <:bc:1101251335023775814>");
                return;
            }
            if (bytes > balance)
            {
                await ctx.CreateResponseAsync("You only have " + balance + " <:bc:1101251335023775814>");
                return;
            }

            int seed = CasinoDiscordBot.GenerateRandomSeed();
            var random = new Random(seed);

            bool CanPay = CasinoDiscordBot.CanPayOut((int)bytes) && CasinoDiscordBot.CanPayOut((int)bytes * 3);
            bool win = random.Next(100) > CasinoDiscordBot.HouseOdds - ((bytes < 3999) ? 7 : 0) + ((bytes > 50000) ? 7 : 0);

            CasinoDiscordBot.AddBytes(ctx.User.Id, (int)-bytes);
            CasinoDiscordBot.UpdateStats(ctx.User, (int)bytes);


            Coin computersChoice = Coin.None;
            if (win && CanPay)
            {
                computersChoice = coin == Coin.Heads ? Coin.Heads : Coin.Tails;
            }
            else
            {
                computersChoice = coin == Coin.Tails ? Coin.Heads : Coin.Tails;
            }

            var embed = CasinoDiscordBot.GetDefaultEmbed(ctx);

            if (computersChoice == coin)
            {
                int winnings = (int)Math.Round(bytes * 1.95);
                CasinoDiscordBot.AddBytes(ctx.User.Id, winnings);
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, winnings, true);

                embed.Title = ":star: YOU WON " + winnings + " <:bc:1101251335023775814> :star:";
                embed.WithDescription("You chose: " + GetEmote(coin));
                embed.WithColor(DiscordColor.Green);
                await ctx.CreateResponseAsync(embed);
            }
            else
            {
                CasinoDiscordBot.UpdateStatsForWinOrLose(ctx.User, (int)bytes, false);
                embed.WithColor(DiscordColor.Orange);
                embed.Title = "The coin landed on " + GetEmote(computersChoice);
                embed.WithDescription("You chose: " + GetEmote(coin));

                await ctx.CreateResponseAsync(embed);
            }

        }

        public enum Coin
        {
            None,
            Heads,
            Tails
        }

        static string GetEmote(Coin coin)
        {
            switch (coin)
            {
                case Coin.None:
                    return "<:coolercircle:1102339215754264656>";

                case Coin.Heads:
                    return "<:heads:1102197519565471835>";

                case Coin.Tails:
                    return "<:bc:1101251335023775814>";

                default:
                    return String.Empty;
            }
        }

        static float Multiplyer(int level)
        {
            switch (level)
            {
                case 1:
                    return 1.85f;
                case 2:
                    return 2.81f;
                case 3:
                    return 5.13f;
                case 4:
                    return 12.36f;
                case 5:
                    return 23.72f;
                case 6:
                    return 53.82f;
                case 7:
                    return 100.02f;
                case 8:
                    return 203.32f;
                case 9:
                    return 491.52f;
                case 10:
                    return 983.04f;
            }

            return 1;
        }
    }
}
